local pedTable = { }
local characterSelected, characterElementSelected, newCharacterButton, bLogout = nil
local Dharma = exports['dgs-master']

font = Dharma:dgsCreateFont(":account/login-panel/DIN-NEXT-LT-W23-REGULAR.TTF", 14)
fontnoChar = Dharma:dgsCreateFont(":account/login-panel/DIN-NEXT-LT-W23-REGULAR.TTF", 10)
upfont = Dharma:dgsCreateFont(":account/login-panel/DIN-NEXT-LT-W23-REGULAR.TTF", 20)
robotoFont10 = Dharma:dgsCreateFont(":resources/fonts/Roboto-Regular.ttf", 10)
FreesansBold10 = Dharma:dgsCreateFont(":resources/fonts/FreeSansBold.otf", 10)
FreesansBold14 = Dharma:dgsCreateFont(":resources/fonts/FreeSansBold.otf", 14)
--FreesansBold12 = Dharma:dgsCreateFont(":resources/fonts/FreeSansBold.otf", 12)
--robotoFont11 = Dharma:dgsCreateFont(":resources/fonts/Roboto-Regular.ttf", 10)
selectionScreenID = 0
thePed = { }
--x, y, z, rot =  1148.296875, -1156.70703125, 23.828125, 0
--count = 0
--oldPos = y
local logoTexture = dxCreateTexture(":account/login-panel/logo.png")
local logoSize = 128 * (1 / 75)
--[[
function logo ()
dxDrawMaterialLine3D(1148.296875, -1156.70703125 + logoSize / 2, 23.828125 - 0.99, 1148.296875, -1156.70703125 - logoSize / 2, 23.828125 - 0.99, logoTexture, logoSize, tocolor(0,162,255), 1148.296875, -1156.70703125, 23.828125 + 10 - 0.99)
end]]
--addEventHandler("onClientRender", getRootElement(), logo)

function Characters_showSelection()
	characters_destroyDetailScreen()
	triggerEvent("onSapphireXMBShow", getLocalPlayer())
	showPlayerHudComponent("radar", false)

	guiSetInputEnabled(false)

	showCursor(true)

	setElementDimension ( getLocalPlayer(), 69 )
	setElementInterior( getLocalPlayer(), 0 )

	for _, thePed in ipairs(pedTable) do
		if isElement(thePed) then
			destroyElement(thePed)
		end
	end

	selectionScreenID = getSelectionScreenID()

	startCam[selectionScreenID] = originalStartCam[selectionScreenID]

	local x, y, z, rot =  pedPos[selectionScreenID][1], pedPos[selectionScreenID][2], pedPos[selectionScreenID][3], pedPos[selectionScreenID][4]
	local characterList = getElementData(getLocalPlayer(), "account:characters")
	if (characterList) then
		-- Prepare the peds
		setTimer(function()
	color = tocolor(0,162,255, 175)
	hovercolor = tocolor(0,162,255, 225)
	clickcolor = tocolor(0,162,255, 255)
	local x, y, z = 1148.296875, -1156.70703125, 23.828125
	material = Dharma:dgsCreate3DInterface(x, y - 0.3, z,2,2,400,400,tocolor(255,255,255,255),0, 1, 0)
	Dharma:dgs3DInterfaceSetDimension(material, getElementDimension(localPlayer))
	leftBtn = Dharma:dgsCreateButton(50,200,30,30,"<",false,material,tocolor(255,255,255,255), 1,1,nil,nil,nil, color ,hovercolor, clickcolor)
	rightBtn = Dharma:dgsCreateButton(350,200,30,30,">",false,material,tocolor(255,255,255,255), 1,1,nil,nil,nil, color ,hovercolor, clickcolor)
		DGS:dgsSetAlpha(leftBtn,0)
		DGS:dgsAlphaTo(leftBtn,1,"Linear",500)
		DGS:dgsSetAlpha(rightBtn,0)
		DGS:dgsAlphaTo(rightBtn,1,"Linear",500)
		--addEventHandler("onDgsMouseClickDown", leftBtn, selectPrevChar)
		--addEventHandler("onDgsMouseClickDown", rightBtn, selectNextChar)
		selectCharacter(1)
		end, 5500,1)

		-- Cam magic
		fadeCamera ( false, 0, 0,0,0 )
		setCameraMatrix (originalStartCam[selectionScreenID][1], originalStartCam[selectionScreenID][2], originalStartCam[selectionScreenID][3], originalStartCam[selectionScreenID][4], originalStartCam[selectionScreenID][5], originalStartCam[selectionScreenID][6])
		setTimer(function ()
			fadeCamera ( true, 1, 0,0,0 )
		end, 1000, 1)

		setTimer(function ()
			showCursor(true)
			addEventHandler("onClientRender", getRootElement(), Characters_updateSelectionCamera)
			addEventHandler("onClientRender", getRootElement(), renderNametags)
			--addEventHandler("onClientRender", root, logo)

			local bgMusic = getElementData(localPlayer, "bgMusic")
			if not bgMusic or not isElement(bgMusic) then
				local bgMusic = playSound ("http://grizzly-gaming.net/less/neon.mp3", true)
				setSoundVolume(bgMusic, 1)
				setElementData(localPlayer, "bgMusic", bgMusic)
			end
			--[[
			local selectionSound = playSound ( "selection_screen.mp3")
			setSoundVolume(selectionSound, 0.3)
			setElementData(localPlayer, "selectionSound", selectionSound)
			--]]
		end, 2000, 1)


	end
end

function selectCharacter(ID)
	if isElement(thePed) then
		destroyElement(thePed)
	end
	local x, y, z, rot =  pedPos[0][1], pedPos[0][2], pedPos[0][3], pedPos[0][4]
	local Characters = getElementData(getLocalPlayer(), "account:characters")
	thePed = createPed( tonumber( Characters[ID][9]), x, y, z)
	setPedRotation(thePed, rot)
	setElementDimension(thePed, 69)
	setElementInterior(thePed, 0)
	charselected = ID
	setElementData(thePed,"account:charselect:id", Characters[ID][1], false)
	setElementData(thePed,"account:charselect:name", Characters[ID][2]:gsub("_", " "), false)
	setElementData(thePed,"account:charselect:cked", Characters[ID][3], false)
	setElementData(thePed,"account:charselect:lastarea", Characters[ID][4], false)
	setElementData(thePed,"account:charselect:age", Characters[ID][5], false)
	setElementData(thePed,"account:charselect:gender", Characters[ID][6], false)
	setElementData(thePed,"account:charselect:faction", Characters[ID][7] or "", false)
	setElementData(thePed,"account:charselect:factionrank", Characters[ID][8] or "", false)
	setElementData(thePed,"account:charselect:skin", Characters[ID][9], false)
	setElementData(thePed,"account:charselect:lastlogin", Characters[ID][10], false)
	setElementData(thePed,"account:charselect:weight", Characters[ID][11], false)
	setElementData(thePed,"account:charselect:height", Characters[ID][12], false)
	setElementData(thePed,"account:charselect:month", Characters[ID][13], false)
	setElementData(thePed,"account:charselect:day", Characters[ID][14], false)
	setElementData(thePed,"clothing:id", Characters[ID][15] or "", false)
	setElementData(thePed,"account:charselect:hours", Characters[ID][16], false)
	setElementData(thePed,"account:charselect:money", Characters[ID][17], false)
	setElementData(thePed,"account:charselect:bankmoney", Characters[ID][18], false)
	setElementData(thePed,"account:charselect:job", Characters[ID][19], false)
	setElementData(thePed,"account:charselect:creationdate", Characters[ID][20], false)
	setElementData(thePed,"account:charselect:ethnicity", Characters[ID][21], false)
	setElementData(thePed,"account:charselect:interior", Characters[ID][22], false)
	setElementData(thePed,"account:charselect:dimension", Characters[ID][23], false)
	setElementData(thePed,"account:charselect:fightstyle", Characters[ID][24], false)
	setElementData(thePed,"account:charselect:lang1", Characters[ID][25], false)
	setElementData(thePed,"account:charselect:lang2", Characters[ID][26], false)
	setElementData(thePed,"account:charselect:lang3", Characters[ID][27], false)
	setElementData(thePed,"account:charselect:carlicense", Characters[ID][28], false)
	setElementData(thePed,"account:charselect:bikelicense", Characters[ID][29], false)
	setElementData(thePed,"account:charselect:pilotlicense", Characters[ID][30], false)
	setElementData(thePed,"account:charselect:fishlicense", Characters[ID][31], false)
	setElementData(thePed,"account:charselect:boatlicense", Characters[ID][32], false)
	setElementData(thePed,"account:charselect:gunlicense", Characters[ID][33], false)
	setElementData(thePed,"account:charselect:gun2license", Characters[ID][34], false)
	setElementData(thePed,"account:charselect:description", Characters[ID][35], false)
	setElementData(thePed,"account:charselect:maxints", Characters[ID][36], false)
	setElementData(thePed,"account:charselect:maxvehs", Characters[ID][37], false)
	local randomAnimation = getRandomAnim( Characters[ID][3] == 1 and 4 or 2 )
	setPedAnimation ( thePed , randomAnimation[1], randomAnimation[2], -1, true, false, false, false )
	showCharacterGUI()
end

addEventHandler("onDgsMouseClickDown", root, 
function ()
local Characters = getElementData(getLocalPlayer(), "account:characters")
	for i = #Characters , #Characters do

		if source == leftBtn then
			if charselected <= 1 then
				selectCharacter(1)
			else
				selectCharacter(charselected - 1)
			end
		end
		if source == rightBtn then
			if charselected >= #Characters then
				selectCharacter(#Characters)
			else
				selectCharacter(charselected + 1)
			end
		end
	end
end)

function Characters_characterSelectionVisisble()
	addEventHandler("onClientClick", getRootElement(), Characters_onClientClick)
	
local _char = getElementData(getLocalPlayer(), "account:characters")
local _time = getElementData(getLocalPlayer(), "hoursplayed")
	local swidth, sheight = guiGetScreenSize()
	local width, height = 300, 50
		btnRect = Dharma:dgsCreateRoundRect(15, false, tocolor(20,20,20,255))  --Create Rounded Rectangle with 50 pixels radius 
		btnRecthov = Dharma:dgsCreateRoundRect(15, false, tocolor(7, 112, 196, 200))  --Create Rounded Rectangle with 50 pixels radius 
		btnRectClick = Dharma:dgsCreateRoundRect(15, false, tocolor(7, 112, 196, 255))
		
--(x,y,sx,sy,text,relative,textColor,titleHeight,titleImage,titleColor,image,color,borderSize,noCloseButton)
		Wnd = Dharma:dgsCreateWindow(0, 0-1, 1, 0.17, "", true, _, 4, _, tocolor(0,162,255, 200), _, tocolor(10, 10, 10, 255), _, true)
		Dharma:dgsWindowSetSizable (Wnd, false)
		Dharma:dgsWindowSetMovable (Wnd, false)
		Dharma:dgsMoveTo(Wnd,0,0,true,"Linear",2000) --Set Animation
		Dharma:dgsSetAlpha(Wnd,0)
		Dharma:dgsAlphaTo(Wnd,1,"Linear",2500)
		--lbl1 = Dharma:dgsCreateLabel(0.565, 0.179, 0.06, 0.11, "#c8c8c8Want to start fresh?", true, Wnd)
		lbl2 = Dharma:dgsCreateLabel(0.13, 0.35, 0.06, 0.11, "Your last login:", true, Wnd, tocolor(200, 200, 200, 255))
		lbl3 = Dharma:dgsCreateLabel(0.13, 0.50, 0.06, 0.11, "Total hours played:", true, Wnd, tocolor(200, 200, 200, 255))
		lbl4 = Dharma:dgsCreateLabel(0.13, 0.65, 0.06, 0.11, "Total Characters:", true, Wnd, tocolor(200, 200, 200, 255))
		lbl5 = Dharma:dgsCreateLabel(0.35, 0.35, 0.05, 0.11, "Email Address:", true, Wnd, tocolor(200, 200, 200, 255))
		lbl6 = Dharma:dgsCreateLabel(0.35, 0.50, 0.05, 0.11, "Registration Date:", true, Wnd, tocolor(200, 200, 200, 255))
		lbl7 = Dharma:dgsCreateLabel(0.35, 0.65, 0.05, 0.11, "GC:", true, Wnd, tocolor(200, 200, 200, 255))
		--Dharma:dgsSetFont(lbl1, font)
		Dharma:dgsSetProperty(lbl2, "font", font)
		Dharma:dgsSetProperty(lbl3, "font", font)
		Dharma:dgsSetProperty(lbl4, "font", font)
		Dharma:dgsSetProperty(lbl5, "font", font)
		Dharma:dgsSetProperty(lbl6, "font", font)
		Dharma:dgsSetProperty(lbl7, "font", font)
		
		Dharma:dgsLabelSetHorizontalAlign(lbl2, "right")
		Dharma:dgsLabelSetHorizontalAlign(lbl3, "right")
		Dharma:dgsLabelSetHorizontalAlign(lbl4, "right")
		Dharma:dgsLabelSetHorizontalAlign(lbl5, "right")
		Dharma:dgsLabelSetHorizontalAlign(lbl6, "right")
		Dharma:dgsLabelSetHorizontalAlign(lbl7, "right")
		browser = Dharma:dgsCreateMediaBrowser(135,125) --Create Multi Media Browser
		--Dharma:dgsMediaLoadMedia(browser,":account/login-panel/vlogo.gif","IMAGE")  --Load the gif file into multi media browser
		playerImage = Dharma:dgsCreateImage(0, 0, 125, 123,":account/login-panel/logo.png",false, Wnd)
		local playerName = getElementData(localPlayer, "account:username")
		playerNameLabel = Dharma:dgsCreateLabel(0.29, 0.02, 0.05, 0.11, "#C8C8C8Welcome to Future Time, #0770C4" .. playerName .. "!", true, Wnd, tocolor(238, 33, 73, 255))
		Dharma:dgsLabelSetHorizontalAlign(playerNameLabel, "center")
		Dharma:dgsSetProperty(playerNameLabel, "font", upfont)
		Dharma:dgsSetProperty(playerNameLabel,"colorCoded",true)
	    local lastLogin = getElementData(localPlayer, "account:lastlogin") or "Unknown"
		lastLoginLabel = Dharma:dgsCreateLabel(0.194, 0.35, 0.08, 0.11, lastLogin, true, Wnd, tocolor(0,162,255, 200))
		Dharma:dgsSetProperty(lastLoginLabel, "font", font)
		local hoursPlayed = getElementData(localPlayer, "timeinserver") or "New"; --hoursPlayed = exports.global:formatNumber(hoursPlayed)
		totalHoursLabel = Dharma:dgsCreateLabel(0.194, 0.50, 0.08, 0.11, hoursPlayed .. " Hours", true, Wnd, tocolor(0,162,255, 200))
        Dharma:dgsSetProperty(totalHoursLabel, "font", font)
		local pedCount = #_char or 0
		totalCharactersLabel = Dharma:dgsCreateLabel(0.194, 0.65, 0.08, 0.11, pedCount .. " Characters", true, Wnd, tocolor(0,162,255, 200))
        Dharma:dgsSetProperty(totalCharactersLabel, "font", font)
		local emailAddress = getElementData(localPlayer, "account:email") or "Unknown"
		emailAddressLabel = Dharma:dgsCreateLabel(0.403, 0.35, 0.08, 0.11, emailAddress, true, Wnd, tocolor(0,162,255, 200))
        Dharma:dgsSetProperty(emailAddressLabel, "font", font)
		local registerDate = getElementData(localPlayer, "account:registerdate") or "Unknown"
		registrationDateLabel = Dharma:dgsCreateLabel(0.403, 0.50, 0.08, 0.11, registerDate, true, Wnd, tocolor(0,162,255, 200))
		Dharma:dgsSetProperty(registrationDateLabel, "font", font)

		local gc = getElementData(localPlayer, "account:credits") or "0"
		gcLabel = Dharma:dgsCreateLabel(0.403, 0.65, 0.08, 0.11, gc, true, Wnd, tocolor(0,162,255, 200))
        Dharma:dgsSetProperty(gcLabel, "font", font)
		newCharacterButton = Dharma:dgsCreateButton(0.55, 0.34, 0.10, 0.42, "Create Character", true, Wnd, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
		addEventHandler("onDgsMouseClickDown", newCharacterButton, Characters_newCharacter, false)
        Dharma:dgsSetProperty(newCharacterButton, "font", font)
		Dharma:dgsSetProperty(newCharacterButton,"textOffset",{-10,0,false})
		Dharma:dgsSetProperty(newCharacterButton,"iconImage",{":account/login-panel/registers.png",":account/login-panel/registers.png",":account/login-panel/registers.png"})
		Dharma:dgsSetProperty(newCharacterButton,"iconOffset",{130,0})
		Dharma:dgsSetProperty(newCharacterButton,"iconSize",{35,35,false})

		accountHistoryButton = Dharma:dgsCreateButton(0.66, 0.34, 0.10, 0.42, "Account History", true, Wnd, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
		addEventHandler("onDgsMouseClickDown", accountHistoryButton, History, false)
        Dharma:dgsSetProperty(accountHistoryButton, "font", font)
		Dharma:dgsSetProperty(accountHistoryButton,"textOffset",{-11,0,false})
		Dharma:dgsSetProperty(accountHistoryButton,"iconImage",{":account/login-panel/hist.png",":account/login-panel/hist.png",":account/login-panel/hist.png"})
		Dharma:dgsSetProperty(accountHistoryButton,"iconOffset",{125,0})
		Dharma:dgsSetProperty(accountHistoryButton,"iconSize",{30,30,false})
		accountRefreshButton = Dharma:dgsCreateButton(0.77, 0.34, 0.10, 0.42, "Refresh", true, Wnd, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
		addEventHandler("onDgsMouseClickDown", accountRefreshButton, Refresh, false)
        Dharma:dgsSetProperty(accountRefreshButton, "font", font)
		Dharma:dgsSetProperty(accountRefreshButton,"textOffset",{-33,0,false})
		Dharma:dgsSetProperty(accountRefreshButton,"iconImage",{":account/login-panel/refresh.png",":account/login-panel/refresh.png",":account/login-panel/refresh.png"})
		Dharma:dgsSetProperty(accountRefreshButton,"iconOffset",{120,0})
		Dharma:dgsSetProperty(accountRefreshButton,"iconSize",{35,35,false})
		bLogout = Dharma:dgsCreateButton(0.88, 0.34, 0.10, 0.42, "Logout", true, Wnd, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
		Dharma:dgsSetProperty(bLogout,"textOffset",{-35,0,false})
		Dharma:dgsSetProperty(bLogout,"iconImage",{":account/login-panel/leftarrow.png",":account/login-panel/leftarrow.png",":account/login-panel/leftarrow.png"})
		Dharma:dgsSetProperty(bLogout,"iconOffset",{117,0})
		Dharma:dgsSetProperty(bLogout,"iconSize",{35,35,false})
		Dharma:dgsSetProperty(bLogout, "font", font)
		addEventHandler("onDgsMouseClickDown", bLogout, function ()
		removeEventHandler("onClientRender", getRootElement(), renderNametags)
		fadeCamera ( false, 2, 0,0,0 )
		setTimer(function()
		triggerServerEvent("accounts:reconnectMe", localPlayer)
		end, 2000,1)
	end, false)
end


function getCamSpeed( index1, startCam1, endCam1, globalspeed1)
	return (math.abs(startCam1[index1]-endCam1[index1])/globalspeed1)
end

--Check c_login.lua for settings block
function Characters_updateSelectionCamera ()
	for var = 1, 6, 1 do
		if not doneCam[selectionScreenID][var] then
			--outputDebugString("if not doneCam[selectionScreenID][var] then")
			if (math.abs(startCam[selectionScreenID][var] - endCam[selectionScreenID][var]) > 0.2) then
				if startCam[selectionScreenID][var] > endCam[selectionScreenID][var] then
					startCam[selectionScreenID][var] = startCam[selectionScreenID][var] - getCamSpeed( var, startCam[selectionScreenID], endCam[selectionScreenID], globalspeed)
				else
					startCam[selectionScreenID][var] = startCam[selectionScreenID][var] + getCamSpeed( var, startCam[selectionScreenID], endCam[selectionScreenID], globalspeed)
				end
			else
				doneCam[selectionScreenID][var] = true
			end
		end
	end

	setCameraMatrix (startCam[selectionScreenID][1], startCam[selectionScreenID][2], startCam[selectionScreenID][3], startCam[selectionScreenID][4], startCam[selectionScreenID][5], startCam[selectionScreenID][6])
	if doneCam[selectionScreenID][1] and doneCam[selectionScreenID][2] and doneCam[selectionScreenID][3] and doneCam[selectionScreenID][4] and doneCam[selectionScreenID][5] and doneCam[selectionScreenID][6] then
		stopMovingCam()
	end
end

function stopMovingCam()
	--playSound ( "WindowsMillenniumEdition.mp3")
	removeEventHandler("onClientRender",getRootElement(),Characters_updateSelectionCamera)
	Characters_characterSelectionVisisble()
end

function renderNametags()
dxDrawMaterialLine3D(1148.296875, -1156.70703125 + logoSize / 2, 23.828125 - 0.99, 1148.296875, -1156.70703125 - logoSize / 2, 23.828125 - 0.99, logoTexture, logoSize, tocolor(0,162,255), 1148.296875, -1156.70703125, 23.828125 + 10 - 0.99)
	for key, player in ipairs(getElementsByType("ped")) do
		if (isElement(player))then
			if (getElementData(player,"account:charselect:id")) then
				local lx, ly, lz = getElementPosition( getLocalPlayer() )
				local rx, ry, rz = getElementPosition(player)
				local distance = getDistanceBetweenPoints3D(lx, ly, lz, rx, ry, rz)
				if  (isElementOnScreen(player)) then
					local lx, ly, lz = getCameraMatrix()
					local collision, cx, cy, cz, element = processLineOfSight(lx, ly, lz, rx, ry, rz+1, true, true, true, true, false, false, true, false, nil)
					if not (collision) then
						local x, y, z = getElementPosition(player)
						local sx, sy = getScreenFromWorldPosition(x, y, z+0.45, 100, false)
						if (sx) and (sy) then
							if (distance<=2) then
								sy = math.ceil( sy - ( 2 - distance ) * 40 )
							end
							sy = sy - 20
							if (sx) and (sy) then
								distance = 1.5
								local offset = 75 / distance
								dxDrawText(getElementData(player,"account:charselect:name"), sx-offset+2, sy+2, (sx-offset)+130 / distance, sy+20 / distance, tocolor(0, 0, 0, 220), 0.6 / distance, "bankgothic", "center", "center", false, false, false)
								dxDrawText(getElementData(player,"account:charselect:name"), sx-offset, sy, (sx-offset)+130 / distance, sy+20 / distance, tocolor(255, 255, 255, 220), 0.6 / distance, "bankgothic", "center", "center", false, false, false)
							end
						end
					end
				end
			end
		end
	end
end

function Characters_onClientClick(mouseButton, buttonState, alsoluteX, alsoluteY, worldX, worldY, worldZ, theElement)
	if (theElement) and (buttonState == "down") then
		if (getElementData(theElement,"account:charselect:id")) then
			characterSelected = getElementData(theElement,"account:charselect:id")
			characterElementSelected = theElement

			Characters_updateDetailScreen(theElement)

			local randomAnimation = nil
			for _, thePed in ipairs(pedTable) do
				if isElement(thePed) then
					local deceased = getElementData(thePed,"account:charselect:cked")
					if deceased ~= 1 then
						if thePed == theElement then
							randomAnimation = getRandomAnim( 1 )
						else
							randomAnimation = getRandomAnim( 2 )
						end
					else
						randomAnimation = getRandomAnim( 4 )
					end
					if randomAnimation then
						local anim1, anim2 = getPedAnimation(thePed)
						if randomAnimation[1] ~= anim1 or randomAnimation[2] ~= anim2 then
							setPedAnimation ( thePed , randomAnimation[1], randomAnimation[2], -1, true, false, false, false )
						end
					end
				end
			end
		end
	end
end

--- Character detail screen
local wDetailScreen, lDetailScreen, iCharacterImage, bPlayAs,cFadeOutTime = nil

function showCharacterGUI()
local side_labels = {}
	--if Characters_createDetailScreen() then
		if Dharma:dgsGetVisible(wDetailScreen) then
			destroyElement(wDetailScreen)
		end
		if (iCharacterImage ~= nil) then
			destroyElement(iCharacterImage)
		end
		
		local sw, sh = guiGetScreenSize()
	--[[
		Wnd = Dharma:dgsCreateWindow(0, 0-1, 1, 0.17, "", true, _, 8, _, tocolor(0,162,255, 200), _, tocolor(10, 10, 10, 255), _, true)
		Dharma:dgsWindowSetSizable (Wnd, false)
		Dharma:dgsWindowSetMovable (Wnd, false)
		Dharma:dgsMoveTo(Wnd,0,0,true,"Linear",2000) --Set Animation
		Dharma:dgsSetAlpha(Wnd,0)
		Dharma:dgsAlphaTo(Wnd,1,"Linear",2500)
	]]
		wDetailScreen = Dharma:dgsCreateWindow(0.74, 0.24, 0.25, 0.52, "", true, _, 1.5, _, tocolor(0,162,255, 200), _, tocolor(10, 10, 10, 255), _, true)
		Dharma:dgsWindowSetSizable (wDetailScreen, false)
		Dharma:dgsWindowSetMovable (wDetailScreen, false)
		--[[
		line = Dharma:dgsCreateLine(139, 22, 15, 98, false, wDetailScreen, 10, tocolor(255, 255, 255, 255))
		line1 = Dharma:dgsCreateLine(357, 22, 15, 98, false, wDetailScreen, 10, tocolor(255, 255, 255, 255))
		Dharma:dgsLineAddItem(line,0,100,0,0, 2, tocolor(200,200,200,255),false)
		Dharma:dgsLineAddItem(line1,0,100,0,0, 2, tocolor(200,200,200,255),false)
		]]
		
		--Dharma:dgsMoveTo(wDetailScreen,0,0,true,"Linear",2000) --Set Animation
		Dharma:dgsSetAlpha(wDetailScreen,0)
		Dharma:dgsAlphaTo(wDetailScreen,1,"Linear",1000)
		
		local skin = getElementModel(thePed)
		iCharacterImage = Dharma:dgsCreateImage(0.06, 0.04, 0.25, 0.21, ":account/img/" .. ("%03d"):format(skin) .. ".png", true, wDetailScreen) -- To be replaced to show char face.
		--logo = Dharma:dgsCreateImage(0.06, 0.04, 0.25, 0.21, ":account/login-panel/logo.png", true, wDetailScreen)
		
		--facLbl = Dharma:dgsCreateLabel(0.27, 0.70, 0.37, 0.15, "Faction: " .. getElementData(thePed, "account:charselect:faction"), true, wDetailScreen, tocolor(200, 200, 200, 255))
		
		--ageLbl = Dharma:dgsCreateLabel(0.27, 0.48, 0.37, 0.15, "Age: " .. tostring(getElementData(thePed, "account:charselect:age")), true, wDetailScreen, tocolor(200, 200, 200, 255))
		
		
		--Dharma:dgsSetProperty(facLbl, "font", robotoFont10)
		--Dharma:dgsSetProperty(ageLbl, "font", robotoFont10)
		--Dharma:dgsSetProperty(nameLbl, "font", robotoFont10)
		charName = Dharma:dgsCreateLabel(0.355, 0.04, 0.60, 0.11, getElementData(thePed,"account:charselect:name"):gsub("_", " "), true, wDetailScreen, tocolor(200, 200, 200, 255))
		Dharma:dgsSetProperty(charName,"font", FreesansBold14)
		Dharma:dgsLabelSetHorizontalAlign(charName, "center", false)
		Dharma:dgsLabelSetVerticalAlign(charName, "center")
		
		--[[
		local characterGender = getElementData(thePed, "account:charselect:gender")
		local characterGenderStr = "Female"
		if (characterGender == 0) then
			characterGenderStr = "Male"
		end]]

		--genderLbl = Dharma:dgsCreateLabel(0.34, 0.20, 0.23, 0.04, "Gender: ".. characterGenderStr, true, wDetailScreen, tocolor(200, 200, 200, 255))
		local characterStatus = getElementData(thePed, "account:charselect:cked")
		local characterStatusStr = "Dead"
		if (characterStatus ~= 1) then
			characterStatusStr = "Alive"
		end
		side_labels[1] = Dharma:dgsCreateLabel(0.38, 0.16, 0.19, 0.04, "USED AT: " --[[.. getElementData(thePed, "account:charselect:lastarea")]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[2] = Dharma:dgsCreateLabel(0.34, 0.20, 0.23, 0.04, "HOURS: " --[[.. characterStatusStr]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[3] = Dharma:dgsCreateLabel(0.34, 0.24, 0.23, 0.04, "STATUS: " --[[.. tostring(getElementData(thePed, "account:charselect:age"))]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[4] = Dharma:dgsCreateLabel(0.02, 0.33, 0.33, 0.04, "LOCATION: "--[[.. getElementData(thePed, "account:charselect:lastarea")]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[5] = Dharma:dgsCreateLabel(0.02, 0.38, 0.33, 0.04, "PROPERTIES(/"..getElementData(thePed, "account:charselect:maxints")--[[ .. getElementData(thePed, "account:charselect:factionrank") .. " - " .. getElementData(thePed, "account:charselect:faction")]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[6] = Dharma:dgsCreateLabel(0.02, 0.43, 0.33, 0.04, "VEHICLES(/"..getElementData(thePed, "account:charselect:maxvehs")--[[..monthNumberToName(getElementData(thePed, "account:charselect:month")).." "..getBetterDay(getElementData(thePed, "account:charselect:day"))..", "..getBirthday(getElementData(thePed, "account:charselect:age"))]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[7] = Dharma:dgsCreateLabel(0.02, 0.48, 0.33, 0.04, "FACTION: "--[[.. getElementData(thePed, "account:charselect:weight")]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[8] = Dharma:dgsCreateLabel(0.02, 0.53, 0.33, 0.04, "CASH IN HAND: "--[[.. getElementData(thePed, "account:charselect:height")]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[9] = Dharma:dgsCreateLabel(0.02, 0.58, 0.33, 0.04, "CASH IN BANK: "--[[.. jobName]], true, wDetailScreen, tocolor(200, 200, 200, 255))
		side_labels[10] = Dharma:dgsCreateLabel(0.02, 0.63, 0.33, 0.04, "CURRENT JOB: "--[[.. jobName]], true, wDetailScreen, tocolor(200, 200, 200, 255))

		local ii = 1
		while (ii <= 10) do
			Dharma:dgsSetProperty(side_labels[ii],"font", FreesansBold10)
			Dharma:dgsLabelSetHorizontalAlign(side_labels[ii], "right", false)
			ii = ii + 1
		end
		
		local money = exports.global:formatMoney(getElementData(thePed, "account:charselect:money"))
		local bankmoney = exports.global:formatMoney(getElementData(thePed, "account:charselect:bankmoney"))
		local job = getElementData(thePed, "account:charselect:job") or 0
		local jobName = exports["job-system"]:getJobTitleFromID(job)
		
		
		side_lastUsedLabel = Dharma:dgsCreateLabel(0.579, 0.162, 0.37, 0.04, getElementData(thePed, "account:charselect:lastlogin") or "01/01/2022 at 00:00", true, wDetailScreen, tocolor(0,162,255, 200))
		side_totalHoursLabel = Dharma:dgsCreateLabel(0.579, 0.202, 0.37, 0.04, getElementData(thePed, "account:charselect:hours").. " Hours" or "0 Hours", true, wDetailScreen, tocolor(0,162,255, 200))
		side_charStatusLabel = Dharma:dgsCreateLabel(0.579, 0.242, 0.37, 0.04, characterStatus or "Alive", true, wDetailScreen, tocolor(0,162,255, 200))

		side_currentLocLabel = Dharma:dgsCreateLabel(0.366, 0.332, 0.58, 0.04, getElementData(thePed, "account:charselect:lastarea") or "Unknown.", true, wDetailScreen, tocolor(0,162,255, 200))
		side_PropertiesLabel = Dharma:dgsCreateLabel(0.366, 0.382, 0.58, 0.04, "None.", true, wDetailScreen, tocolor(0,162,255, 200))
		side_vehiclesLabel = Dharma:dgsCreateLabel(0.366, 0.432, 0.58, 0.04, "None.", true, wDetailScreen, tocolor(0,162,255, 200))
		side_factionsLabel = Dharma:dgsCreateLabel(0.366, 0.482, 0.58, 0.04, getElementData(thePed, "account:charselect:faction") or "None.", true, wDetailScreen, tocolor(0,162,255, 200))
		side_cashInHandLabel = Dharma:dgsCreateLabel(0.366, 0.532, 0.58, 0.04, "$"..money or "$0", true, wDetailScreen, tocolor(0,162,255, 200))
		side_cashInBankLabel = Dharma:dgsCreateLabel(0.366, 0.582, 0.58, 0.04, "$"..bankmoney or "$0", true, wDetailScreen, tocolor(0,162,255, 200))
		side_currentJobLabel = Dharma:dgsCreateLabel(0.366, 0.632, 0.58, 0.04, jobName or "Unemployed.", true, wDetailScreen, tocolor(0,162,255, 200))

		Dharma:dgsSetProperty(side_lastUsedLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_totalHoursLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_charStatusLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_currentLocLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_PropertiesLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_vehiclesLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_factionsLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_cashInHandLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_cashInBankLabel,"font", robotoFont10)
		Dharma:dgsSetProperty(side_currentJobLabel,"font", robotoFont10)
	
		bMoreInfo = Dharma:dgsCreateButton(0.64, 0.79, 0.29, 0.14, "INFO", true, wDetailScreen, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)--Dharma:dgsCreateButton(0.06, 0.79, 0.53, 0.14, "PLAY AS N/A", true, wDetailScreen, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(238, 33, 73, 100), tocolor(238, 33, 73, 200), tocolor(238, 33, 73, 255))
		Dharma:dgsSetProperty(bMoreInfo, "font", robotoFont10)
		addEventHandler("onDgsMouseClickDown", bMoreInfo, sideGUI_charInfoButtonClick, false)
		bPlayAs = Dharma:dgsCreateButton(0.06, 0.79, 0.53, 0.14, "SELECT CHARACTER", true, wDetailScreen, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)--Dharma:dgsCreateButton(0.06, 0.79, 0.53, 0.14, "PLAY AS N/A", true, wDetailScreen, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(238, 33, 73, 100), tocolor(238, 33, 73, 200), tocolor(238, 33, 73, 255))
		Dharma:dgsSetProperty(bPlayAs, "font", robotoFont10)
		addEventHandler("onDgsMouseClickDown", bPlayAs, Characters_selectCharacter, false)
		if getElementData(thePed, "account:charselect:cked") == 1 then
			Dharma:dgsSetEnabled(bPlayAs, false)
		else
			Dharma:dgsSetEnabled(bPlayAs, true)
		end
	--end  
end

--238,33,73
--#ee2149

function Characters_deactivateGUI()
	if isElement(bPlayAs) then
		Dharma:dgsSetEnabled(bPlayAs, false)
		Dharma:dgsSetEnabled(wDetailScreen, false)
		Dharma:dgsSetEnabled( newCharacterButton, false )
		Dharma:dgsSetEnabled( bLogout, false )
		Dharma:dgsSetEnabled( accountRefreshButton, false )
		Dharma:dgsSetEnabled( accountHistoryButton, false )
		Dharma:dgsSetEnabled( Wnd, false )
        fixClose()

	end
	removeEventHandler("onClientRender", getRootElement(), renderNametags)
	removeEventHandler("onClientClick", getRootElement(), Characters_onClientClick)
end

function Characters_selectCharacter()
		Characters_deactivateGUI()
		local randomAnimation = getRandomAnim(3)
		setPedAnimation ( characterElementSelected, randomAnimation[1], randomAnimation[2], -1, true, false, false, false )
		Dharma:dgsSetText ( playas, "Wait.." )
		--setElementData(getLocalPlayer(), "fishing", false)
		cFadeOutTime = 254
		addEventHandler("onClientRender", getRootElement(), Characters_FadeOut)
		fadeCamera ( false, 1, 0,0,0 )
		setTimer(function()
			triggerServerEvent("accounts:characters:spawn", getLocalPlayer(), getElementData(thePed, "account:charselect:id"))
		end, 1000,1)
end

function Characters_FadeOut()
	cFadeOutTime = cFadeOutTime -3
	if (cFadeOutTime <= 0) then
		removeEventHandler("onClientRender", getRootElement(), Characters_FadeOut)
		--removeEventHandler("onClientRender", getRootElement(), logo)
		destroyElement(material)
	else
		for _, thePed in ipairs(pedTable) do
			if isElement(thePed) and (thePed ~= characterElementSelected) then
				setElementAlpha(thePed, cFadeOutTime)
			end
		end
	end
end

function characters_destroyDetailScreen()
	lDetailScreen = { }
	if isElement(wDetailScreen) then
		destroyElement(iCharacterImage)
		destroyElement(bPlayAs)
		destroyElement(wDetailScreen)
		destroyElement(charInfoGUI)
        fixClose()
		iCharacterImage = nil
		iPlayAs = nil
		wDetailScreen = nil

	end
	for _, thePed in ipairs(pedTable) do
		if isElement(thePed) then
			destroyElement(thePed)
		end
	end
	pedTable = { }
	cFadeOutTime = 0
	if isElement(newCharacterButton) then
		destroyElement( newCharacterButton )
		fixClose()
	end
	if isElement(bLogout) then
		destroyElement( bLogout )
	end
end
--- End character detail screen

function characters_onSpawn(fixedName, adminLevel, gmLevel, factionID, factionRank)
	clearChat()
	showChat(true)
	Dharma:dgsSetInputEnabled(false)
	showCursor(false)
	--outputChatBox("You are now playing as '" .. fixedName .. "'.", 0, 255, 0)
	outputChatBox("Need Help? /helpme", 255, 194, 14)
	outputChatBox("You can visit the Options menu by pressing 'F10' or /home.", 255, 194, 15)
	outputChatBox(" ")
	characters_destroyDetailScreen()
	setElementData(getLocalPlayer(), "admin_level", adminLevel, false)
	setElementData(getLocalPlayer(), "account:gmlevel", gmLevel, false)
	setElementData(getLocalPlayer(), "faction", factionID, false)
	setElementData(getLocalPlayer(), "factionrank", factionrank, false)

	-- Adams
	local dbid = getElementDimension(localPlayer)
	triggerServerEvent("frames:loadInteriorTextures", getLocalPlayer(), dbid)
	options_enable()
	--Stop bgMusic + spawning sound fx / maxime
	local bgMusic = getElementData(localPlayer, "bgMusic")
	if bgMusic and isElement(bgMusic) then
		setTimer(startSoundFadeOut, 2000, 1, bgMusic, 100, 30, 0.04, "bgMusic")
	end
	local selectionSound = getElementData(localPlayer, "selectionSound")
	if selectionSound and isElement(selectionSound) then
		destroyElement(selectionSound)
		bgMusic = nil
	end
	--[[
	setTimer(function ()
		local spawnCharSound = playSound("spawn_char.mp3")
		setSoundVolume(spawnCharSound, 0.3)
	end, 2000, 1)
	--]]
end
addEventHandler("accounts:characters:spawn", getRootElement(), characters_onSpawn)

function soundFadeOut(sound, decrease, dataKey)
	if sound and isElement(sound) then
		local oldVol = getSoundVolume(sound)
		if oldVol <= 0 then
			if soundFadeTimer and isElement(soundFadeTimer) then
				killTimer(soundFadeTimer)
				soundFadeTimer = nil
			end
			destroyElement(sound)
			if dataKey then
				setElementData(localPlayer, dataKey, false)
			end
		else
			if not decrease then decrease = 0.05 end
			local newVol = oldVol - decrease
			setSoundVolume(sound, newVol)
		end
	end
end
function startSoundFadeOut(sound, timeInterval, timesToExecute, decrease, dataKey)
	if not sound or not isElement(sound) then return false end
	if not tonumber(timeInterval) then timeInterval = 100 end
	if not tonumber(timesToExecute) then timesToExecute = 30 end
	if not tonumber(decrease) then decrease = 0.05 end
	soundFadeTimer = setTimer(soundFadeOut, timeInterval, timesToExecute, sound, decrease, dataKey)
	setTimer(forceStopSound, 4000, 1, sound, dataKey)
end
function forceStopSound(sound, dataKey)
	if sound and isElement(sound) then
		destroyElement(sound)
		if dataKey then
			setElementData(localPlayer, dataKey, false)
		end		
	end
end

function check_char()
local char_ = getElementData(getLocalPlayer(), "account:characters")
if #char_ == 0 then
	setTimer(function ()
		makeFirstChar()
		end, 6000, 1)
	end
end

function makeFirstChar()
			noCharactersGUI = Dharma:dgsCreateWindow(0.22, 0.36, 0.55, 0.34, "", true, _, 0, _, _, _, tocolor(10, 10, 10, 255), _, true)
		    Dharma:dgsWindowSetSizable (noCharactersGUI, false)
		    Dharma:dgsWindowSetMovable (noCharactersGUI, false)
			noCharactersGUILabel = Dharma:dgsCreateLabel(0.18, 0.12, 0.54, 0.13, "YOU HAVE NO CHARACTERS!", true, noCharactersGUI, tocolor(200, 200, 200, 255))
			Dharma:dgsSetFont(noCharactersGUILabel, upfont)
			noCharactersGUILabl2 = Dharma:dgsCreateLabel(0.13, 0.32, 0.75, 0.24, "First things first, we need to get you set up with your own character! Characters are your unique playable civilians of Los Santos.\nYou choose their past, roleplay out their present and see what adventures hold for them in their future!\n\nOnce you create a character, they cannot be deleted and are permanent. You can only have up to 15 characters so be wise with\nyour available slots!", true, noCharactersGUI, tocolor(200, 200, 200, 255))
			Dharma:dgsLabelSetHorizontalAlign(noCharactersGUILabl2, "center")
			Dharma:dgsSetFont(noCharactersGUILabl2, fontnoChar)
			createFirstCharButton = Dharma:dgsCreateButton(0.35, 0.63, 0.30, 0.27, "CREATE FIRST CHARACTER", true, noCharactersGUI, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)--Dharma:dgsCreateButton(0.35, 0.63, 0.30, 0.27, "CREATE FIRST CHARACTER", true, noCharactersGUI, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(238, 33, 73, 100), tocolor(238, 33, 73, 200), tocolor(238, 33, 73, 255))
			addEventHandler("onDgsMouseClickUp", createFirstCharButton, Characters_newCharacter, false)
			Dharma:dgsSetFont(createFirstCharButton, font)
			fixClose()
end

function Characters_newCharacter()
	Characters_deactivateGUI()
	characters_destroyDetailScreen()
	newCharacter_init()
	fixClose()
	Dharma:dgsSetVisible(noCharactersGUI, false)
	Dharma:dgsSetVisible(createFirstCharButton, false)
	Dharma:dgsSetVisible(charInfoGUI, false)
	Dharma:dgsSetEnabled(createFirstCharButton, false)
end

function playerLogout()
	Characters_deactivateGUI()
	characters_destroyDetailScreen()
	for _, thePed in ipairs(pedTable) do
		destroyElement(thePed, 0)
	end
end

function Refresh()
	Characters_deactivateGUI()
	characters_destroyDetailScreen()
	Characters_showSelection()
	fixClose()
end

function History()
	triggerServerEvent("showAdminHistory", root, localPlayer)
	playSoundFrontEnd ( 4 )
end

function fixClose()
Dharma:dgsSetVisible(Wnd, false)
Dharma:dgsSetVisible(accountHistoryButton, false)
Dharma:dgsSetVisible(accountRefreshButton, false)
destroyElement(material)
end

--Character Info--
function character_CharInfoOpen()
	local charInfoGUILabels = {}
	--local Characters = getElementData(getLocalPlayer(), "account:characters")
	--wDetailScreen = Dharma:dgsCreateWindow(0.74, 0.24, 0.25, 0.52, "", true, _, 1.5, _, tocolor(0,162,255, 200), _, tocolor(10, 10, 10, 255), _, true)
	charInfoGUI = Dharma:dgsCreateWindow(0.49, 0.24, 0.25, 0.52, "", true, _, 1.5, _, tocolor(0,162,255, 200), _, tocolor(10, 10, 10, 255), _, true)
	Dharma:dgsWindowSetSizable (charInfoGUI, false)
	Dharma:dgsWindowSetMovable (charInfoGUI, false)
	Dharma:dgsSetAlpha(charInfoGUI, 0)
	Dharma:dgsAlphaTo(charInfoGUI, 1,"Linear", 1000)
	--gender--
	local characterGender = getElementData(thePed, "account:charselect:gender")
	local characterGenderStr = "Female"
	if (characterGender == 0) then
		characterGenderStr = "Male"
	end
	--ethnicity--
	local charEthnicity = getElementData(thePed, "account:charselect:ethnicity")
	local charEthnicityStr = "Black"
	if (charEthnicity == 1) then
		charEthnicityStr = "White"
	elseif (charEthnicity == 2) then
		charEthnicityStr = "Asian"
	end
	--fightstyle--
	local charFightstyle = getElementData(thePed, "account:charselect:fightstyle")
	if tonumber(charFightstyle) then
		if (charFightstyle == 4) then charFightstyle = "Normal"
			elseif (charFightstyle == 5) then charFightstyle = "Boxing"
			elseif (charFightstyle == 6) then charFightstyle = "Kung Fu"
			elseif (charFightstyle == 7) then charFightstyle = "Kneehead"
			elseif (charFightstyle == 15) then charFightstyle = "Grab Kick"
			elseif (charFightstyle == 16) then charFightstyle = "Elbow Fighting"
			else charFightstyle = "Unknown"
		end
	end
	--languages--
	local language = getElementData(thePed, "account:charselect:lang1")
	local language2 = getElementData(thePed, "account:charselect:lang2")
	local language3 = getElementData(thePed, "account:charselect:lang3")
	
	local charLanguageString
		
	if (language ~= 0) then
		local lang = exports['language-system']:getLanguageName(language)
		charLanguageString = lang
	end

	if (language2 ~= 0) then
		lang = exports['language-system']:getLanguageName(language2)
		charLanguageString = charLanguageString .. ", " .. lang
	end

	if (language3 ~= 0) then
		lang = exports['language-system']:getLanguageName(language3)
		charLanguageString = charLanguageString .. ", " .. lang
	end
	--licenses--
	
	local parsedLicenses = {}
	
	parsedLicenses[1] = getElementData(thePed, "account:charselect:carlicense") or "None"
	parsedLicenses[2] = getElementData(thePed, "account:charselect:bikelicense") or "None"
	parsedLicenses[3] = getElementData(thePed, "account:charselect:pilotlicense") or "None"
	parsedLicenses[4] = getElementData(thePed, "account:charselect:fishlicense") or "None"
	parsedLicenses[5] = getElementData(thePed, "account:charselect:boatlicense") or "None"
	parsedLicenses[6] = getElementData(thePed, "account:charselect:gunlicense") or "None"
	parsedLicenses[7] = getElementData(thePed, "account:charselect:gun2license") or "None"
	
	--local parsedLicenses = split(charLicenses, ",")
	local hasLicense = false

	for i, license in ipairs(parsedLicenses) do
		if tonumber(parsedLicenses[i]) == 1 then
			hasLicense = true
		end
	end

	local charLicenseString
	
	if hasLicense then
		local c = false
		if (tonumber(parsedLicenses[1]) == 1) then
			charLicenseString = "Motorvehicle"
			c = true
		end
		if (tonumber(parsedLicenses[2]) == 1) then
			if (c) then
				charLicenseString = charLicenseString .. ", Bike"
				c = true
			else
				charLicenseString = "Bike"
			end
		end
		if (tonumber(parsedLicenses[3]) == 1) then
			if (c) then
				charLicenseString = charLicenseString .. ", Pilot"
				c = true
			else
				charLicenseString = "Pilot"
			end
		end
		if (tonumber(parsedLicenses[4]) == 1) then
			if (c) then
				charLicenseString = charLicenseString .. ", Fish"
				c = true
			else
				charLicenseString = "Fish"
			end
		end
		if (tonumber(parsedLicenses[5]) == 1) then
			if (c) then
				charLicenseString = charLicenseString .. ", Boat"
				c = true
			else
				charLicenseString = "Boat"
			end
		end
		if (tonumber(parsedLicenses[6]) == 1) then
			if (c) then
				charLicenseString = charLicenseString .. ", Gun"
				c = true
			else
				charLicenseString = "Gun"
			end
		end
		if (tonumber(parsedLicenses[7]) == 1) then
			if (c) then
				charLicenseString = charLicenseString .. ", Gun2"
				c = true
			else
				charLicenseString = "Gun2"
			end
		end
		if (#charLicenseString > 42) then
			charLicenseString = "All Licenses."
		end
	else
		charLicenseString = "None."
	end
		
	charInfoGUILabels[1] = Dharma:dgsCreateLabel(0.11, 0.06, 0.82, 0.07, "CHARACTER INFORMATION", true, charInfoGUI)
	charInfoGUILabels[2] = Dharma:dgsCreateLabel(0.09, 0.23, 0.16, 0.03, "ETHNICITY: ", true, charInfoGUI)
	charInfoGUILabels[3] = Dharma:dgsCreateLabel(0.11, 0.28, 0.14, 0.03, "GENDER: " , true, charInfoGUI)
	charInfoGUILabels[4] = Dharma:dgsCreateLabel(0.11, 0.33, 0.14, 0.03, "WEIGHT: ", true, charInfoGUI)
	charInfoGUILabels[5] = Dharma:dgsCreateLabel(0.11, 0.38, 0.14, 0.03, "HEIGHT: ", true, charInfoGUI)

	charInfoGUILabels[6] = Dharma:dgsCreateLabel(0.57, 0.23, 0.16, 0.03, "DIMENSION:", true, charInfoGUI)
	charInfoGUILabels[7] = Dharma:dgsCreateLabel(0.57, 0.28, 0.16, 0.03, "INTERIOR:", true, charInfoGUI)
	charInfoGUILabels[8] = Dharma:dgsCreateLabel(0.55, 0.33, 0.19, 0.03, "FIGHTSTYLE:", true, charInfoGUI)
	charInfoGUILabels[9] = Dharma:dgsCreateLabel(0.57, 0.38, 0.16, 0.03, "SKIN:", true, charInfoGUI)

	charInfoGUILabels[10] = Dharma:dgsCreateLabel(0.05, 0.47, 0.27, 0.03, "Faction Rank:", true, charInfoGUI)
	charInfoGUILabels[11] = Dharma:dgsCreateLabel(0.05, 0.51, 0.27, 0.03, "LANGUAGES:", true, charInfoGUI)
	charInfoGUILabels[12] = Dharma:dgsCreateLabel(0.05, 0.55, 0.27, 0.03, "LICENSES:", true, charInfoGUI)
	
	charInfoGUILabels[13] = Dharma:dgsCreateLabel(0.15, 0.65, 0.36, 0.04, "CHARACTER STORY", true, charInfoGUI)
	--[[
	charInfoGUILabels[14] = Dharma:dgsCreateLabel(0.05, 0.708, 0.23, 0.03, "STRENGTH", true, charInfoGUI)
	charInfoGUILabels[15] = Dharma:dgsCreateLabel(0.05, 0.748, 0.23, 0.03, "MARKSMANSHIP", true, charInfoGUI)
	charInfoGUILabels[16] = Dharma:dgsCreateLabel(0.05, 0.787, 0.23, 0.03, "MECHANICS", true, charInfoGUI)
	charInfoGUILabels[17] = Dharma:dgsCreateLabel(0.05, 0.827, 0.23, 0.03, "KNOWLEDGE", true, charInfoGUI)
	charInfoGUILabels[18] = Dharma:dgsCreateLabel(0.05, 0.866, 0.23, 0.03, "STAMINA", true, charInfoGUI)
	]]
	charInfoSubLabel = Dharma:dgsCreateLabel(0.05, 0.13, 0.90, 0.04, "#0770C4"..getElementData(thePed,"account:charselect:name"):gsub("_", " ") .. "#FFFFFF created on #0770C4" .. getElementData(thePed,"account:charselect:creationdate"), true, charInfoGUI)
	
	for i, v in ipairs(charInfoGUILabels) do
		Dharma:dgsLabelSetHorizontalAlign(charInfoGUILabels[i], "right")
		Dharma:dgsSetProperty(charInfoGUILabels[i], "font", FreesansBold10)
	end
	
		Dharma:dgsSetProperty(charInfoGUILabels[1],"font", FreesansBold14)
		Dharma:dgsLabelSetHorizontalAlign(charInfoGUILabels[1], "center", false)
			
		Dharma:dgsSetProperty(charInfoGUILabels[13],"font", FreesansBold14)
		Dharma:dgsLabelSetHorizontalAlign(charInfoGUILabels[13], "left", false)
		
		Dharma:dgsSetProperty(charInfoSubLabel,"font", FreesansBold10)
		Dharma:dgsLabelSetHorizontalAlign(charInfoSubLabel, "center", false)
		Dharma:dgsSetProperty(charInfoSubLabel,"colorCoded", true)
	
	infoEthnicityLabel = Dharma:dgsCreateLabel(0.26, 0.231, 0.27, 0.03, charEthnicityStr, true, charInfoGUI, tocolor(0,162,255, 200))
	infoGenderLabel = Dharma:dgsCreateLabel(0.26, 0.2815, 0.27, 0.03, characterGenderStr, true, charInfoGUI, tocolor(0,162,255, 200))
	infoWeightLabel = Dharma:dgsCreateLabel(0.26, 0.332, 0.27, 0.03, getElementData(thePed, "account:charselect:weight") .. "kg", true, charInfoGUI, tocolor(0,162,255, 200))
	infoHeightLabel = Dharma:dgsCreateLabel(0.26, 0.383, 0.27, 0.03, getElementData(thePed, "account:charselect:height") .. "cm", true, charInfoGUI, tocolor(0,162,255, 200))
	
	infoDimensionLabel = Dharma:dgsCreateLabel(0.74, 0.232, 0.27, 0.03, getElementData(thePed, "account:charselect:dimension"), true, charInfoGUI, tocolor(0,162,255, 200))
	infoInteriorLabel = Dharma:dgsCreateLabel(0.74, 0.282, 0.27, 0.03, getElementData(thePed, "account:charselect:interior"), true, charInfoGUI, tocolor(0,162,255, 200))
	infoFightStyleLabel = Dharma:dgsCreateLabel(0.74, 0.332, 0.27, 0.03, charFightstyle, true, charInfoGUI, tocolor(0,162,255, 200))
	infoSkinLabel = Dharma:dgsCreateLabel(0.74, 0.3836, 0.27, 0.03, "ID " .. getElementData(thePed, "account:charselect:skin"), true, charInfoGUI, tocolor(0,162,255, 200))
	
	infoFacRankLabel = Dharma:dgsCreateLabel(0.33, 0.472, 0.60, 0.03, getElementData(thePed, "account:charselect:factionrank"), true, charInfoGUI, tocolor(0,162,255, 200))
	infoLanguagesLabel = Dharma:dgsCreateLabel(0.33, 0.512, 0.60, 0.03, charLanguageString, true, charInfoGUI, tocolor(0,162,255, 200))
	infoLicensesLabel = Dharma:dgsCreateLabel(0.33, 0.551, 0.60, 0.03, charLicenseString, true, charInfoGUI, tocolor(0,162,255, 200))
	
	descMemo = Dharma:dgsCreateMemo(0.02, 0.75, 0.96, 0.23, getElementData(thePed, "account:charselect:description"), true, charInfoGUI, _, _, _, _, tocolor(15, 15, 15, 255))
	
	Dharma:dgsSetProperty(infoEthnicityLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoGenderLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoWeightLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoHeightLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoDimensionLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoInteriorLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoFightStyleLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoSkinLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoFacRankLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoLanguagesLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(infoLicensesLabel, "font", FreesansBold10)
	Dharma:dgsSetProperty(descMemo, "font", FreesansBold10)
	
	Dharma:dgsMemoSetReadOnly(descMemo, true)
	
end

function sideGUI_charInfoButtonClick(button, state)
	--if (button == "left") and (state == "down") then
		if (Dharma:dgsGetVisible(charInfoGUI) == true) then
			Dharma:dgsSetVisible(charInfoGUI, false)
		else
			--local charid = highlightedPedID
			character_CharInfoOpen()
		end
	--end
end