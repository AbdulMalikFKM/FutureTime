local gui = {}
local curskin = 1
local dummyPed = nil
local languageselected = 1
local selectedMonth1 = "January"
local scrDay = 1
local logoTexture = dxCreateTexture(":account/login-panel/logo.png")
local logoSize = 128 * (1 / 75)
--DGS1 = exports['dgs-master1']
local DGS1 = exports['dgs-master']
font_12 = DGS1:dgsCreateFont(":account/login-panel/DIN-NEXT-LT-W23-REGULAR.TTF", 12)
font_16 = DGS1:dgsCreateFont(":account/login-panel/DIN-NEXT-LT-W23-REGULAR.TTF", 16)
font_28 = DGS1:dgsCreateFont(":account/login-panel/DIN-NEXT-LT-W23-REGULAR.TTF", 36)
function newCharacter_init()
	guiSetInputEnabled(true)
	--setCameraInterior(14)
	--setCameraMatrix(254.7190,  -41.1370,  1002, 256.7190,  -41.1370,  1002 )
	--setCameraMatrix(1145.1398925781, -1150.4985351562, 27.457765579224+5, 1145.1910400391, -1236.7550048828, -23.136978149414 )
	dummyPed = createPed(217, 1142.162109375, -1156.7587890625, 23.828125)
	setElementInterior(dummyPed, 0)
	setElementInterior(getLocalPlayer(), 0)
	setPedRotation(dummyPed, 357)
	setElementDimension(dummyPed, 70)
	setElementDimension(localPlayer, 70)
	fadeCamera ( true , 1, 0,0,0 )
	local screenX, screenY = guiGetScreenSize()
	rndRect = DGS1:dgsCreateRoundRect(30, false,tocolor(25,25,25,255))  
	btnRect = DGS1:dgsCreateRoundRect(15, false, tocolor(40,39,41,255))  
	btnRecthov = DGS1:dgsCreateRoundRect(15, false, tocolor(255, 51, 51, 200))  
	btnRectClick = DGS1:dgsCreateRoundRect(15, false, tocolor(255, 51, 51, 255))
	btnRect = DGS1:dgsCreateRoundRect(15, false, tocolor(40,39,41,255))  
	btnRecthov = DGS1:dgsCreateRoundRect(15, false, tocolor(255, 51, 51, 200))  
	btnRectClick = DGS1:dgsCreateRoundRect(15, false, tocolor(255, 51, 51, 255))
	addEventHandler("onClientRender", getRootElement(), groundLogo)
	gui["_root"] = DGS1:dgsCreateImage(10, screenY/2-225, 255, 478,rndRect,false)--DGS1:dgsCreateWindow(10, screenY/2-225, 255, 478, "Create Character", false, tocolor(200, 200, 200, 255), _, ":account/login-panel/up.png", tocolor(255, 255, 255, 255), _, _, _, true)
	--DGS1:dgsWindowSetSizable(gui["_root"], false)
	--DGS1:dgsWindowSetMovable(gui["_root"], false)
	--DGS1:dgsSetFont(gui["_root"], font_12)
	gui["lblCharName"] = DGS1:dgsCreateLabel(10, 25, 91, 16, "Name:", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblCharName"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblCharName"], "center")
    DGS1:dgsSetFont(gui["_root"], font_12)
	gui["txtCharName"] = DGS1:dgsCreateEdit(60, 24, 180, 22, "", false, gui["_root"], _, _, _, _, tocolor(50, 55, 60, 255))
	DGS1:dgsEditSetMaxLength(gui["txtCharName"], 32767)

	gui["lblCharNameExplanation"] = DGS1:dgsCreateLabel(10, 46, 240, 80,"This needs to be in the following format: \n     Firstname Lastname\nFor example: Taylor Jackson.\nYou are not allowed to use famous names.", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblCharNameExplanation"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblCharNameExplanation"], "center")
    DGS1:dgsSetFont(gui["lblCharNameExplanation"], font_12)
	
	gui["lblGender"] = DGS1:dgsCreateLabel(10, 160, 46, 13, "Gender:", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblGender"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblGender"], "center")
	DGS1:dgsSetFont(gui["lblGender"], font_12)
	gui["rbMale"] = DGS1:dgsCreateRadioButton(90, 160, 51, 13, "Male", false, gui["_root"], tocolor(200, 200, 200, 255))
	gui["rbFemale"] = DGS1:dgsCreateRadioButton(150, 160, 82, 13, "Female", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsSetFont(gui["rbMale"], font_12)
	DGS1:dgsSetFont(gui["rbFemale"], font_12)
	DGS1:dgsRadioButtonSetSelected ( gui["rbMale"], true)
	addEventHandler("onDgsMouseClickDown", gui["rbMale"], newCharacter_updateGender, false)
	addEventHandler("onDgsMouseClickDown", gui["rbFemale"], newCharacter_updateGender, false)

	gui["lblSkin"] = DGS1:dgsCreateLabel(10, 180, 80, 16, "Skin:", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblSkin"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblSkin"], "center")
	DGS1:dgsSetFont(gui["lblSkin"], font_12)
--[[
	gui["btnPrevSkin"] = DGS1:dgsCreateButton(50, 180, 80, 16, "Previous", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick) DGS1:dgsCreateButton(50, 180, 80, 16, "Previous", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClickDown", gui["btnPrevSkin"], newCharacter_updateGender, false)
	DGS1:dgsSetFont(gui["btnPrevSkin"], font_12)
	gui["btnNextSkin"] = DGS1:dgsCreateButton(150, 180, 80, 16, "Next", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)  DGS1:dgsCreateButton(150, 180, 80, 16, "Next", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClickDown", gui["btnNextSkin"], newCharacter_updateGender, false)
	DGS1:dgsSetFont(gui["btnNextSkin"], font_12)
	]]
	local color = tocolor(0,162,255, 175)
	local hovercolor = tocolor(0,162,255, 225)
	local clickcolor = tocolor(0,162,255, 255)
	local x, y, z = 1142.162109375, -1156.7587890625, 23.828125
	material = DGS1:dgsCreate3DInterface(x, y - 0.3, z,2,2,400,400,tocolor(255,255,255,255),0, 1, 0)
	DGS1:dgs3DInterfaceSetDimension(material, 70)
	gui["btnPrevSkin"] = DGS1:dgsCreateButton(50,200,30,30,"<",false,material,tocolor(255,255,255,255), 1,1,nil,nil,nil, color ,hovercolor, clickcolor)
	addEventHandler("onDgsMouseClickDown", gui["btnPrevSkin"], newCharacter_updateGender, false)
	DGS1:dgsSetFont(gui["btnPrevSkin"], font_12)
	gui["btnNextSkin"] = DGS1:dgsCreateButton(350,200,30,30,">",false,material,tocolor(255,255,255,255), 1,1,nil,nil,nil, color ,hovercolor, clickcolor)
	addEventHandler("onDgsMouseClickDown", gui["btnNextSkin"], newCharacter_updateGender, false)
	DGS1:dgsSetFont(gui["btnNextSkin"], font_12)
		--[[DGS:dgsSetAlpha(leftBtn,0)
		DGS:dgsAlphaTo(leftBtn,1,"Linear",500)
		DGS:dgsSetAlpha(rightBtn,0)
		DGS:dgsAlphaTo(rightBtn,1,"Linear",500)]]
	
	gui["lblRace"] = DGS1:dgsCreateLabel(10, 140, 111, 16, "Race:", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblRace"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblRace"], "center")
    DGS1:dgsSetFont(gui["lblRace"], font_12)
	
	gui["chkBlack"] =  DGS1:dgsCreateCheckBox ( 60, 140, 55, 16, "Black", true, false, gui["_root"], tocolor(200, 200, 200, 255) )
	DGS1:dgsSetFont(gui["chkBlack"], font_12)
	addEventHandler("onDgsMouseClickDown", gui["chkBlack"] , newCharacter_raceFix, false)
	gui["chkWhite"] =  DGS1:dgsCreateCheckBox ( 120, 140, 55, 16, "White", false, false, gui["_root"], tocolor(200, 200, 200, 255) )
	DGS1:dgsSetFont(gui["chkWhite"], font_12)
	addEventHandler("onDgsMouseClickDown", gui["chkWhite"] , newCharacter_raceFix, false)
	gui["chkAsian"] =  DGS1:dgsCreateCheckBox ( 180, 140, 55, 16, "Asian", false, false, gui["_root"], tocolor(200, 200, 200, 255) )
	DGS1:dgsSetFont(gui["chkAsian"], font_12)
	addEventHandler("onDgsMouseClickDown", gui["chkAsian"] , newCharacter_raceFix, false)

	gui["lblHeight"] = DGS1:dgsCreateLabel(10, 200, 111, 16, "Height", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblHeight"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblHeight"], "center")
	DGS1:dgsSetFont(gui["lblHeight"], font_12)

	gui["scrHeight"] =  DGS1:dgsCreateScrollBar ( 110, 200, 130, 16, true, false, gui["_root"], _, _, _,  tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255), tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsElementScroll", gui["scrHeight"], newCharacter_updateScrollBars, false)
	DGS1:dgsSetProperty(gui["scrHeight"], "StepSize", "0.02")

	gui["lblWeight"] = DGS1:dgsCreateLabel(10, 220, 111, 16, "Weight", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblWeight"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblWeight"], "center")
    DGS1:dgsSetFont(gui["lblWeight"], font_12)
	
	gui["scrWeight"] =  DGS1:dgsCreateScrollBar ( 110, 220, 130, 16, true, false, gui["_root"], _, _, _,  tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255), tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsElementScroll", gui["scrWeight"], newCharacter_updateScrollBars, false)
	DGS1:dgsSetProperty(gui["scrWeight"], "StepSize", "0.01")

	gui["lblAge"] = DGS1:dgsCreateLabel(10, 240, 111, 16, "Age", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, _,  tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255), tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblAge"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblAge"], "center")
	DGS1:dgsSetFont(gui["lblAge"], font_12)
	
	gui["scrAge"] =  DGS1:dgsCreateScrollBar ( 110, 240, 130, 16, true, false, gui["_root"], _, _, _,  tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255), tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsElementScroll", gui["scrAge"], newCharacter_updateScrollBars, false)
	DGS1:dgsSetProperty(gui["scrAge"], "StepSize", "0.0120")

	gui["lblDay"] = DGS1:dgsCreateLabel(10, 282, 111, 16, "Day of birth:", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblDay"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblDay"], "center")
    DGS1:dgsSetFont(gui["lblDay"], font_12)
	
	gui["scrDay"] =  DGS1:dgsCreateScrollBar ( 110, 285, 130, 16, true, false, gui["_root"], _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255), tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsElementScroll", gui["scrDay"], newCharacter_updateScrollBars, false)
	DGS1:dgsSetProperty(gui["scrDay"], "StepSize", "0.0125")

	gui["lblMonth"] = DGS1:dgsCreateLabel(10, 260, 111, 16, "Month of birth", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblDay"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblDay"], "center")
    DGS1:dgsSetFont(gui["lblMonth"], font_12)
	
	gui["drpMonth"] =  DGS1:dgsCreateComboBox ( 110, 260, 130, 16, "January", false, gui["_root"], _, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	DGS1:dgsSetFont(gui["drpMonth"], font_12)
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "January")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "February")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "March")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "April")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "May")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "June")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "July")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "August")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "September")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "October")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "November")
	DGS1:dgsComboBoxAddItem(gui["drpMonth"], "December")

	addEventHandler ( "onDgsComboBoxSelect", root,
		function ( comboBox )
			if ( comboBox == gui["drpMonth"] ) then
				local item = DGS1:dgsComboBoxGetSelected ( gui["drpMonth"] )
				selectedMonth1 = tostring ( DGS1:dgsComboBoxGetItemText ( gui["drpMonth"] , item ) )
			end
		end, true)



	gui["lblLanguage"] = DGS1:dgsCreateLabel(10, 330, 111, 16, "Language:", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblLanguage"], "left", false)
	DGS1:dgsLabelSetVerticalAlign(gui["lblLanguage"], "center")
	DGS1:dgsSetFont(gui["lblLanguage"], font_12)

	gui["btnLanguagePrev"] = --[[DGS1:dgsCreateButton(110, 330, 16, 16, "<", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)]]DGS1:dgsCreateButton(110, 330, 16, 16, "<", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	gui["lblLanguageDisplay"] = DGS1:dgsCreateLabel(126, 330, 98, 16, "English", false, gui["_root"], tocolor(200, 200, 200, 255))
	DGS1:dgsLabelSetHorizontalAlign(gui["lblLanguageDisplay"], "center", true)
	DGS1:dgsLabelSetVerticalAlign(gui["lblLanguageDisplay"], "center", true)
	DGS1:dgsSetFont(gui["btnLanguagePrev"], font_12)
	DGS1:dgsSetFont(gui["lblLanguageDisplay"], font_12)

	gui["btnLanguageNext"] = --[[DGS1:dgsCreateButton(224, 330, 16, 16, ">", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)]]DGS1:dgsCreateButton(224, 330, 16, 16, ">", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	DGS1:dgsSetFont(gui["btnLanguageNext"], font_12)
	addEventHandler("onDgsMouseClickDown", gui["btnLanguagePrev"] , newCharacter_updateLanguage, false)
	addEventHandler("onDgsMouseClickDown", gui["btnLanguageNext"] , newCharacter_updateLanguage, false)

	gui["btnCancel"] = DGS1:dgsCreateButton(10, 364, 231, 41, "Cancel", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)--DGS1:dgsCreateButton(10, 364, 231, 41, "Cancel", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	DGS1:dgsSetFont(gui["btnCancel"], font_12)
	addEventHandler("onDgsMouseClickDown", gui["btnCancel"], newCharacter_cancel, false)

	gui["btnCreateChar"] = DGS1:dgsCreateButton(10,408, 231, 41, "Create", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)--DGS1:dgsCreateButton(10,408, 231, 41, "Create", false, gui["_root"], tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	DGS1:dgsSetFont(gui["btnCreateChar"], font_12)
	addEventHandler("onDgsMouseClickDown", gui["btnCreateChar"], newCharacter_attemptCreateCharacter, false)
	newCharacter_changeSkin()
	newCharacter_updateScrollBars()
end

function newCharacter_raceFix()
	DGS1:dgsCheckBoxSetSelected ( gui["chkAsian"], false )
	DGS1:dgsCheckBoxSetSelected ( gui["chkWhite"], false )
	DGS1:dgsCheckBoxSetSelected ( gui["chkBlack"], false )
	if (source == gui["chkBlack"]) then
		DGS1:dgsCheckBoxSetSelected ( gui["chkBlack"], true )
	elseif (source == gui["chkWhite"]) then
		DGS1:dgsCheckBoxSetSelected ( gui["chkWhite"], true )
	elseif (source == gui["chkAsian"]) then
		DGS1:dgsCheckBoxSetSelected ( gui["chkAsian"], true )
	end

	curskin = 1
	newCharacter_changeSkin(0)
end

function newCharacter_updateGender()
	local diff = 0
	if (source == gui["btnPrevSkin"]) then
		diff = -1
	elseif (source == gui["btnNextSkin"]) then
		diff = 1
	else
		curskin = 1
	end
	newCharacter_changeSkin(diff)
end

function newCharacter_updateLanguage()

	if source == gui["btnLanguagePrev"] then
		if languageselected == 1 then
			languageselected = call( getResourceFromName( "language-system" ), "getLanguageCount" )
		else
			languageselected = languageselected - 1
		end
	elseif source == gui["btnLanguageNext"] then
		if languageselected == call( getResourceFromName( "language-system" ), "getLanguageCount" ) then
			languageselected = 1
		else
			languageselected = languageselected + 1
		end
	end

	DGS1:dgsSetText(gui["lblLanguageDisplay"], tostring(call( getResourceFromName( "language-system" ), "getLanguageName", languageselected )))
end

function newCharacter_updateScrollBars()
	local scrollHeight = DGS1:dgsScrollBarGetScrollPosition(gui["scrHeight"])
	scrollHeight = math.floor((scrollHeight / 2) + 150)

	local scrWeight = DGS1:dgsScrollBarGetScrollPosition(gui["scrWeight"])
	scrWeight = math.floor(scrWeight + 50)

	local scrAge = DGS1:dgsScrollBarGetScrollPosition(gui["scrAge"])
	scrAge = math.floor( (scrAge * 0.8 ) + 16 )

	DGS1:dgsSetText(gui["lblHeight"], "Height: "..scrollHeight.." CM")

	DGS1:dgsSetText(gui["lblWeight"], "Weight: "..scrWeight.." LB")

	DGS1:dgsSetText(gui["lblAge"], "Age: "..scrAge.." years old")

	local year = getBirthday(tonumber(scrAge))
	selectedMonth = monthToNumber(selectedMonth1)
	local dayCap = daysInMonth(selectedMonth, year) or 31

	scrDay = (tonumber(DGS1:dgsScrollBarGetScrollPosition(gui["scrDay"]))+1)/100
	scrDay = math.floor( scrDay*dayCap )
	if scrDay == 0 then
		scrDay = 1
	end

	DGS1:dgsSetText(gui["lblDay"], "Day of birth: "..(scrDay or "1"))
end

function newCharacter_changeSkin(diff)
	local array = newCharacters_getSkinArray()
	local skin = 0
	if (diff ~= nil) then
		curskin = curskin + diff
	end

	if (curskin > #array or curskin < 1) then
		curskin = 1
		skin = array[1]
	else
		curskin = curskin
		skin = array[curskin]
	end

	if skin ~= nil then
		setElementModel(dummyPed, tonumber(skin))
	end
end

function newCharacters_getSkinArray()
	local array = { }
	if (DGS1:dgsCheckBoxGetSelected( gui["chkBlack"] )) then -- BLACK
		if (DGS1:dgsRadioButtonGetSelected( gui["rbMale"] )) then -- BLACK MALE
			array = blackMales
		elseif (DGS1:dgsRadioButtonGetSelected( gui["rbFemale"] )) then -- BLACK FEMALE
			array = blackFemales
		else
			outputChatBox("Select a gender first!", 0, 255, 0)
		end
	elseif ( DGS1:dgsCheckBoxGetSelected( gui["chkWhite"] ) ) then -- WHITE
		if ( DGS1:dgsRadioButtonGetSelected( gui["rbMale"] ) ) then -- WHITE MALE
			array = whiteMales
		elseif ( DGS1:dgsRadioButtonGetSelected( gui["rbFemale"] ) ) then -- WHITE FEMALE
			array = whiteFemales
		else
			outputChatBox("Select a gender first!", 0, 255, 0)
		end
	elseif ( DGS1:dgsCheckBoxGetSelected( gui["chkAsian"] ) ) then -- ASIAN
		if ( DGS1:dgsRadioButtonGetSelected( gui["rbMale"] ) ) then -- ASIAN MALE
			array = asianMales
		elseif ( DGS1:dgsRadioButtonGetSelected( gui["rbFemale"] ) ) then -- ASIAN FEMALE
			array = asianFemales
		else
			outputChatBox("Select a gender first!", 0, 255, 0)
		end
	end
	return array
end

function newCharacter_cancel(hideSelection)
	removeEventHandler("onClientRender", getRootElement(), groundLogo)
	guiSetInputEnabled(false)
	destroyElement(dummyPed)
	destroyElement(gui["_root"])
	gui = {}
	curskin = 1
	dummyPed = nil
	languageselected = 1
	if hideSelection ~= true then
		Characters_showSelection()
	end
	clearChat()
end

function newCharacter_attemptCreateCharacter()
	local characterName = DGS1:dgsGetText(gui["txtCharName"])
	local nameCheckPassed, nameCheckError = checkValidCharacterName(characterName)
	removeEventHandler("onClientRender", getRootElement(), groundLogo)
	if not nameCheckPassed then
		LoginScreen_showWarningMessage( "Error processing your character name:\n".. nameCheckError )
		return
	end

	local race = 0
	if (DGS1:dgsCheckBoxGetSelected(gui["chkBlack"])) then
		race = 0
	elseif (DGS1:dgsCheckBoxGetSelected(gui["chkWhite"])) then
		race = 1
	elseif (DGS1:dgsCheckBoxGetSelected(gui["chkAsian"])) then
		race = 2
	else
		LoginScreen_showWarningMessage( "Error processing your character race:\nNone selected." )
		return
	end

	local gender = 0
	if (DGS1:dgsRadioButtonGetSelected( gui["rbMale"] )) then
		gender = 0
	elseif (DGS1:dgsRadioButtonGetSelected( gui["rbFemale"] )) then
		gender = 1
	else
		LoginScreen_showWarningMessage( "Error processing your character gender:\nNone selected." )
		return
	end

	local skin = getElementModel( dummyPed )
	if not skin then
		LoginScreen_showWarningMessage( "Error processing your character skin:\nNone selected." )
		return
	end


	local scrollHeight = DGS1:dgsScrollBarGetScrollPosition(gui["scrHeight"])
	scrollHeight = math.floor((scrollHeight / 2) + 150)

	local scrWeight = DGS1:dgsScrollBarGetScrollPosition(gui["scrWeight"])
	scrWeight = math.floor(scrWeight + 50)

	local scrAge = DGS1:dgsScrollBarGetScrollPosition(gui["scrAge"])
	scrAge = math.floor( (scrAge * 0.8 ) + 16 )

	if languageselected == nil then
		LoginScreen_showWarningMessage( "Error processing your character language:\nNone selected." )
		return
	end
	DGS1:dgsSetEnabled(gui["btnCancel"], false)
	DGS1:dgsSetEnabled(gui["btnCreateChar"], false)
	DGS1:dgsSetEnabled(gui["_root"], false)
	fadeCamera(false, 1)
	setTimer(function ()
		selectStartPointGUI(characterName, characterDescription, race, gender, skin, scrollHeight, scrWeight, scrAge, languageselected, selectedMonth, scrDay) --This is the correct place. /MAXIME
	end, 6000, 1)
end

function newCharacter_response(statusID, statusSubID)
	if (statusID == 1) then
		LoginScreen_showWarningMessage( "Oops, something went wrong. Try again\nor contact an administrator.\nError ACC"..tostring(statusSubID) )
	elseif (statusID == 2) then
		if (statusSubID == 1) then
			LoginScreen_showWarningMessage( "This charactername is already in\nuse, sorry :(!" )
		else
			LoginScreen_showWarningMessage( "Oops, something went wrong. Try again\nor contact an administrator.\nError ACD"..tostring(statusSubID) )
		end
	elseif (statusID == 3) then
		newCharacter_cancel(true)
		triggerServerEvent("accounts:characters:spawn", getLocalPlayer(), statusSubID)
		triggerServerEvent("updateCharacters", getLocalPlayer())
		return
	end

	DGS1:dgsSetEnabled(gui["btnCancel"], true)
	DGS1:dgsSetEnabled(gui["btnCreateChar"], true)
	DGS1:dgsSetEnabled(gui["_root"], true)

end
addEventHandler("accounts:characters:new", getRootElement(), newCharacter_response)

local wSelectStartPoint = nil
function selectStartPointGUI(characterName, characterDescription, race, gender, skin, scrollHeight, scrWeight, scrAge, languageselected, selectedMonth, scrDay )
	showCursor(true)
	guiSetInputEnabled(true)

	--config
	local locations = {
					-- x, 			y,					 z, 			rot    		int, 	dim 	Location Name
		["default"] = {1924.4794921875, -1760.5458984375, 13.546875, 359.0744, 	        0, 		0, 		"Fort Carson City Hall"},
		["bus"] = {1749.509765625, -1860.5087890625, 13.578649520874, 359.0744, 	0, 		0, 		"Unity Bus Station"},
		["metro"] = {808.88671875, -1354.6513671875, -0.5078125, 139.5092, 			0, 		0,		"Metro Station"},
		["air"] = {1691.6455078125, -2334.001953125, 13.546875, 0.10711, 			0, 		0,		"Los Santos International Airport"},
		["boat"] = {2809.66015625, -2436.7236328125, 13.628322601318, 90.8995, 		0, 		0,		"Santa Maria Dock"},
	}

	wSelectStartPoint = DGS1:dgsCreateWindow(0,0, 300, 250, "How do you arrive in Los Santos?", false, tocolor(200, 200, 200, 255), _, ":account/login-panel/up.png", tocolor(255, 255, 255, 255), _, _, _, true)
	--exports.global:centerWindow(wSelectStartPoint)

	local busButton = DGS1:dgsCreateButton(40, 40, 100, 60, "Bus", false, wSelectStartPoint, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClickDown", busButton, function ()
		newCharacter_cancel(true)
		Bus()
		triggerServerEvent("accounts:characters:new", getLocalPlayer(), characterName, characterDescription, race, gender, skin, scrollHeight, scrWeight, scrAge, languageselected, selectedMonth, scrDay, locations.bus)
		closeSelectStartPoint()
	end, false)
	
	local metroButton = DGS1:dgsCreateButton(40, 120, 100, 60, "Metro", false, wSelectStartPoint, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClickDown", metroButton, function()
		newCharacter_cancel(true)
		Metro()
		triggerServerEvent("accounts:characters:new", getLocalPlayer(), characterName, characterDescription, race, gender, skin, scrollHeight, scrWeight, scrAge, languageselected, selectedMonth, scrDay, locations.metro)
		closeSelectStartPoint()
	end, false)
	
	local airButton = DGS1:dgsCreateButton(160, 40, 100, 60, "Airplane", false, wSelectStartPoint, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClickDown", airButton, function()
		newCharacter_cancel(true)
		Air()
		triggerServerEvent("accounts:characters:new", getLocalPlayer(), characterName, characterDescription, race, gender, skin, scrollHeight, scrWeight, scrAge, languageselected, selectedMonth, scrDay, locations.air)
		closeSelectStartPoint()
	end, false)
	
	local boatButton = DGS1:dgsCreateButton(160, 120, 100, 60, "Boat", false, wSelectStartPoint, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(50, 55, 60, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClickDown", boatButton, function()
		newCharacter_cancel(true)
		Boat()
		triggerServerEvent("accounts:characters:new", getLocalPlayer(), characterName, characterDescription, race, gender, skin, scrollHeight, scrWeight, scrAge, languageselected, selectedMonth, scrDay, locations.boat)
		closeSelectStartPoint()
	end, false)
end

function Air ()
	contentWindowair = DGS1:dgsCreateWindow(0.24, 0.43, 0.51, 0.14, "", true, _, 0, _, _, _, tocolor(0, 0, 0, 255), _, true)
	lvLabelair = DGS1:dgsCreateLabel(0.03, 0.01, 0.95, 0.36, "Los Santos International Airport", true, contentWindowair)
	DGS1:dgsSetFont(lvLabelair, font_28)
	DGS1:dgsLabelSetHorizontalAlign(lvLabelair, "center", false)
	
	lvLabelair2 = DGS1:dgsCreateLabel(0.88, 0.45, 0.16, 0.25, "Arrivals", true, contentWindowair)
	DGS1:dgsSetFont(lvLabelair2, font_16)

	DGS1:dgsSetAlpha(contentWindowair, 0)
	DGS1:dgsAlphaTo(contentWindowair, 1, false, "OutQuad", 2000)
	setTimer(function()
		fadeCamera(true, 2)
		DGS1:dgsAlphaTo(contentWindowair, 0, false, "OutQuad", 2000)
	end, 4000, 1)
end
function Metro ()
	contentWindowmetro = DGS1:dgsCreateWindow(0.24, 0.43, 0.51, 0.14, "", true, _, 0, _, _, _, tocolor(0, 0, 0, 255), _, true)
	lvLabelmetro = DGS1:dgsCreateLabel(0.03, 0.01, 0.95, 0.36, "San Andreas Metro Station", true, contentWindowmetro)
	DGS1:dgsSetFont(lvLabelmetro, font_28)
	DGS1:dgsLabelSetHorizontalAlign(lvLabelmetro, "center", false)
	
	lvLabelmetro2 = DGS1:dgsCreateLabel(0.88, 0.45, 0.16, 0.25, "Arrivals", true, contentWindowmetro)
	DGS1:dgsSetFont(lvLabelmetro2, font_16)

	DGS1:dgsSetAlpha(contentWindowmetro, 0)
	DGS1:dgsAlphaTo(contentWindowmetro, 1, false, "OutQuad", 2000)
		setTimer(function()
		fadeCamera(true, 2)
		DGS1:dgsAlphaTo(contentWindowmetro, 0, false, "OutQuad", 2000)
	end, 4000, 1)
end
function Bus ()
	contentWindowvus = DGS1:dgsCreateWindow(0.24, 0.43, 0.51, 0.14, "", true, _, 0, _, _, _, tocolor(0, 0, 0, 255), _, true)
	lvLabelbus = DGS1:dgsCreateLabel(0.03, 0.01, 0.95, 0.36, "San Andreas Unity Bus Station", true, contentWindowvus)
	DGS1:dgsSetFont(lvLabelbus, font_28)
	DGS1:dgsLabelSetHorizontalAlign(lvLabelbus, "center", false)
	
	lvLabelbus2 = DGS1:dgsCreateLabel(0.88, 0.45, 0.16, 0.25, "Arrivals", true, contentWindowvus)
	DGS1:dgsSetFont(lvLabelbus2, font_16)

	DGS1:dgsSetAlpha(contentWindowvus, 0)
	DGS1:dgsAlphaTo(contentWindowvus, 1, false, "OutQuad", 2000)
		setTimer(function()
		fadeCamera(true, 2)
		DGS1:dgsAlphaTo(contentWindowvus, 0, false, "OutQuad", 2000)
	end, 4000, 1)
end
function Boat ()
	contentWindowboat = DGS1:dgsCreateWindow(0.24, 0.43, 0.51, 0.14, "", true, _, 0, _, _, _, tocolor(0, 0, 0, 255), _, true)
	lvLabelboat = DGS1:dgsCreateLabel(0.03, 0.01, 0.95, 0.36, "Santa Maria Dock", true, contentWindowboat)
	DGS1:dgsSetFont(lvLabelboat, font_28)
	DGS1:dgsLabelSetHorizontalAlign(lvLabelboat, "center", false)
	
	lvLabelboat2 = DGS1:dgsCreateLabel(0.88, 0.45, 0.16, 0.25, "Arrivals", true, contentWindowboat)
	DGS1:dgsSetFont(lvLabelboat2, font_16)

	DGS1:dgsSetAlpha(contentWindowboat, 0)
	DGS1:dgsAlphaTo(contentWindowboat, 1, false, "OutQuad", 2000)
		setTimer(function()
		fadeCamera(true, 2)
		DGS1:dgsAlphaTo(contentWindowboat, 0, false, "OutQuad", 2000)
	end, 4000, 1)
end
function closeSelectStartPoint()
	if wSelectStartPoint and isElement(wSelectStartPoint) then
		destroyElement(wSelectStartPoint)
		showCursor(false)
		guiSetInputEnabled(false)
	end
end

function isThisYearLeap(year)
     if (tonumber(year)%4) == 0 then
          return true
     else
          return false
     end
end

function monthToNumber(monthName)
	if not monthName then
		return 1
	else
		if monthName == "January" then
			return 1
		elseif monthName == "February" then
			return 2
		elseif monthName == "March" then
			return 3
		elseif monthName == "April" then
			return 4
		elseif monthName == "May" then
			return 5
		elseif monthName == "June" then
			return 6
		elseif monthName == "July" then
			return 7
		elseif monthName == "August" then
			return 8
		elseif monthName == "September" then
			return 9
		elseif monthName == "October" then
			return 10
		elseif monthName == "November" then
			return 11
		elseif monthName == "December" then
			return 12
		else
			return 1
		end
	end
end

function monthNumberToName(monthNumber)
	if not monthNumber or not tonumber(monthNumber) then
		return "January"
	else
		monthNumber = tonumber(monthNumber)
		if monthNumber == 1 then
			return "January"
		elseif monthNumber == 2 then
			return "February"
		elseif monthNumber == 3 then
			return "March"
		elseif monthNumber == 4 then
			return "April"
		elseif monthNumber == 5 then
			return "May"
		elseif monthNumber == 6 then
			return "June"
		elseif monthNumber == 7 then
			return "July"
		elseif monthNumber == 8 then
			return "August"
		elseif monthNumber == 9 then
			return "September"
		elseif monthNumber == 10 then
			return "October"
		elseif monthNumber == 11 then
			return "November"
		elseif monthNumber == 12 then
			return "December"
		else
			return "January"
		end
	end
end

function daysInMonth(month, year)
	if not month or not year or not tonumber(month) or not tonumber(year) then
		return 31
	else
		month = tonumber(month)
		year = tonumber(year)
	end

	if month == 1 then
		return 31
	elseif month == 2 then
		if isThisYearLeap(year) then
			return 29
		else
			return 28
		end
	elseif month == 3 then
		return 31
	elseif month == 4 then
		 return 30
	elseif month == 5 then
		return 31
	elseif month == 6 then
		return 30
	elseif month == 7 then
		return 31
	elseif month == 8 then
		return 31
	elseif month == 9 then
		return 30
	elseif month == 10 then
		return 31
	elseif month == 11 then
		return 30
	elseif month == 12 then
		return 31
	else
		return 31
	end
end

function getBirthday(age)
	if not age or not tonumber(age) then
		return 2015
	else
		age = tonumber(age)
	end

	local time = getRealTime()
	time.year = time.year + 1900
	return (time.year - age)
end

function getBetterDay(day)
	if not day or not tonumber(day) then
		return "1st"
	else
		day = tonumber(day)
		if day == 1 or day == 21 or day == 31 then
			return day.."st"
		elseif day == 2 or day == 22 then
			return day.."nd"
		elseif day == 3 or day == 23 then
			return day.."rd"
		else
			return day.."th"
		end
	end
end

--1142.162109375, -1156.7587890625, 23.828125
function groundLogo()
dxDrawMaterialLine3D(1142.162109375, -1156.7587890625 + logoSize / 2, 23.828125 - 0.99, 1142.162109375, -1156.7587890625 - logoSize / 2, 23.828125 - 0.99, logoTexture, logoSize, tocolor(0,162,255), 1142.162109375, -1156.7587890625, 23.828125 + 10 - 0.99)
end