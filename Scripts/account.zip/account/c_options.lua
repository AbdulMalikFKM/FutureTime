--Dharma = exports['dgs-master']
fontType = {-- (1)font (2)scale offset
	["default"] = {"default", 1},
	["default-bold"] = {"default-bold",1},
	["clear"] = {"clear",1.1},
	["arial"] = {"arial",1},
	["sans"] = {"sans",1.2},
	["pricedown"] = {"pricedown",3},
	["bankgothic"] = {"bankgothic",4},
	["diploma"] = {"diploma",2},
	["beckett"] = {"beckett",2},
	["BizNoteFont18"] = {"BizNoteFont18",1.1},
}

function getOverLayFonts()
	return fontType
end

fonts = getOverLayFonts()


function options_enable()
	--toggleControl("change_camera", false)
	keys = getBoundKeys("change_camera")

	--[[for name, state in pairs(keys) do
		if ( name ~= "home" ) then
			bindKey(name, "down", options_cameraWorkAround)
		else
			unbindKey(name)
		end
	end]]

	addCommandHandler("home", options_showmenu)
	bindKey("F10", "down", "home")
end
addEventHandler("accounts:options",getRootElement(),options_enable)

addEventHandler("onClientKey", root,
function (button, press)
	if (button == "F10") then
	triggerServerEvent("showMeMyProperties", localPlayer, localPlayer)
	end
end)

function options_disable()
	removeCommandHandler("home", options_showmenu)
	unbindKey("home", "down", "home")
	unbindKey("F10", "down", "home")
			--triggerServerEvent("showMeMyProperties", localPlayer, localPlayer)
end

wOptions,bChangeCharacter,bStreamerSettings,bGraphicsSettings,bAccountSettings,bLogout, DpropRectImg, objPrev = nil
wGraphicsMenu,cLogsEnabled,cMotionBlur,cSkyClouds,cStreamingAudio,bGraphicsMenuClose,sVehicleStreamer,sPickupStreamer,lVehicleStreamer,lPickupStreamer,gameMenuLoaded = nil

function isCameraOnPlayer()
	local vehicle = getPedOccupiedVehicle(getLocalPlayer())
	if vehicle then
		return getCameraTarget( ) == vehicle
	else
		return getCameraTarget( ) == getLocalPlayer()
	end
end
--[[
function options_showmenu()
	if wOptions then
		options_closemenu()
		return
	end

	if getElementData(getLocalPlayer(), "exclusiveGUI") or not isCameraOnPlayer() then
		return
	end
	triggerEvent( 'hud:blur', resourceRoot, 6, true, 0.5, nil )
	setElementData(getLocalPlayer(), "exclusiveGUI", true, false)
	triggerEvent("account:changingchar", getLocalPlayer())
	local screenWidth, screenHeight = guiGetScreenSize()
	local windowWidth, windowHeight = 250, 15
	local bHeight = 35
	windowHeight = windowHeight+(bHeight*5)
	local left = screenWidth/2 - windowWidth/2
	local top = screenHeight/2 - windowHeight/2
	local margin = 15
	local wHeight = margin + 195
	showCursor(true)  
	--dgsCreateWindow(x,y,sx,sy,text,relative,textColor,titleHeight,titleImage,titleColor,image,color,borderSize,noCloseButton)
	wOptions = Dharma:dgsCreateWindow(-300, 0, 261, 768, "", false, _, 10, _, tocolor(238, 33, 73, 150), _, _, _, true)
	Dharma:dgsMoveTo(wOptions,0,0,false,false,"Linear",1000)
	Dharma:dgsWindowSetSizable(wOptions, false)
	Dharma:dgsWindowSetMovable(wOptions, false)
	--Dharma:dgsSetEnabled(wOptions, false)
	logo = Dharma:dgsCreateImage(-100, 10, 257, 166, ":account/login-panel/sh3ar.png", false, wOptions) 
	Dharma:dgsMoveTo(logo,4,10,false,false,"Linear",1000)	
--dgsCreateButton(x,y,sx,sy,text,relative,parent,textColor,scalex,scaley,norimg,selimg,cliimg,norcolor,hovcolor,clicolor)
	bChangeCharacter = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Change Character", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))	
	addEventHandler("onDgsMouseClick", bChangeCharacter,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				options_logOut( )
			end
			options_closemenu()
		end, false)
	wHeight = wHeight + bHeight
	bStatistics = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Character Statistics", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClick", bStatistics,
	function ()
		if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
			triggerServerEvent("showStats", localPlayer,localPlayer)
		end
		options_closemenu()
	end, false)
	wHeight = wHeight + bHeight

	bGraphicsSettings = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Settings", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	--addEventHandler("onDgsMouseClick", bGraphicsSettings, options_opengraphicsmenu, false)
	addEventHandler("onDgsMouseClick", bGraphicsSettings,
	function ()
		if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
			--triggerServerEvent("accounts:settings:fetchSettings", localPlayer)
			showSettingsWindow()
		end
	end, false)
	wHeight = wHeight + bHeight

	if getResourceFromName("donators") then
		bStore = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Premium Features", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
		--addEventHandler("onDgsMouseClick", bGraphicsSettings, options_opengraphicsmenu, false)
		addEventHandler("onDgsMouseClick", bStore,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				triggerServerEvent("donation-system:GUI:open", localPlayer)
			end
			options_closemenu()
		end, false)
		wHeight = wHeight + bHeight
	end

	if getResourceFromName("admin-system") and exports['admin-system']:canPlayerAccessStaffManager(localPlayer) then
		bStaffManager = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Staff Manager", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
		addEventHandler("onDgsMouseClick", bStaffManager,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				executeCommandHandler("staffs")
			end
			options_closemenu()
		end, false)
		wHeight = wHeight + bHeight
	end

	if getResourceFromName("interior_system") and getResourceFromName("interior-manager") and exports.integration:isPlayerAdmin( localPlayer ) then
		bInteriorManager = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Interior Manager", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
		addEventHandler("onDgsMouseClick", bInteriorManager,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				triggerServerEvent("interiorManager:openit", localPlayer, localPlayer)
			end
			options_closemenu()
		end, false)
		wHeight = wHeight + bHeight
	end

	if getResourceFromName("apps") and exports.integration:isPlayerTrialAdmin(localPlayer) or exports.integration:isPlayerSupporter(localPlayer) then
		bApplicationManager = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Application Manager", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
		addEventHandler("onDgsMouseClick", bApplicationManager,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				executeCommandHandler("apps")
			end
			options_closemenu()
		end, false)
		wHeight = wHeight + bHeight
	end

	if getResourceFromName("tele-manager") and exports.integration:isPlayerTrialAdmin(localPlayer) or exports.integration:isPlayerSupporter(localPlayer) then
		bTeleportManager = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Teleport Manager", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
		addEventHandler("onDgsMouseClick", bTeleportManager,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				executeCommandHandler("tele")
			end
			options_closemenu()
		end, false)
		wHeight = wHeight + bHeight
	end
	
	if getResourceFromName("carradio") then
		bRadioManager = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Radio Station Manager", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
		addEventHandler("onDgsMouseClick", bRadioManager,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				executeCommandHandler("radios")
			end
			options_closemenu()
		end, false)
		wHeight = wHeight + bHeight
	end

	if getResourceFromName("vehicle-manager") then
		local thePlayer = getLocalPlayer()
		if exports.integration:isPlayerVCTMember(thePlayer) or exports.integration:isPlayerSupporter(thePlayer) or exports.integration:isPlayerTrialAdmin(thePlayer) or exports.integration:isPlayerScripter(thePlayer) or exports.integration:isPlayerVehicleConsultant(thePlayer) then
			bVehicleLib = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Vehicle Library", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
			addEventHandler("onDgsMouseClick", bVehicleLib,
				function ()
					if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
						triggerServerEvent("vehlib:sendLibraryToClient", localPlayer)
					end
					options_closemenu()
				end, false)
			wHeight = wHeight + bHeight
		end
	end
	
		if getResourceFromName('moddownloader') and getResourceFromName("vehicle-manager") then
			bMods = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "MODS", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
			addEventHandler("onDgsMouseClick", bMods,
				function ()
					if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
						triggerEvent("openModDownloaderwOptions", localPlayer)
					end
					options_closemenu()
				end, false)
			wHeight = wHeight + bHeight
		end

	if getResourceFromName("announcement") and exports.announcement:canPlayerAccessMotdManager(localPlayer) then
		bmotd = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "MOTD Manager", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
		addEventHandler("onDgsMouseClick", bmotd,
			function ()
				if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
					executeCommandHandler("motd")
				end
				options_closemenu()
			end, false)
		wHeight = wHeight + bHeight
	end
	

	if getResourceFromName("help") then
		bHelp = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Help & Manual", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
		addEventHandler("onDgsMouseClick", bHelp,
			function ()
				if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
					triggerEvent("getCmdsHelpFromServer", localPlayer, nil, true)
				end
				options_closemenu()
			end, false)
		wHeight = wHeight + bHeight
	end

	bLogout = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Logout", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClick", bLogout,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				fadeCamera ( false, 2, 0,0,0 )
				setTimer(function()
					triggerServerEvent("accounts:settings:reconnectPlayer", localPlayer)
				end, 2000,1)
			end
			options_closemenu()
		end, false)
	wHeight = wHeight + bHeight

	bClose = Dharma:dgsCreateButton(margin, wHeight, 224, 34, "Close", false, wOptions, tocolor(200, 200, 200, 255), _, _, _, _, _, tocolor(85, 90, 100, 255), tocolor(209, 17, 6, 200), tocolor(209, 17, 6, 255))
	addEventHandler("onDgsMouseClick", bClose, options_closemenu, false)
	wHeight = wHeight + bHeight

	guiSetSize(wOptions, windowWidth, wHeight+margin/2, false)
	exports.global:centerWindow(wOptions)
end
]]
DGS = exports['dgs-master']

home = dxCreateTexture(":resources/home.png")
finance = dxCreateTexture(":resources/money.png")
setting = dxCreateTexture(":resources/settings.png")
radio = dxCreateTexture(":resources/walkietalkie.png")
report = dxCreateTexture(":resources/other.png")
premium = dxCreateTexture(":resources/rank.png")
help = dxCreateTexture(":resources/description.png")
--DGS = exports['dgs-master']
DGS:dgsLocateObjectPreviewResource("object_preview")

function options_showmenu(vehicleList, interiorList, carried)
		if wOptions and background then
		options_closemenu()
		return
	end
	
			--robotoFont10 = DGS:dgsCreateFont(":job-system/storekeeper/files/Roboto-Regular.ttf", 10)
		robotoFont10 = DGS:dgsCreateFont(":resources/fonts/Roboto-Regular.ttf", 10)
		robotoFont11 = DGS:dgsCreateFont(":resources/fonts/OpenSans-Regular.ttf", 12)
		--robotoFont11 = DGS:dgsCreateFont(":job-system/storekeeper/files/Roboto-Regular.ttf", 11)
		opal18 = DGS:dgsCreateFont(":resources/OPAL.ttf", 18)
	
	
	--if getElementData(getLocalPlayer(), "exclusiveGUI") or not isCameraOnPlayer() then
	--	return
	--end
	--triggerEvent( 'hud:blur', resourceRoot, 6, true, 0.5, nil )
	--setElementData(getLocalPlayer(), "exclusiveGUI", true, false)
	--triggerEvent("account:changingchar", getLocalPlayer())
	local sW, sH = guiGetScreenSize() -- get the screen size
	-- blurbox = DGS:dgsCreateBlurBox(sW, sH) -- Create a blur Box
	-- blurArea = DGS:dgsCreateImage(0,0,1,1,blurbox,true)
	background = DGS:dgsCreateImage(0, 0, sW, sH,":account/login-panel/panel.png",false, nil, tocolor (255, 255, 255, 255))
	DGS:dgsSetEnabled(background, false)
	
local screenW, screenH = guiGetScreenSize()
		
		
		money = getElementData(localPlayer, "money")
		bmoney = getElementData(localPlayer, "bankmoney")
		hours = getElementData(localPlayer, "hoursplayed")
		job = getElementData(localPlayer, "job") or "Unemployed"
		jobName = exports["job-system"]:getJobTitleFromID(job)
		accName = getElementData(localPlayer, "account:username")
		accID = getElementData(localPlayer, "account:id")
		regData = getElementData(localPlayer, "account:registerdate") or "Unknown"
		gc = getElementData(localPlayer, "account:credits") or "0"
		rank = exports.global:getPlayerAdminTitle(localPlayer)
		playerTeam = getPlayerTeam(localPlayer)
		facName = getTeamName(playerTeam)
		_char = getElementData(getLocalPlayer(), "account:characters")
			showCursor(true) 
	local carlicense = getElementData(localPlayer, "license.car")
	local bikelicense = getElementData(localPlayer, "license.bike")
	local boatlicense = getElementData(localPlayer, "license.boat")
	local fishlicense = getElementData(localPlayer, "license.fish")
	local gunlicense = getElementData(localPlayer, "license.gun")
	local gun2license = getElementData(localPlayer, "license.gun2")
	if (carlicense==1) then
		carlicense = "#00ff00Yes"
	elseif (carlicense==3) then
		carlicense = "Theory test passed"
	else
		carlicense = "#ff0000No"
	end
	if (bikelicense==1) then
		bikelicense = "#00ff00Yes"
	elseif (bikelicense==3) then
		bikelicense = "Theory test passed"
	else
		bikelicense = "#ff0000No"
	end
	if (boatlicense==1) then
		boatlicense = "#00ff00Yes"
	else
		boatlicense = "#ff0000No"
	end
	
		local pilotLicenses = exports['mdc-system']:getPlayerPilotLicenses(thePlayer) or {}
	local pilotlicense = ""
	local maxShow = 5
	local numAdded = 0
	local numOverflow = 0
	local typeratings = 0
	for k,v in ipairs(pilotLicenses) do
		local licenseID = v[1]
		local licenseValue = v[2]
		local licenseName = v[3]
		if licenseID == 7 then --if typerating
			if licenseValue then
				typeratings = typeratings + 1
			end
		else
			if numAdded >= maxShow then
				numOverflow = numOverflow + 1
			else
				if numAdded == 0 then
					pilotlicense = pilotlicense..tostring(licenseName)
				else
					pilotlicense = pilotlicense..", "..tostring(licenseName)
				end
				numAdded = numAdded + 1
			end
		end
	end
	if(numAdded == 0) then
		pilotlicense = "#ff0000No"
	else
		if numOverflow > 0 then
			pilotlicense = pilotlicense.." (+"..tostring(numOverflow+typeratings)..")"
		else
			if typeratings > 0 then
				pilotlicense = pilotlicense.." (+"..tostring(typeratings)..")"
			else
				pilotlicense = pilotlicense.."."
			end
		end
	end
	
	if (fishlicense==1) then
		fishlicense = "#00ff00Yes"
	else
		fishlicense = "#ff0000No"
	end
	if (gunlicense==1) then
		gunlicense = "#00ff00Yes"
	else
		gunlicense = "#ff0000No"
	end
	if (gun2license==1) then
		gun2license = "#00ff00Yes"
	else
		gun2license = "#ff0000No"
	end
		
		maxint = (getElementData(localPlayer, "maxinteriors") or 10)
		local dbid = tonumber(getElementData(localPlayer, "dbid"))
		local carids = ""
		local numcars = 0
		for key, value in ipairs(getElementsByType("vehicle")) do
		local owner = tonumber(getElementData(value, "owner"))

		if (owner) and (owner==dbid) then
			local id = getElementData(value, "dbid")
			carids = carids .. id .. ", "
			numcars = numcars + 1
		end
	end
	printCar = numcars .. "/#FFFFFF" .. getElementData(localPlayer, "maxvehicles")
	local properties = ""
	local numproperties = 0
	for key, value in ipairs(getElementsByType("interior")) do
		local interiorStatus = getElementData(value, "status")
		
		if interiorStatus[4] and interiorStatus[4] == dbid and getElementData(value, "name") then
			local id = getElementData(value, "dbid")
			properties = properties .. id .. ", "
			numproperties = numproperties + 1
		end
	end
	--	background = DGS:dgsCreateImage(0, 0, screenW, screenH, ":account/login-panel/vin2.png", false)
		mainRect = DGS:dgsCreateRoundRect(0, false,tocolor(10,10,10,255))
		--backgRect = DGS:dgsCreateRoundRect(0, false,tocolor(10,10,10,255))
		dummyRect = DGS:dgsCreateRoundRect(0, false,tocolor(10,10,10,255))
		labelRect = DGS:dgsCreateRoundRect(0, false,tocolor(15,15,15,255))
		
		--background = DGS:dgsCreateImage(0, 0, screenW, screenH,backgRect,false)
		wOptions = DGS:dgsCreateImage((screenW - 970) / 2, (screenH - 575) / 2, 970, 575,mainRect,false)
		
		DGS:dgsSetAlpha(wOptions,0)
		DGS:dgsAlphaTo(wOptions,1,"Linear",800)
		
		
		logoRect = DGS:dgsCreateImage(0, 0, 970, 65,labelRect,false,wOptions)
        logo = DGS:dgsCreateImage(9, 2, 213, 65, ":resources/dashlogo.png", false, wOptions)
		DGS:dgsSetEnabled(logo, false)
		DGS:dgsSetEnabled(logoRect, false)
		nameLbl = DGS:dgsCreateLabel(235, 8, 509, 35, "#c8c8c8Welcome #0770C4".. getPlayerName(localPlayer):gsub("_", " "), false, wOptions, tocolor(200, 200, 200, 255))
		welLbl = DGS:dgsCreateLabel(235, 35, 509, 35, "Enjoy Your Stay!", false, wOptions, tocolor(200, 200, 200, 255))
		
		DGS:dgsSetProperty(nameLbl,"font",opal18)
		DGS:dgsSetProperty(nameLbl,"colorCoded",true)
		DGS:dgsSetProperty(welLbl,"font",opal18)
		DGS:dgsSetProperty(welLbl,"colorCoded",true)
		
		bClose = DGS:dgsCreateButton(934, 21, 26, 23, "", false, wOptions, tocolor(200, 200, 200, 255), _, _, ":interaction/icons/cross_x.png", ":interaction/icons/cross_x.png", ":interaction/icons/cross_x.png",_, tocolor(7, 112, 196,200), tocolor(7, 112, 196, 255))
		addEventHandler("onDgsMouseClickDown", bClose, options_closemenu, false)
		DmainRectImg = DGS:dgsCreateImage(225, 65, 745, 510,dummyRect,false,wOptions)
		DpropRectImg = DGS:dgsCreateImage(225, 65, 745, 510,dummyRect,false,wOptions)
		DpremiumRectImg = DGS:dgsCreateImage(225, 65, 745, 510,dummyRect,false,wOptions)
		DredemRectImg = DGS:dgsCreateImage(225, 65, 745, 510,dummyRect,false,wOptions)
		DradioRectImg = DGS:dgsCreateImage(225, 65, 745, 510,dummyRect,false,wOptions)
		DhelpRectImg = DGS:dgsCreateImage(225, 65, 745, 510,dummyRect,false,wOptions)
		--DrepRectImg = DGS:dgsCreateImage(225, 65, 745, 510,dummyRect,false,wOptions)
		DsettRectImg = DGS:dgsCreateImage(225, 65, 745, 510,dummyRect,false,wOptions)
		
		skinID = getElementModel ( localPlayer )
		myElement = createPed(skinID,0,0,0)
		objPrev = DGS:dgsCreateObjectPreviewHandle(myElement,0,0,150)
		skinImg = DGS:dgsCreateImage(325, -25, 450, 500,_,false, DmainRectImg)
		DGS:dgsAttachObjectPreviewToImage(objPrev,skinImg)
		
        maingrid = DGS:dgsCreateGridList(9, 65, 215, 501, false, wOptions, _, tocolor(5,5,5,255), _, tocolor(5,5,5,255))--guiCreateGridList(9, 65, 215, 501, false, GUIEditor.window[1])
        local column = DGS:dgsGridListAddColumn( maingrid, "", 0.95 )
		DGS:dgsGridListSetNavigationEnabled(maingrid, false)
		
		for i = 1, 7 do
		row = DGS:dgsGridListAddRow(maingrid)
		end
		DGS:dgsGridListSetItemText(maingrid, 1, column, "        Home", false)
		DGS:dgsGridListSetItemText(maingrid, 2, column, "        Finance", false)
		--DGS:dgsGridListSetItemText(maingrid, 3, column, "        Report", false)
		DGS:dgsGridListSetItemText(maingrid, 3, column, "        Premium Features", false)
		DGS:dgsGridListSetItemText(maingrid, 4, column, "        Redeem Code", false)
		DGS:dgsGridListSetItemText(maingrid, 5, column, "        Radio Station Manager", false)
		DGS:dgsGridListSetItemText(maingrid, 6, column, "        Help & Manual", false)
		DGS:dgsGridListSetItemText(maingrid, 7, column, "        Settings", false)
		
		DGS:dgsSetProperty(maingrid,"rowHeight",40)
		DGS:dgsGridListSetColumnHeight(maingrid, 0)

		DGS:dgsGridListSetRowBackGroundColor(maingrid,1,tocolor(25, 25, 25, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
		DGS:dgsGridListSetRowBackGroundColor(maingrid,2,tocolor(15, 15, 15, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
		DGS:dgsGridListSetRowBackGroundColor(maingrid,3,tocolor(25, 25, 25, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
		DGS:dgsGridListSetRowBackGroundColor(maingrid,4,tocolor(15, 15, 15, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
		DGS:dgsGridListSetRowBackGroundColor(maingrid,5,tocolor(25, 25, 25, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
		DGS:dgsGridListSetRowBackGroundColor(maingrid,6,tocolor(15, 15, 15, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
		DGS:dgsGridListSetRowBackGroundColor(maingrid,7,tocolor(25, 25, 25, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
		
		DGS:dgsGridListSetItemImage(maingrid,1,1,home,tocolor(255,255,255,255),-5,2,32,32,false)
		DGS:dgsGridListSetItemImage(maingrid,2,1,finance,tocolor(255,255,255,255),-5,5,32,32,false)
		--DGS:dgsGridListSetItemImage(maingrid,3,1,report,tocolor(255,255,255,255),-5,5,35,35,false)
		DGS:dgsGridListSetItemImage(maingrid,3,1,premium,tocolor(255,255,255,255),-5,5,35,35,false)
		DGS:dgsGridListSetItemImage(maingrid,4,1,radio,tocolor(255,255,255,255),-12,0,40,40,false)
		DGS:dgsGridListSetItemImage(maingrid,5,1,help,tocolor(255,255,255,255),-5,5,32,32,false)
		DGS:dgsGridListSetItemImage(maingrid,6,1,setting,tocolor(255,255,255,255),-5,5,32,32,false)
		DGS:dgsGridListSetItemImage(maingrid,7,1,setting,tocolor(255,255,255,255),-5,5,32,32,false)
		
		DGS:dgsSetProperty(maingrid,"font",robotoFont11)
		DGS:dgsGridListSetSelectedItem (maingrid, 1)
		
		DGS:dgsSetVisible(DpropRectImg, false)
		DGS:dgsSetVisible(DpremiumRectImg, false)
		DGS:dgsSetVisible(DredemRectImg, false)
		DGS:dgsSetVisible(DradioRectImg, false)
		DGS:dgsSetVisible(DsettRectImg, false)
		DGS:dgsSetVisible(DhelpRectImg, false)
		
		btnRect = DGS:dgsCreateRoundRect(15, false, tocolor(20,20,20,255))  --Create Rounded Rectangle with 50 pixels radius 
		btnRecthov = DGS:dgsCreateRoundRect(15, false, tocolor(7, 112, 196, 200))  --Create Rounded Rectangle with 50 pixels radius 
		btnRectClick = DGS:dgsCreateRoundRect(15, false, tocolor(7, 112, 196, 255))
		
				-------------------------------------------Rectangle [My Character] [First Row]-------------------------------------------
		dobRect = DGS:dgsCreateImage(25, 25, 340, 27,labelRect,false,DmainRectImg)
		dlRect = DGS:dgsCreateImage(25, 62, 165, 27,labelRect,false,DmainRectImg)--56
		mclRect = DGS:dgsCreateImage(200, 62, 165, 27,labelRect,false,DmainRectImg)
		boatlRect = DGS:dgsCreateImage(25, 99, 110, 27,labelRect,false,DmainRectImg)
		pilotlRect = DGS:dgsCreateImage(145, 99, 110, 27,labelRect,false,DmainRectImg)
		fishpRect = DGS:dgsCreateImage(265, 99, 100, 27,labelRect,false,DmainRectImg)
		t1glRect = DGS:dgsCreateImage(25, 136, 165, 27,labelRect,false,DmainRectImg)
		t2glRect = DGS:dgsCreateImage(200, 136, 165, 27,labelRect,false,DmainRectImg)
		facRect = DGS:dgsCreateImage(25, 173, 340, 27,labelRect,false,DmainRectImg)
		timeRect = DGS:dgsCreateImage(25, 210, 185, 27,labelRect,false,DmainRectImg)
		tisRect = DGS:dgsCreateImage(220, 210, 145, 27,labelRect,false,DmainRectImg)
		jobRect = DGS:dgsCreateImage(25, 247, 130, 27,labelRect,false,DmainRectImg)
		levelRect = DGS:dgsCreateImage(165, 247, 95, 27,labelRect,false,DmainRectImg)--35
		progRect = DGS:dgsCreateImage(270, 247, 95, 27,labelRect,false,DmainRectImg)--35
		wegRect = DGS:dgsCreateImage(25, 284, 340, 27,labelRect,false,DmainRectImg)
		regDataLbl = DGS:dgsCreateImage(25, 358, 340, 27,labelRect,false,DmainRectImg)
		accnameRect = DGS:dgsCreateImage(25, 395, 165, 27,labelRect,false,DmainRectImg)
		accidRect = DGS:dgsCreateImage(200, 395, 165, 27,labelRect,false,DmainRectImg)
		totalcharRect = DGS:dgsCreateImage(25, 432, 165, 27,labelRect,false,DmainRectImg)
		charidRect = DGS:dgsCreateImage(200, 432, 165, 27,labelRect,false,DmainRectImg)
		rankRect = DGS:dgsCreateImage(25, 469, 340, 27,labelRect,false,DmainRectImg)
		
		line = DGS:dgsCreateLine(25, 335, 340, 27, false, DmainRectImg, 10, tocolor(255, 255, 255, 255))
		DGS:dgsLineAddItem(line,0,0,340,0, 2, tocolor(200,200,200,255),false)
		
		bChangeCharacter = DGS:dgsCreateButton(400, 469, 325, 27, "Change Character", false, DmainRectImg, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
		DGS:dgsSetProperty(bChangeCharacter,"colorTransitionPeriod",1000)
		DGS:dgsSetFont(bChangeCharacter, robotoFont11)
	addEventHandler("onDgsMouseClick", bChangeCharacter,
		function ()
			if not isPedDead ( getLocalPlayer() ) and isCameraOnPlayer() then
				options_logOut( )
			end
			options_closemenu()
		end, false)
		-------------------------------------------Labels [My Character] [First Row]-------------------------------------------
		dobLbl = DGS:dgsCreateLabel(25, 25, 340, 27, "  Data of Birth: #0770C4" .. exports.global:getPlayerDoB(localPlayer), false, DmainRectImg, _, _, _, _, _, _, _, "center")
		dlLbl = DGS:dgsCreateLabel(25, 62, 340, 27, "  Driver License: " .. carlicense, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		mclLbl = DGS:dgsCreateLabel(200, 62, 340, 27, "  Motorcycle License: " .. bikelicense, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		boatlLbl = DGS:dgsCreateLabel(25, 99, 340, 27, "  Boat License: " .. boatlicense, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		pilotlLbl = DGS:dgsCreateLabel(145, 99, 340, 27, "  Pilot License: " .. pilotlicense, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		fishpLbl = DGS:dgsCreateLabel(265, 99, 340, 27, "  Fish Permit: " .. fishlicense, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		t1gLbl = DGS:dgsCreateLabel(25, 136, 340, 27, "  Tier 1 Firearms License: " .. gunlicense, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		t2gLbl = DGS:dgsCreateLabel(200, 136, 340, 27, "  Tier 2 Firearms License: " .. gun2license, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		facLbl = DGS:dgsCreateLabel(25, 173, 340, 27, "  Faction: #0770C4" .. facName, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		timeLbl = DGS:dgsCreateLabel(25, 210, 340, 27, "  Time Spent on Character: #0770C4" .. hours, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		tisLbl = DGS:dgsCreateLabel(220, 210, 340, 27, "  Time on Server: #0770C4" .. getElementData(localPlayer, "timeinserver") or 0, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		jobLbl = DGS:dgsCreateLabel(25, 247, 340, 27, "  Job: #0770C4" .. jobName, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		levelLbl = DGS:dgsCreateLabel(165, 247, 340, 27, "  Level: #0770C4" .. getElementData(localPlayer, "jobLevel") or 1, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		progLbl = DGS:dgsCreateLabel(270, 247, 340, 27, "  Progress: #0770C4" .. getElementData(localPlayer, "jobProgress") or 0, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		wegLbl = DGS:dgsCreateLabel(25, 284, 340, 27, carried, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		ranklLbl = DGS:dgsCreateLabel(25, 469, 340, 27, "  Rank: #0770C4" .. rank, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		regdataLbl = DGS:dgsCreateLabel(25, 358, 340, 27, "  Registration Date: #0770C4" .. regData, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		accnameLbl = DGS:dgsCreateLabel(25, 395, 340, 27, "  Account Name: #0770C4" .. accName, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		accidLbl = DGS:dgsCreateLabel(200, 395, 340, 27, "  Account ID: #0770C4" .. accID, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		totalcharLbl = DGS:dgsCreateLabel(25, 432, 340, 27, "  Total Characters:  #0770C4" .. #_char, false, DmainRectImg, _, _, _, _, _, _, _, "center")
		charidLbl = DGS:dgsCreateLabel(200, 432, 340, 27, "  Current Character ID:  #0770C4" .. getElementData(localPlayer, "account:character:id"), false, DmainRectImg, _, _, _, _, _, _, _, "center")
		
		DGS:dgsSetProperty(dobLbl,"colorCoded",true)
		DGS:dgsSetProperty(dlLbl,"colorCoded",true)
		DGS:dgsSetProperty(mclLbl,"colorCoded",true)
		DGS:dgsSetProperty(boatlLbl,"colorCoded",true)
		DGS:dgsSetProperty(pilotlLbl,"colorCoded",true)
		DGS:dgsSetProperty(fishpLbl,"colorCoded",true)
		DGS:dgsSetProperty(t1gLbl,"colorCoded",true)
		DGS:dgsSetProperty(t2gLbl,"colorCoded",true)
		DGS:dgsSetProperty(timeLbl,"colorCoded",true)
		DGS:dgsSetProperty(tisLbl,"colorCoded",true)
		DGS:dgsSetProperty(facLbl,"colorCoded",true)
		DGS:dgsSetProperty(regdataLbl,"colorCoded",true)
		DGS:dgsSetProperty(jobLbl,"colorCoded",true)
		DGS:dgsSetProperty(levelLbl,"colorCoded",true)
		DGS:dgsSetProperty(progLbl,"colorCoded",true)
		DGS:dgsSetProperty(wegLbl,"colorCoded",true)
		DGS:dgsSetProperty(ranklLbl,"colorCoded",true)
		DGS:dgsSetProperty(accnameLbl,"colorCoded",true)
		DGS:dgsSetProperty(accidLbl,"colorCoded",true)
		DGS:dgsSetProperty(totalcharLbl,"colorCoded",true)
		DGS:dgsSetProperty(charidLbl,"colorCoded",true)

		DGS:dgsSetFont(dobLbl, robotoFont10)
		DGS:dgsSetFont(dlLbl, robotoFont10)
		DGS:dgsSetFont(mclLbl, robotoFont10)
		DGS:dgsSetFont(boatlLbl, robotoFont10)
		DGS:dgsSetFont(pilotlLbl, robotoFont10)
		DGS:dgsSetFont(fishpLbl, robotoFont10)
		DGS:dgsSetFont(t1gLbl, robotoFont10)
		DGS:dgsSetFont(t2gLbl, robotoFont10)
		DGS:dgsSetFont(timeLbl, robotoFont10)
		DGS:dgsSetFont(tisLbl, robotoFont10)
		DGS:dgsSetFont(facLbl, robotoFont10)
		DGS:dgsSetFont(regdataLbl, robotoFont10)
		DGS:dgsSetFont(jobLbl, robotoFont10)
		DGS:dgsSetFont(levelLbl, robotoFont10)
		DGS:dgsSetFont(progLbl, robotoFont10)
		DGS:dgsSetFont(wegLbl, robotoFont10)
		DGS:dgsSetFont(ranklLbl, robotoFont10)
		DGS:dgsSetFont(accnameLbl, robotoFont10)
		DGS:dgsSetFont(accidLbl, robotoFont10)
		DGS:dgsSetFont(totalcharLbl, robotoFont10)
		DGS:dgsSetFont(charidLbl, robotoFont10)
		-------------------------------------------Rectangle [My Properties] [Second Row]-------------------------------------------
		moneyRect = DGS:dgsCreateRoundRect(0, false,tocolor(5,91,166,255))
		moneynbankRect = DGS:dgsCreateRoundRect(0, false,tocolor(2,113,104,255))
		vehRect = DGS:dgsCreateRoundRect(0, false,tocolor(136,103,48,255))
		proRect = DGS:dgsCreateRoundRect(0, false,tocolor(176,57,47,255))
		
		moneyRectImg = DGS:dgsCreateImage(25, 25, 173, 124,moneyRect,false,DpropRectImg)
		moneynbankRectImg = DGS:dgsCreateImage(205, 25, 173, 124,moneynbankRect,false,DpropRectImg)
		vehRectImg = DGS:dgsCreateImage(385, 25, 173, 124,vehRect,false,DpropRectImg)
		proRectImg = DGS:dgsCreateImage(565, 25, 173, 124,proRect,false,DpropRectImg)
		
		moneyImg = DGS:dgsCreateImage(25, 25, 55, 55,":resources/coins.png",false,moneyRectImg)--235, 80, 70, 70 --53, 25
		moneynbankImg = DGS:dgsCreateImage(25, 25, 55, 55,":resources/bank.png",false,moneynbankRectImg)--418, 80, 50, 50
		vehImg = DGS:dgsCreateImage(25, 25, 55, 55,":resources/vehicless.png",false,vehRectImg)--601, 80, 50, 50
		proImg = DGS:dgsCreateImage(25, 25, 55, 55,":resources/property.png",false,proRectImg)--784, 80, 70, 70
		
		DGS:dgsCenterElement(moneyImg)
		DGS:dgsCenterElement(moneynbankImg)
		DGS:dgsCenterElement(vehImg)
		DGS:dgsCenterElement(proImg)

		-------------------------------------------Labels & Grid [My Properties] [Second Row]-------------------------------------------
		
		moneyLbl = DGS:dgsCreateLabel(10, 5, 509, 35, "Money", false, moneyRectImg, tocolor(200, 200, 200, 255))
		amntMoneyLbl = DGS:dgsCreateLabel(-5, 100, 173, 35, money.."$", false, moneyRectImg, tocolor(200, 200, 200, 255))--130
		DGS:dgsSetProperty(moneyLbl,"font",robotoFont11)
		DGS:dgsSetProperty(amntMoneyLbl,"font",robotoFont11)
		DGS:dgsLabelSetHorizontalAlign(amntMoneyLbl, "right", false)   
		
		moneynbankLbl = DGS:dgsCreateLabel(10, 5, 509, 35, "Money in Bank", false, moneynbankRectImg, tocolor(200, 200, 200, 255))
		DGS:dgsSetProperty(moneynbankLbl,"font",robotoFont11)
		amntmoneynbankLbl = DGS:dgsCreateLabel(-5, 100, 173, 35, bmoney.."$", false, moneynbankRectImg, tocolor(200, 200, 200, 255))--120
		DGS:dgsSetProperty(amntmoneynbankLbl,"font",robotoFont11)
		DGS:dgsLabelSetHorizontalAlign(amntmoneynbankLbl, "right", false)  
		vehLbl = DGS:dgsCreateLabel(10, 5, 509, 35, "Vehicles", false, vehRectImg, tocolor(200, 200, 200, 255))
        vehNumLbl = DGS:dgsCreateLabel(-5, 100, 173, 35, printCar, false, vehRectImg, tocolor(200, 200, 200, 255))
		DGS:dgsSetProperty(vehLbl,"font",robotoFont11)
		DGS:dgsSetProperty(vehNumLbl,"font",robotoFont11)
		DGS:dgsLabelSetHorizontalAlign(vehNumLbl, "right", false)   
		proLbl = DGS:dgsCreateLabel(10, 5, 509, 35, "Properties", false, proRectImg, tocolor(200, 200, 200, 255))
		DGS:dgsSetProperty(proLbl,"font",robotoFont11)
		proNumLbl = DGS:dgsCreateLabel(-5, 100, 173, 35, numproperties .. "/".. maxint, false, proRectImg, tocolor(200, 200, 200, 255)) --guiCreateLabel(0.015, 0.935, 0.95, 0.15, tostring(motd), true, tabOverview)
		DGS:dgsSetProperty(proNumLbl,"font",robotoFont11)
		DGS:dgsSetProperty(vehNumLbl,"colorCoded",true)
		DGS:dgsLabelSetHorizontalAlign(proNumLbl, "right", false)  
		
		vehGrid = DGS:dgsCreateGridList(25, 180, 713, 150, false, DpropRectImg, _, tocolor(5,5,5,255), _, tocolor(5,5,5,255))
		proGrid = DGS:dgsCreateGridList(25, 350, 713, 150, false, DpropRectImg, _, tocolor(5,5,5,255), _, tocolor(5,5,5,255))
		
		local ovid = DGS:dgsGridListAddColumn( vehGrid, "", 0.09 )
		local ov = DGS:dgsGridListAddColumn( vehGrid, "", 0.45 )
		local ovcp = DGS:dgsGridListAddColumn( vehGrid, "", 0.1 )
		
		local proid = DGS:dgsGridListAddColumn( proGrid, "", 0.09 )
		local proloc = DGS:dgsGridListAddColumn( proGrid, "", 0.25 )
		local protype = DGS:dgsGridListAddColumn( proGrid, "", 0.15 )
		local procost = DGS:dgsGridListAddColumn( proGrid, "", 0.15 )
		local proname = DGS:dgsGridListAddColumn( proGrid, "", 0.25 )
		
		for i,r in ipairs(vehicleList) do
		local row = DGS:dgsGridListAddRow(vehGrid)
		local vid = r[1]
		local v = r[2]
		local vm = getElementModel(v)
		DGS:dgsGridListSetItemText(vehGrid, row, ovid, tostring(vid), false, false)
		DGS:dgsGridListSetItemText(vehGrid, row, ov, exports.global:getVehicleName(v) , false, false) --tostring(getVehicleNameFromModel(vm))
		DGS:dgsGridListSetItemText(vehGrid, row, ovcp, tostring(getVehiclePlateText(v) or ""), false, false)
		DGS:dgsGridListSetRowBackGroundColor(vehGrid,row,tocolor(25, 25, 25, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
	end
		for i, v in ipairs (interiorList) do
			local row = DGS:dgsGridListAddRow(proGrid)
			local id = interiorList[i][1]
			local x = interiorList[i][2]
			local y = interiorList[i][3]
			local z = interiorList[i][4]
			local typee = interiorList[i][5]
			local cost = interiorList[i][6]
			local name = interiorList[i][7]
			local location = getZoneName(x, y, z)
		DGS:dgsGridListSetItemText(proGrid, row, proid, tostring(id), false, false)
		DGS:dgsGridListSetItemText(proGrid, row, proloc, tostring(location), false, false)
		if typee == 0 then
		outputChatBox("House")
		--DGS:dgsGridListSetItemText(proGrid, row, protype, "House", false, false)
		end
		if tostring(typee) == 1 then
		DGS:dgsGridListSetItemText(proGrid, row, protype, "Business", false, false)
		end
		if tostring(typee) == 2 then
		DGS:dgsGridListSetItemText(proGrid, row, protype, "Government", false, false)
		end
		if tostring(typee) == 3 then
		DGS:dgsGridListSetItemText(proGrid, row, protype, "Rentable", false, false)
		end
		DGS:dgsGridListSetItemText(proGrid, row, procost, tostring(cost), false, false)
		DGS:dgsGridListSetItemText(proGrid, row, proname, tostring(name), false, false)
		DGS:dgsGridListSetRowBackGroundColor(proGrid,row,tocolor(25, 25, 25, 200),tocolor(7, 112, 196,200),tocolor(7, 112, 196,255))
	end
		--local column = DGS:dgsGridListAddColumn( proGrid, "", 0.95 )
		DGS:dgsGridListSetColumnHeight(vehGrid, 0)
		DGS:dgsSetProperty(vehGrid,"font",robotoFont11)
		DGS:dgsSetProperty(vehGrid,"rowHeight",40)
		DGS:dgsSetProperty(proGrid,"rowHeight",40)
		
		premiumloadLbl = DGS:dgsCreateLabel(315, 220, 509, 35, "Loading ...", false, DpremiumRectImg, tocolor(200, 200, 200, 255))
		radioloadLbl = DGS:dgsCreateLabel(315, 220, 509, 35, "Loading ...", false, DradioRectImg, tocolor(200, 200, 200, 255))

		DGS:dgsSetProperty(premiumloadLbl,"font",robotoFont11)
		DGS:dgsSetProperty(radioloadLbl,"font",robotoFont11)
		-------------------------------------------Memo [Help] [Fifth Row]-------------------------------------------
		
			helpMemo = DGS:dgsCreateMemo(25,25,695,460,"  Hello And Enjoy",false,DhelpRectImg)
			DGS:dgsMemoSetReadOnly( helpMemo, true )
			DGS:dgsSetProperty(helpMemo,"bgColor",tocolor(20, 20, 20, 255))
			DGS:dgsSetProperty(helpMemo,"font",robotoFont10)
    end
addEvent("propertiesInfo", true)
addEventHandler("propertiesInfo", getRootElement(), options_showmenu)
--addEventHandler("onClientResourceStart", getRootElement(), dashboard)

addEventHandler ( "onDgsMouseClickDown", root, function ( button, state  )
	if source == maingrid then 
		local Selected = DGS:dgsGridListGetSelectedItem(maingrid)
		if Selected == 1 then 
			DGS:dgsSetVisible(DmainRectImg, true)
			DGS:dgsSetAlpha(DmainRectImg,0)
			DGS:dgsAlphaTo(DmainRectImg,1,"Linear",500)
			DGS:dgsSetVisible(DpropRectImg, false)
			DGS:dgsSetVisible(DpremiumRectImg, false)
			DGS:dgsSetVisible(DredemRectImg, false)
			DGS:dgsSetVisible(DradioRectImg, false)
			DGS:dgsSetVisible(DsettRectImg, false)
			DGS:dgsSetVisible(DhelpRectImg, false)
		elseif Selected == 2 then
			DGS:dgsSetVisible(DpropRectImg, true)
			DGS:dgsSetAlpha(DpropRectImg,0)
			DGS:dgsAlphaTo(DpropRectImg,1,"Linear",500)
			DGS:dgsSetVisible(DmainRectImg, false)
			DGS:dgsSetVisible(DpremiumRectImg, false)
			DGS:dgsSetVisible(DredemRectImg, false)
			DGS:dgsSetVisible(DradioRectImg, false)
			DGS:dgsSetVisible(DsettRectImg, false)
			DGS:dgsSetVisible(DhelpRectImg, false)
			--executeCommandHandler("radios")
		elseif Selected == 3 then
			DGS:dgsSetVisible(DpremiumRectImg, true)
			DGS:dgsSetAlpha(DpremiumRectImg,0)
			DGS:dgsAlphaTo(DpremiumRectImg,1,"Linear",500)
			DGS:dgsSetVisible(DpropRectImg, false)
			DGS:dgsSetVisible(DredemRectImg, false)
			DGS:dgsSetVisible(DradioRectImg, false)
			DGS:dgsSetVisible(DmainRectImg, false)
			DGS:dgsSetVisible(DsettRectImg, false)
			DGS:dgsSetVisible(DhelpRectImg, false)
			--triggerEvent("donation-system:GUI:opens", localPlayer, DpremiumRectImg)
			setTimer (function ()
			triggerEvent("donation-system:GUI:opens", localPlayer, DpremiumRectImg)
			DGS:dgsSetText(premiumloadLbl, "")
			end, 100, 1)
			triggerServerEvent("donation-system:GUI:open", localPlayer)
		
		elseif Selected == 4 then
			DGS:dgsSetVisible(DredemRectImg, true)
			DGS:dgsSetAlpha(DredemRectImg,0)
			DGS:dgsAlphaTo(DredemRectImg,1,"Linear",500)
			DGS:dgsSetVisible(DpropRectImg, false)
			DGS:dgsSetVisible(DpremiumRectImg, false)
			DGS:dgsSetVisible(DradioRectImg, false)
			DGS:dgsSetVisible(DmainRectImg, false)
			DGS:dgsSetVisible(DhelpRectImg, false)
			DGS:dgsSetVisible(DsettRectImg, false)
			triggerEvent("redeem-system:GUI:opens", localPlayer, DredemRectImg)
		
		elseif Selected == 5 then
			DGS:dgsSetVisible(DradioRectImg, true)
			DGS:dgsSetAlpha(DradioRectImg,0)
			DGS:dgsAlphaTo(DradioRectImg,1,"Linear",500)
			DGS:dgsSetVisible(DpropRectImg, false)
			DGS:dgsSetVisible(DpremiumRectImg, false)
			DGS:dgsSetVisible(DredemRectImg, false)
			DGS:dgsSetVisible(DmainRectImg, false)
			DGS:dgsSetVisible(DsettRectImg, false)
			DGS:dgsSetVisible(DhelpRectImg, false)
			triggerServerEvent("openRadioManager", localPlayer)
			setTimer (function ()
			triggerEvent("openRadioManagers", localPlayer, DradioRectImg)
			DGS:dgsSetText(radioloadLbl, "")
			end, 100, 1)
		
		elseif Selected == 6 then
			DGS:dgsSetVisible(DhelpRectImg, true)
			DGS:dgsSetAlpha(DhelpRectImg,0)
			DGS:dgsAlphaTo(DhelpRectImg,1,"Linear",500)
			DGS:dgsSetVisible(DpropRectImg, false)
			DGS:dgsSetVisible(DpremiumRectImg, false)
			DGS:dgsSetVisible(DredemRectImg, false)
			DGS:dgsSetVisible(DradioRectImg, false)
			DGS:dgsSetVisible(DmainRectImg, false)
			DGS:dgsSetVisible(DsettRectImg, false)
			
		elseif Selected == 7 then
			DGS:dgsSetVisible(DsettRectImg, true)
			DGS:dgsSetAlpha(DsettRectImg,0)
			DGS:dgsAlphaTo(DsettRectImg,1,"Linear",500)
			DGS:dgsSetVisible(DpropRectImg, false)
			DGS:dgsSetVisible(DpremiumRectImg, false)
			DGS:dgsSetVisible(DredemRectImg, false)
			DGS:dgsSetVisible(DradioRectImg, false)
			DGS:dgsSetVisible(DmainRectImg, false)
			DGS:dgsSetVisible(DhelpRectImg, false)
			--options_opengraphicsmenu()
			triggerEvent("accounts:settings:fetchSettings", localPlayer, DsettRectImg)
			showSettingsWindow()
		end
	end
end )

function options_closemenu()
	options_closegraphicsmenu()
	closeSettingsWindow()
	showCursor(false)
	if wOptions then
		destroyElement(wOptions)
		destroyElement(background)
		--destroyElement(logo)
		destroyElement(blurArea)
		destroyElement(blurbox)
		wOptions = nil
		exports.object_preview:destroyObjectPreview(objPrev)
		destroyElement(myElement)
	end
	setElementData(getLocalPlayer(), "exclusiveGUI", false, false)
	triggerEvent( 'hud:blur', resourceRoot, 'off', true )
end

function options_cameraWorkAround()
	setControlState("change_camera", true)
end


--MAXIME
function options_opengraphicsmenu()
	gameMenuLoaded = false
	local screenWidth, screenHeight = guiGetScreenSize()
	local windowWidth, windowHeight = 200, 350+17
	local left = screenWidth/2 - windowWidth/2
	local top = screenHeight/2 - windowHeight/2
	local enable = 1

	guiSetEnabled(wOptions, false)

	--wGraphicsMenu = guiCreateWindow(left, top, windowWidth, windowHeight, "Game options", false)
	--guiWindowSetSizable(wGraphicsMenu, false)
	----------

	cMotionBlur = DGS:dgsCreateCheckBox(10, 25, 180, 17, "Enable motion blur", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cMotionBlur, options_updateGameConfig)
	-----------
	cSkyClouds = DGS:dgsCreateCheckBox(10, 45, 180, 17, "Enable Sky clouds", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cSkyClouds, options_updateGameConfig)
	------------
	cStreamingAudio = DGS:dgsCreateCheckBox(10, 65, 180, 17, "Enable streaming audio", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cStreamingAudio, options_updateGameConfig)

	bOverlayDescription = Dharma:dgsCreateButton ( 10, 85, 180, 17*2, "Overlay Description Settings", false, DsettRectImg )
	addEventHandler("onDgsMouseClickDown", bOverlayDescription, overlayDescSettings)

	--[[lVehicleStreamer = guiCreateCheckBox ( 10, 95, 180, 17, "Vehicle streamer: Disabled", false, false, wGraphicsMenu )
	addEventHandler("onDgsMouseClickDown", lVehicleStreamer, options_updateGameConfig)

	sVehicleStreamer = guiCreateScrollBar(10, 110, 180, 17, true, false, wGraphicsMenu)
	addEventHandler("onClientGUIScroll", sVehicleStreamer, options_GameConfig_updateScrollbars)

	lPickupStreamer = guiCreateCheckBox ( 10, 125, 180, 17, "Interior streamer: Disabled", false, false, wGraphicsMenu )
	addEventHandler("onDgsMouseClickDown", lPickupStreamer, options_updateGameConfig)

	sPickupStreamer = guiCreateScrollBar(10, 140, 180, 17, true, false, wGraphicsMenu)
	addEventHandler("onClientGUIScroll", sPickupStreamer, options_GameConfig_updateScrollbars)]]

	cLogsEnabled = DGS:dgsCreateCheckBox(10, 160, 180, 17, "Logging of chat", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cLogsEnabled, options_updateGameConfig)

	cBubblesEnabled = DGS:dgsCreateCheckBox(10, 180, 180, 17, "Enable Chat bubbles", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cBubblesEnabled, options_updateGameConfig)

	cIconsEnabled = DGS:dgsCreateCheckBox(10, 200, 180, 17, "Enable typing icons", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cIconsEnabled, options_updateGameConfig)

	cEnableNametags = DGS:dgsCreateCheckBox(10, 220, 180, 17, "Enable nametags", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cEnableNametags, options_updateGameConfig)

	cEnableRShaders = DGS:dgsCreateCheckBox(10, 240, 180, 17, "Enable radar shader", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cEnableRShaders, options_updateGameConfig)

	cEnableWShaders = DGS:dgsCreateCheckBox(10, 260, 180, 17, "Enable water shader", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cEnableWShaders, options_updateGameConfig)

	cEnableVShaders = DGS:dgsCreateCheckBox(10, 280, 180, 17, "Enable vehicle shader", false, false, DsettRectImg)
	addEventHandler("onDgsMouseClickDown", cEnableVShaders, options_updateGameConfig)

	--[[
	chatbubbles
	]]

	-- Put the current settings selected/active

	--[[local vehicleStreamerEnabled = tonumber( loadSavedData("streamer-vehicle-enabled", "1") )
	if (vehicleStreamerEnabled) then
		guiCheckBoxSetSelected ( lVehicleStreamer, true )
	end

	local pickupStreamerEnabled = tonumber( loadSavedData("streamer-pickup-enabled", "1") )
	if (pickupStreamerEnabled) then
		guiCheckBoxSetSelected ( lPickupStreamer, true )
	end]]

	local blurEnabled = tonumber( loadSavedData("motionblur", "1") )
	if (blurEnabled == 1) then
		DGS:dgsCheckBoxSetSelected ( cMotionBlur, true )
	end


	local skyCloudsEnabled = tonumber( loadSavedData("skyclouds", "1") )
	if (skyCloudsEnabled == 1) then
		DGS:dgsCheckBoxSetSelected ( cSkyClouds, true )
	end

	local streamingMediaEnabled = tonumber( loadSavedData("streamingmedia", "1") )
	if (streamingMediaEnabled == 1) then
		DGS:dgsCheckBoxSetSelected ( cStreamingAudio, true )
	end

	local logsEnabled = tonumber( loadSavedData("logsenabled", "1") )
	if (logsEnabled == 1) then
		DGS:dgsCheckBoxSetSelected ( cLogsEnabled, true )
	end

	--[[local vehicleStreamerStatus = tonumber( loadSavedData("streamer-vehicle", "60") )
	if (vehicleStreamerStatus) then
		guiScrollBarSetScrollPosition(sVehicleStreamer, ((vehicleStreamerStatus-40)/2))
	end

	local pickupStreamerStatus = tonumber( loadSavedData("streamer-pickup", "25") )
	if (pickupStreamerStatus) then
		guiScrollBarSetScrollPosition(sPickupStreamer, (pickupStreamerStatus-10))
	end]]

	local isBubblesEnabled = tonumber( loadSavedData("chatbubbles", "1") )
	if (isBubblesEnabled == 1) then
		DGS:dgsCheckBoxSetSelected ( cBubblesEnabled, true )
	end

	local isChatIconsEnabled = tonumber( loadSavedData("chaticons", "1") )
	if (isChatIconsEnabled == 1) then
		DGS:dgsCheckBoxSetSelected ( cIconsEnabled, true )
	end

	local isNameTagsEnabled = tonumber( loadSavedData("shownametags", "1") )
	if (isNameTagsEnabled == 1) then
		DGS:dgsCheckBoxSetSelected ( cEnableNametags, true )
	end

	local isRShaderEnabled = tonumber( loadSavedData( "enable_radar_shader", "1") )
	if isRShaderEnabled == 1 then
		DGS:dgsCheckBoxSetSelected ( cEnableRShaders, true )
	end

	local isWShaderEnabled = tonumber( loadSavedData( "enable_water_shader", "1") )
	if isWShaderEnabled == 1 then
		DGS:dgsCheckBoxSetSelected ( cEnableWShaders, true )
	end

	local isVShaderEnabled = tonumber( loadSavedData( "enable_vehicle_shader", "1") )
	if isVShaderEnabled == 1 then
		DGS:dgsCheckBoxSetSelected ( cEnableVShaders, true )
	end

	gameMenuLoaded = true
	--options_GameConfig_updateScrollbars()

	--bGraphicsMenuClose = Dharma:dgsCreateButton(10, 320, 490, 17*2, "Close", false, wGraphicsMenu)
	--addEventHandler("onDgsMouseClick", bGraphicsMenuClose, options_closegraphicsmenu, false)
end

--[[function options_GameConfig_updateScrollbars()
	if (gameMenuLoaded) then
		local vehicleStreamerStatus = guiScrollBarGetScrollPosition(sVehicleStreamer)
		vehicleStreamerStatus = ((vehicleStreamerStatus) * 2) + 40

		local pickupStreamerStatus = guiScrollBarGetScrollPosition(sPickupStreamer)
		pickupStreamerStatus = pickupStreamerStatus + 10

		guiSetText(lVehicleStreamer, "Vehicle streamer: "..vehicleStreamerStatus.." meter")
		guiSetText(lPickupStreamer, "Interior streamer: "..pickupStreamerStatus.." meter")

		appendSavedData("streamer-vehicle", tostring(vehicleStreamerStatus))
		appendSavedData("streamer-pickup", tostring(pickupStreamerStatus))

		triggerEvent("accounts:settings:loadGraphicSettings", getLocalPlayer())
	end
end]]

--MAXIME
function overlayDescSettings(button, state)
	if source == bOverlayDescription then
		if wOverlayDescSettings then
			fCloseOverlayDescSettings()
		else

			local screenWidth, screenHeight = guiGetScreenSize()
			local windowWidth, windowHeight = 350, 40+(20*15)
			local left = screenWidth/2 - windowWidth/2
			local top = screenHeight/2 - windowHeight/2
			local enable = 1

			DGS:dgsSetEnabled(wOptions, false)
			DGS:dgsSetEnabled(DsettRectImg, false)

			wOverlayDescSettings = DGS:dgsCreateWindow(left, top, windowWidth, windowHeight, "Overlay Description Options", false)
			DGS:dgsWindowSetSizable(wOverlayDescSettings, false)
			----------
			local y = 0
			local lane1w = 230
			local lane1x = 10
			local lane2w = lane1w + lane1x
			local lane2x = lane1x*2 + lane1w
			cEnableDescription = DGS:dgsCreateCheckBox(10, 25+y, lane1w, 17, "Enable All Overlay Description", true, false, wOverlayDescSettings)
			addEventHandler("onDgsMouseClickDown", cEnableDescription, options_updateGameConfig)
			enable = tonumber( loadSavedData("enableOverlayDescription", "1") or 1)
			DGS:dgsCheckBoxSetSelected ( cEnableDescription, enable == 1 and true or false)
			DGS:dgsCreateImage ( 10, 25+y+23, windowWidth-20 , 1, ":admin-system/images/whitedot.jpg", false, wOverlayDescSettings )
			y = y + 30

			cEnableDescriptionVeh = DGS:dgsCreateCheckBox(10, 25+y, lane1w, 17, "Enable Overlay Description (Vehicle)", true, false, wOverlayDescSettings)
			addEventHandler("onDgsMouseClickDown", cEnableDescriptionVeh, options_updateGameConfig)
			enable = tonumber( loadSavedData("enableOverlayDescriptionVeh", "1") or 1 )
			DGS:dgsCheckBoxSetSelected ( cEnableDescriptionVeh, enable == 1 and true or false)

			cEnableDescriptionVehPin = DGS:dgsCreateCheckBox(lane2x, 25+y, lane2w, 17, "Pin", false, false, wOverlayDescSettings)
			addEventHandler("onDgsMouseClickDown", cEnableDescriptionVehPin, options_updateGameConfig)
			enable = tonumber( loadSavedData("enableOverlayDescriptionVehPin", "1") or 1 )
			DGS:dgsCheckBoxSetSelected ( cEnableDescriptionVehPin, enable == 1 and true or false)

			y = y + 20

			lFontVeh = DGS:dgsCreateLabel ( 10, 25+y+3, 40, 20,  "Font:", false, wOverlayDescSettings )
			cFontVeh = DGS:dgsCreateComboBox ( 10+40, 25+y, lane1w, 20,  loadSavedData2("cFontVeh") or "default", false, wOverlayDescSettings )
			local count1 = 0
			for key, font in pairs(fonts) do
				DGS:dgsComboBoxAddItem(cFontVeh, type(font[1]) == "string" and font[1] or "BizNoteFont18")
				count1 = count1 + 1
			end
			--DGS:dgsComboBoxSetBoxHeight ( cFontVeh, 20 )
			addEventHandler ( "onDgsComboBoxSelect", guiRoot,
				function ( comboBox )
					if ( comboBox == cFontVeh ) then
						local item = DGS:dgsComboBoxGetSelected ( cFontVeh )
						local text = tostring ( DGS:dgsComboBoxGetItemText ( cFontVeh , item ) )
						if ( text ~= "" ) then
							 appendSavedData("cFontVeh", text)
						end
					end
				end
			)

			y = y + 20 + 5

			bgVeh = DGS:dgsCreateCheckBox ( 10, 25+y+3, 150, 17,  "Enable Background", true, false, wOverlayDescSettings )
			enable = tonumber( loadSavedData("bgVeh", "1") or 1 )
			DGS:dgsCheckBoxSetSelected ( bgVeh, enable == 1 and true or false)

			borderVeh = DGS:dgsCreateCheckBox ( 10+150, 25+y+3, 150, 17, "Enable Border", true, false, wOverlayDescSettings )
			enable = tonumber( loadSavedData("borderVeh", "1") or 1)
			DGS:dgsCheckBoxSetSelected ( borderVeh, enable == 1 and true or false)

			addEventHandler("onDgsMouseClickDown", bgVeh, options_updateGameConfig)
			addEventHandler("onDgsMouseClickDown", borderVeh, options_updateGameConfig)

			DGS:dgsCreateImage ( 10, 25+y+21, windowWidth-20 , 1, ":admin-system/images/whitedot.jpg", false, wOverlayDescSettings )

			y = y + 40

			cEnableOverlayDescriptionPro = DGS:dgsCreateCheckBox(10, 25+y, lane1w, 17, "Enable Overlay Description (Property)", true, false, wOverlayDescSettings)
			addEventHandler("onDgsMouseClickDown", cEnableOverlayDescriptionPro, options_updateGameConfig)
			enable = tonumber( loadSavedData("enableOverlayDescriptionPro", "1") or 1 )
			DGS:dgsCheckBoxSetSelected ( cEnableOverlayDescriptionPro, enable == 1 and true or false)

			cEnableOverlayDescriptionProPin = DGS:dgsCreateCheckBox(lane2x, 25+y, lane2w, 17, "Pin", false, false, wOverlayDescSettings)
			addEventHandler("onDgsMouseClickDown", cEnableOverlayDescriptionProPin, options_updateGameConfig)
			enable = tonumber( loadSavedData("enableOverlayDescriptionProPin", "1") or 1 )
			DGS:dgsCheckBoxSetSelected ( cEnableOverlayDescriptionProPin, enable == 1 and true or false)

			y = y + 20

			lFontPro = DGS:dgsCreateLabel ( 10, 25+y+3, 40, 20,  "Font:", false, wOverlayDescSettings )
			cFontPro = DGS:dgsCreateComboBox ( 10+40, 25+y, lane1w, 20,  loadSavedData2("cFontPro") , false, wOverlayDescSettings )
			for key, font in pairs(fonts) do
				DGS:dgsComboBoxAddItem(cFontPro, type(font[1]) == "string" and font[1] or "BizNoteFont18")
			end
			--DGS:dgsComboBoxSetBoxHeight ( cFontPro, count1 )
			addEventHandler ( "onDgsComboBoxSelect", guiRoot,
				function ( comboBox )
					if ( comboBox == cFontPro ) then
						local item = DGS:dgsComboBoxGetSelected ( cFontPro )
						local text = tostring ( DGS:dgsComboBoxGetItemText ( cFontPro , item ) )
						if ( text ~= "" ) then
							appendSavedData("cFontPro", text)
						end
					end
				end
			)

			y = y + 20 + 5

			bgPro = DGS:dgsCreateCheckBox ( 10, 25+y+3, 150, 17,  "Enable Background", true, false, wOverlayDescSettings )
			enable = tonumber( loadSavedData("bgPro", "1") or 1 )
			DGS:dgsCheckBoxSetSelected ( bgPro, enable == 1 and true or false)

			borderPro = DGS:dgsCreateCheckBox ( 10+150, 25+y+3, 150, 17, "Enable Border", true,false,  wOverlayDescSettings )
			enable = tonumber( loadSavedData("borderPro", "1") or 1 )
			DGS:dgsCheckBoxSetSelected ( borderPro, enable == 1 and true or false)

			addEventHandler("onDgsMouseClickDown", bgPro, options_updateGameConfig)
			addEventHandler("onDgsMouseClickDown", borderPro, options_updateGameConfig)

			DGS:dgsCreateImage ( 10, 25+y+21, windowWidth-20 , 1, ":admin-system/images/whitedot.jpg", false, wOverlayDescSettings )

			y = y + 40

			--bCloseOverlayDescSettings = Dharma:dgsCreateButton(10, 70+y, windowWidth+34, 17*2, "Close", false, wOverlayDescSettings)
			--addEventHandler("onDgsMouseClick", bCloseOverlayDescSettings, fCloseOverlayDescSettings, false)
		end
	end
end

--MAXIME--
function options_updateGameConfig()
	if source == borderVeh then
		appendSavedData("borderVeh", DGS:dgsCheckBoxGetSelected(borderVeh) and "1" or "0")
	end

	if source == bgVeh then
		appendSavedData("bgVeh", DGS:dgsCheckBoxGetSelected(bgVeh) and "1" or "0")
	end

	if source == borderPro then
		appendSavedData("borderPro", DGS:dgsCheckBoxGetSelected(borderPro) and "1" or "0")
	end

	if source == bgPro then
		appendSavedData("bgPro", DGS:dgsCheckBoxGetSelected(bgPro) and "1" or "0")
	end

	if source == cEnableDescription then
		appendSavedData("enableOverlayDescription", DGS:dgsCheckBoxGetSelected(cEnableDescription) and "1" or "0")
	end

	if source == cEnableDescriptionVeh then
		appendSavedData("enableOverlayDescriptionVeh", DGS:dgsCheckBoxGetSelected(cEnableDescriptionVeh) and "1" or "0")
	end

	if source == cEnableDescriptionVehPin then
		appendSavedData("enableOverlayDescriptionVehPin", DGS:dgsCheckBoxGetSelected(cEnableDescriptionVehPin) and "1" or "0")
	end

	if source == cEnableOverlayDescriptionPro then
		appendSavedData("enableOverlayDescriptionPro", DGS:dgsCheckBoxGetSelected(cEnableOverlayDescriptionPro) and "1" or "0")
	end

	if source == cEnableOverlayDescriptionProPin then
		appendSavedData("enableOverlayDescriptionProPin", DGS:dgsCheckBoxGetSelected(cEnableOverlayDescriptionProPin) and "1" or "0")
	end


	if source == cMotionBlur then
		if (DGS:dgsCheckBoxGetSelected(cMotionBlur)) then
			appendSavedData("motionblur", "1")
		else
			appendSavedData("motionblur", "0")
		end
	end

	if source == cSkyClouds then
		if (DGS:dgsCheckBoxGetSelected(cSkyClouds)) then
			appendSavedData("skyclouds", "1")
		else
			appendSavedData("skyclouds", "0")
		end
	end

	if source == cStreamingAudio then
		if (DGS:dgsCheckBoxGetSelected(cStreamingAudio)) then
			appendSavedData("streamingmedia", "1")
		else
			appendSavedData("streamingmedia", "0")
		end
	end

	if source == cLogsEnabled then
		if (DGS:dgsCheckBoxGetSelected(cLogsEnabled)) then
			appendSavedData("logsenabled", "1")
		else
			appendSavedData("logsenabled", "0")
		end
	end

	--[[if (guiCheckBoxGetSelected(lPickupStreamer)) then
		appendSavedData("streamer-pickup-enabled", "1")
	else
		appendSavedData("streamer-pickup-enabled", "0")
	end

	if (guiCheckBoxGetSelected(lVehicleStreamer)) then
		appendSavedData("streamer-vehicle-enabled", "1")
	else
		appendSavedData("streamer-vehicle-enabled", "0")
	end]]

	if source == cBubblesEnabled then
		if (DGS:dgsCheckBoxGetSelected(cBubblesEnabled)) then
			appendSavedData("chatbubbles", "1")
		else
			appendSavedData("chatbubbles", "0")
		end
	end

	if source == cIconsEnabled then
		if (DGS:dgsCheckBoxGetSelected(cIconsEnabled)) then
			appendSavedData("chaticons", "1")
		else
			appendSavedData("chaticons", "0")
		end
	end

	if source == cEnableNametags then
		if (DGS:dgsCheckBoxGetSelected(cEnableNametags)) then
			appendSavedData("shownametags", "1")
		else
			appendSavedData("shownametags", "0")
		end
	end

	if source == cEnableRShaders then
		appendSavedData("enable_radar_shader", DGS:dgsCheckBoxGetSelected(cEnableRShaders) and "1" or "0")
	end

	if source == cEnableWShaders then
		appendSavedData("enable_water_shader", DGS:dgsCheckBoxGetSelected(cEnableWShaders) and "1" or "0")
	end

	if source == cEnableVShaders then
		appendSavedData("enable_vehicle_shader", DGS:dgsCheckBoxGetSelected(cEnableVShaders) and "1" or "0")
	end

	triggerEvent("accounts:settings:loadGraphicSettings", getLocalPlayer())
end



--MAXIME
-- function percentageToLevel(percentage)
	-- if percentage >= 0 and < 20 then
		-- return "5"
	-- elseif percentage >= 20 and < 40 then
		-- return "10"
	-- elseif percentage >= 40 and < 60 then
		-- return "20"
	-- elseif percentage >= 60 and < 80 then
		-- return "40"
	-- elseif percentage >= 80 and < 100 then
		-- return "80"
	-- else
		-- return "160"
	-- end
-- end



function guiComboBoxAdjustHeight ( combobox, itemcount )
	if getElementType ( combobox ) ~= "gui-combobox" or type ( itemcount ) ~= "number" then error ( "Invalid arguments @ 'guiComboBoxAdjustHeight'", 2 ) end
	local width = guiGetSize ( combobox, false )
	return guiSetSize ( combobox, width, ( itemcount * 20 ) + 20, false )
end

function fCloseOverlayDescSettings()
	if wOverlayDescSettings then
		destroyElement(wOverlayDescSettings)
		wOverlayDescSettings = nil
		if wGraphicsMenu then
			guiSetEnabled(wGraphicsMenu, true)
		end
	end
end

function options_closegraphicsmenu()
	if wGraphicsMenu then
		options_updateGameConfig()
		destroyElement(wGraphicsMenu)
		wGraphicsMenu = nil
	end
	fCloseOverlayDescSettings()
	if wOptions then
		DGS:dgsSetEnabled(wOptions, true)
	end
end

function options_logOut( message )
	triggerServerEvent("updateCharacters", getLocalPlayer())
	triggerServerEvent("accounts:characters:change", getLocalPlayer(), "Change Character")
	triggerEvent("onClientChangeChar", getRootElement())
	options_disable()
	Characters_showSelection()
	clearChat()
	if message then
		LoginScreen_showWarningMessage( message )
	end
end
addEventHandler("accounts:logout", getRootElement(), options_logOut)

function options_logOutToLoginPanel( message )
	triggerServerEvent("accounts:characters:logout", getLocalPlayer(), "Change Character")
	open_log_reg_pannel()
end
