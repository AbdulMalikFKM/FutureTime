--[[
* ***********************************************************************************************************************
* Copyright (c) 2015 OwlGaming Community - All Rights Reserved
* All rights reserved. This program and the accompanying materials are private property belongs to OwlGaming Community
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
* ***********************************************************************************************************************
]]

GUIEditor_Window = {}
GUIEditor_TabPanel = {}
GUIEditor_Tab = {}
GUIEditor_Button = {}
GUIEditor_Checkbox = {}
GUIEditor_Label = {}
local screenWidth, screenHeight = guiGetScreenSize()
settings = {}

function showSettingsWindow(DsettRectImg)
	--closeSettingsWindow()
	
	if wOptions and isElement(wOptions) then
		guiSetEnabled(wOptions, false)
	end
	
	if getElementData(getLocalPlayer(), "exclusiveGUI") or not isCameraOnPlayer()  then
		return false
	end
	
	setElementData(getLocalPlayer(), "exclusiveGUI", true, false)
	
	local w, h = 740,474
	local x, y = (screenWidth-w)/2, (screenHeight-h)/2
	--tab = DGS:dgsCreateWindow(x,y,w,h,"Settings",false)
	--guiWindowSetSizable(GUIEditor_Window.main, false)
	--GUIEditor_TabPanel.main = guiCreateTabPanel(0.0122,0.0401,0.9757,0.8692,true,GUIEditor_Window.main)


	--GUIEditor_Tab.graphicSettings = guiCreateTab("General",GUIEditor_TabPanel.main)
	local lineH = 0.0515
	local posY = lineH
	
	GUIEditor_Label.graphicSettingsgeneral = DGS:dgsCreateLabel(0.0222,0.0361,0.313,lineH,"General Configurations:",true,DsettRectImg)
	DGS:dgsSetFont(GUIEditor_Label.graphicSettingsgeneral,"default-bold-small")

	GUIEditor_Checkbox.graphic_motionblur = DGS:dgsCreateCheckBox(0.036,0.1005,0.2992,lineH,"Enable motion blur",false,true,DsettRectImg)
	if getElementData(localPlayer, "graphic_motionblur") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_motionblur,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_motionblur,true)
	end
	
	GUIEditor_Checkbox.graphic_skyclouds = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable sky clouds",false,true,DsettRectImg)
	if getElementData(localPlayer, "graphic_skyclouds") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_skyclouds,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_skyclouds,true)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.streams = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable streaming audio",false,true,DsettRectImg)
	if getResourceFromName("carradio") then
		if getElementData(localPlayer, "streams") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.streams,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.streams,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.streams, false)
	end
	
	posY = posY + lineH
	
	GUIEditor_Checkbox.graphic_logs = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable client logging of chatbox",false,true,DsettRectImg)
	if getResourceFromName("OwlGamingLogs") then
		if getElementData(localPlayer, "graphic_logs") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_logs,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_logs,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_logs, false)
	end

	posY = posY + lineH

	GUIEditor_Checkbox.cellphone_log = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable client logging of calls & SMS",false,true,DsettRectImg)
	if getResourceFromName("OwlGamingLogs") and getResourceFromName("phone") then
		if getElementData(localPlayer, "cellphone_log") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.cellphone_log,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.cellphone_log,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.cellphone_log, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.graphic_chatbub = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable chat bubbles",false,true,DsettRectImg)
	if getResourceFromName("chat-system") then
		if getElementData(localPlayer, "graphic_chatbub") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_chatbub,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_chatbub,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_chatbub, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.graphic_typingicon = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable typing icons",false,true,DsettRectImg)
	if getResourceFromName("chat-system") then
		if getElementData(localPlayer, "graphic_typingicon") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_typingicon,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_typingicon,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_typingicon, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.graphic_nametags = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable nametags",false,true,DsettRectImg)
	if getResourceFromName("hud") then
		if getElementData(localPlayer, "graphic_nametags") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_nametags,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_nametags,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_nametags, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.settings_hud_style = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable new HUD style",false,true,DsettRectImg)
	if getResourceFromName("hud") then
		if getElementData(localPlayer, "settings_hud_style") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.settings_hud_style,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.settings_hud_style,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.settings_hud_style, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.graphic_shaderradar = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable radar shader",false,true,DsettRectImg)
	if getResourceFromName("shader_radar") then
		if getElementData(localPlayer, "graphic_shaderradar") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shaderradar,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shaderradar,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_shaderradar, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.graphic_shaderwater = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable water shader",false,true,DsettRectImg)
		--addEventHandler("onDgsMouseClickDown", GUIEditor_Checkbox.graphic_shaderwater, options_updateGameConfig)
	if getResourceFromName("shader_water") then
		if getElementData(localPlayer, "graphic_shaderwater") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shaderwater,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shaderwater,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_shaderwater, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.graphic_shaderveh = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable vehicle shader",false,true,DsettRectImg)
	if getResourceFromName("shader_car_paint") then
		if getElementData(localPlayer, "graphic_shaderveh") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shaderveh,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shaderveh,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_shaderveh, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.graphic_shaderveh_reflect = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable vehicle shader reflect",false,true,DsettRectImg)
	if getResourceFromName("shader_car_paint_reflect") then
		if getElementData(localPlayer, "graphic_shaderveh_reflect") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shaderveh_reflect,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shaderveh_reflect,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_shaderveh_reflect, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.vehicle_hotkey = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable roadshine shader",false,true,DsettRectImg)
	if getResourceFromName('shader_roadshine3') then
		if getElementData(localPlayer, "graphic_shader_roadshine3") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.vehicle_hotkey,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.vehicle_hotkey,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.vehicle_hotkey, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.autopark = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable vehicle auto /park",false,true,DsettRectImg)
	if getResourceFromName('vehicle-system') then
		if getElementData(localPlayer, "autopark") ~= "1" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.autopark,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.autopark,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.autopark, false)
	end

	posY = posY + lineH
	
	GUIEditor_Checkbox.antifalling = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Enable interior anti-falling",false,true,DsettRectImg)
	if getResourceFromName("interior_system") then
		if getElementData(localPlayer, "antifalling") ~= "1" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.antifalling,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.antifalling,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.antifalling, false)
	end

	posY = posY + lineH

	-----------------------------------------------------------------------
	local lineW2 = 0.34
	local posX = lineW2
	posY = 0.1005

	GUIEditor_Checkbox.vehicle_rims = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Enable custom rim models",false,true,DsettRectImg)
	if getResourceFromName("realism") then
		if getElementData(localPlayer, "vehicle_rims") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.vehicle_rims,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.vehicle_rims,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.vehicle_rims, false)
	end

	posY = posY + lineH
	GUIEditor_Checkbox.text2speech_ic_chats = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Enable Local IC chats text2speech",false,true,DsettRectImg)
	if getResourceFromName("text2speech") then
		if not getElementData(localPlayer, "text2speech_ic_chats") or getElementData(localPlayer, "text2speech_ic_chats") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.text2speech_ic_chats,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.text2speech_ic_chats,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.text2speech_ic_chats, false)
	end

	posY = posY + lineH
	GUIEditor_Checkbox.phone_anim = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Enable phone animation",false,true,DsettRectImg)
	if getElementData(localPlayer, "phone_anim") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.phone_anim,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.phone_anim,true)
	end
	
	posY = posY + lineH
	GUIEditor_Checkbox.talk_anim = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Enable /say animations",false,true,DsettRectImg)
	if not getElementData(localPlayer, "talk_anim") or getElementData(localPlayer, "talk_anim") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.talk_anim,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.talk_anim,true)
	end

	posY = posY + lineH
	GUIEditor_Checkbox.pm_username = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Show your /pm username.",false,true,DsettRectImg)
	if getElementData(localPlayer, "pm_username") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.pm_username,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.pm_username,true)
	end

	posY = posY + lineH
	GUIEditor_Checkbox.weapon_show_selector = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Show weapon selector while shooting.",false,true,DsettRectImg)
	if getElementData(localPlayer, "weapon_show_selector") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.weapon_show_selector,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.weapon_show_selector,true)
	end

	posY = posY + lineH
	GUIEditor_Checkbox.bind_indicators = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Enable rebindable indicators.",false,true,DsettRectImg)
	if getElementData(localPlayer, "bind_indicators") == "1" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.bind_indicators,true)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.bind_indicators,false)
	end

	posY = posY + lineH

	GUIEditor_Checkbox.dynamic_lighting = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Enable dynamic lighting.",false,true,DsettRectImg)
	if getResourceFromName("shader_depth_filed") then
	if getElementData(localPlayer, "dynamic_lighting") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.dynamic_lighting,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.dynamic_lighting,true)
	end
	DGS:dgsSetEnabled(GUIEditor_Checkbox.dynamic_lighting, dyn_light)
	end
	posY = posY + lineH
		local dyn_light = getResourceFromName("shader_darker_night") and true or false
	GUIEditor_Checkbox.graphic_shader_darker_night = DGS:dgsCreateCheckBox(0.0322+posX,posY,0.313,lineH,"Enhanced night mode.",false,true,DsettRectImg)
	if dyn_light then
		if getElementData(localPlayer, "graphic_shader_darker_night") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shader_darker_night,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_shader_darker_night,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_shader_darker_night, false)
	end

	posY = posY + lineH
	GUIEditor_Checkbox.dynamic_lighting_nighttime_only = DGS:dgsCreateCheckBox(0.0322+posX,posY,0.313,lineH,"Only enable at night time.",false,true,DsettRectImg)
	if getElementData(localPlayer, "dynamic_lighting_nighttime_only") ~= "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.dynamic_lighting_nighttime_only,true)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.dynamic_lighting_nighttime_only,false)
	end
	DGS:dgsSetEnabled(GUIEditor_Checkbox.dynamic_lighting_nighttime_only, dyn_light)

	posY = posY + lineH
	--local dyn_light_veh = exports.global:isResourceRunning('dynamic_lighting_vehicles') and true or false
	GUIEditor_Checkbox.dynamic_lighting_vehicles = DGS:dgsCreateCheckBox(0.0322+posX,posY,0.313,lineH,"Enable vehicle dynamic lighting.",false,true,DsettRectImg)
	if getElementData(localPlayer, "dynamic_lighting_vehicles") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.dynamic_lighting_vehicles,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.dynamic_lighting_vehicles,true)
	end
	DGS:dgsSetEnabled(GUIEditor_Checkbox.dynamic_lighting_vehicles, dyn_light and dyn_light_veh)

	if exports.integration:isPlayerSupporter(getLocalPlayer()) or exports.integration:isPlayerTrialAdmin(getLocalPlayer()) then
		posY = posY + lineH
		GUIEditor_Checkbox.auto_check = DGS:dgsCreateCheckBox(0.0222+posX,posY,0.313,lineH,"Automatically open /check on /ar",false,true,DsettRectImg)
		if getElementData(localPlayer, "auto_check") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.auto_check,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.auto_check,true)
		end
	end


	--GUIEditor_Checkbox.noti_settings = guiCreateButton(0.0222+posX,posY,0.313,lineH,"Notification Settings",true,GUIEditor_Tab.graphicSettings)

	-----------------------------------------------------------------------
	
	posX = posX + lineW2
	GUIEditor_Label.graphicSettings_desc = DGS:dgsCreateLabel(0.0222+posX,0.0361,0.313,lineH,"Overlay Description Configurations:",true,DsettRectImg)
	DGS:dgsSetFont(GUIEditor_Label.graphicSettings_desc,"default-bold-small")
	
	GUIEditor_Checkbox.enableOverlayDescription = DGS:dgsCreateCheckBox(0.036+posX,0.1005,0.2992,lineH,"Toggle all overlay description",false,true,DsettRectImg)
	if getResourceFromName("description") then
		if getElementData(localPlayer, "enableOverlayDescription") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.enableOverlayDescription,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.enableOverlayDescription,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.enableOverlayDescription, false)
	end
	
	GUIEditor_Checkbox.enableOverlayDescriptionVeh = DGS:dgsCreateCheckBox(0.036+posX,0.1005+lineH,0.2992,lineH,"Vehicle: Enable description",false,true,DsettRectImg)
	if getResourceFromName("description") then
		if getElementData(localPlayer, "enableOverlayDescriptionVeh") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.enableOverlayDescriptionVeh,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.enableOverlayDescriptionVeh,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.enableOverlayDescriptionVeh, false)
	end
	
	DGS:dgsCreateLabel ( 0.036+posX,0.1005+lineH*2+0.005,0.2992,lineH ,  "Font:", true, DsettRectImg )
	cFontVeh = DGS:dgsCreateComboBox ( 0.036+posX+0.055,0.1005+lineH*2,0.2,lineH,  getElementData(localPlayer, "cFontVeh") or "default", true, DsettRectImg )
	local count1 = 0 
	for key, font in pairs(fonts) do
		DGS:dgsComboBoxAddItem(cFontVeh, type(font[1]) == "string" and font[1] or "BizNoteFont18")
		count1 = count1 + 1
	end
	--DGS:dgsComboBoxSetBoxHeight ( cFontVeh, count1 )
	addEventHandler ( "onDgsComboBoxSelect", guiRoot,
		function ( comboBox )
			if ( comboBox == cFontVeh ) then
				local item = DGS:dgsComboBoxGetSelected ( cFontVeh )
				local text = tostring ( DGS:dgsComboBoxGetItemText ( cFontVeh , item ) )
				if ( text ~= "" ) then
					updateAccountSettings("cFontVeh", text)
				end
			end
		end
	)
	
	GUIEditor_Checkbox.enableOverlayDescriptionPro = DGS:dgsCreateCheckBox(0.036+posX,0.1005+lineH*3,0.2992,lineH,"Interior: Enable description",false,true,DsettRectImg)
	if getResourceFromName("description") then
		if getElementData(localPlayer, "enableOverlayDescriptionPro") == "0" then
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.enableOverlayDescriptionPro,false)
		else
			DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.enableOverlayDescriptionPro,true)
		end
	else
		DGS:dgsSetEnabled(GUIEditor_Checkbox.enableOverlayDescriptionPro, false)
	end
	
	DGS:dgsCreateLabel ( 0.036+posX,0.1005+lineH*4+0.005,0.2992,lineH ,  "Font:", true, DsettRectImg )
	cFontPro = DGS:dgsCreateComboBox ( 0.036+posX+0.055,0.1005+lineH*4,0.2,lineH,  getElementData(localPlayer, "cFontPro") or "default", true, DsettRectImg )
	local count1 = 0 
	for key, font in pairs(fonts) do
		DGS:dgsComboBoxAddItem(cFontPro, type(font[1]) == "string" and font[1] or "BizNoteFont18")
		count1 = count1 + 1
	end
	--DGS:dgsComboBoxSetBoxHeight ( cFontPro, count1 )
	addEventHandler ( "onDgsComboBoxSelect", guiRoot,
		function ( comboBox )
			if ( comboBox == cFontPro ) then
				local item = DGS:dgsComboBoxGetSelected ( cFontPro )
				local text = tostring ( DGS:dgsComboBoxGetItemText ( cFontPro , item ) )
				if ( text ~= "" ) then
					updateAccountSettings("cFontPro", text)
				end
			end
		end
	)
	--[[
	GUIEditor_Tab.Notifications = guiCreateTab("Notifications",GUIEditor_TabPanel.main)
	local lineH = 0.0515
	local posY = lineH

	GUIEditor_Label.graphicSettingsgeneral = guiCreateLabel(0.0222,0.0361,0.313,lineH,"Receive notifications about:",true,GUIEditor_Tab.Notifications)
	guiSetFont(GUIEditor_Label.graphicSettingsgeneral,"default-bold-small")

	GUIEditor_Checkbox.noti_faction_updates = DGS:dgsCreateCheckBox(0.036,0.1005,0.2992,lineH,"Faction updates",false,true,GUIEditor_Tab.Notifications)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.noti_faction_updates,getElementData(localPlayer, "noti_faction_updates") ~= "0")
	
	GUIEditor_Checkbox.noti_offline_pm = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Incoming offline messages",false,true,GUIEditor_Tab.Notifications)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.noti_offline_pm,getElementData(localPlayer, "noti_offline_pm") ~= "0")

	posY = posY + lineH
	GUIEditor_Checkbox.vehicle_inactivity_scanner = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Vehicle inactivity scanner",false,true,GUIEditor_Tab.Notifications)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.vehicle_inactivity_scanner,getElementData(localPlayer, "vehicle_inactivity_scanner") ~= "0")

	posY = posY + lineH
	GUIEditor_Checkbox.interior_inactivity_scanner = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Interior related",false,true,GUIEditor_Tab.Notifications)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.interior_inactivity_scanner,getElementData(localPlayer, "interior_inactivity_scanner") ~= "0")

	posY = posY + lineH
	GUIEditor_Checkbox.support_center = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.2992,lineH,"Support Center",false,true,GUIEditor_Tab.Notifications)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.support_center,getElementData(localPlayer, "support_center") ~= "0")

	local lineW2 = 0.34
	local posX = lineW2
	posY = 0.1005
	GUIEditor_Label.graphicSettingsgeneral = guiCreateLabel(0.0222+posX,0.0361,0.313,lineH,"General Settings:",true,GUIEditor_Tab.Notifications)
	guiSetFont(GUIEditor_Label.graphicSettingsgeneral,"default-bold-small")

	GUIEditor_Checkbox.noti_no_noti = DGS:dgsCreateCheckBox(0.036+posX,0.1005,1,lineH,"Show button even when there are no notifications",false,true,GUIEditor_Tab.Notifications)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.noti_no_noti,getElementData(localPlayer, "noti_no_noti") == "1")

	
	GUIEditor_Tab.Social = guiCreateTab("Social",GUIEditor_TabPanel.main)
	local lineH = 0.0515
	local posY = lineH
	
	GUIEditor_Label.graphicSettingsgeneral = guiCreateLabel(0.0222,0.0361,0.313,lineH,"Friends List:",true,GUIEditor_Tab.Social)
	guiSetFont(GUIEditor_Label.graphicSettingsgeneral,"default-bold-small")

	GUIEditor_Checkbox.social_classic_user_interface = DGS:dgsCreateCheckBox(0.036,0.1005,0.888,lineH,"Classic User Interface",false,true,GUIEditor_Tab.Social)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.social_classic_user_interface,getElementData(localPlayer, "social_classic_user_interface") == "1")
	
	GUIEditor_Checkbox.social_invite_only = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.888,lineH,"Invite only (Ignore all incoming friend requests)",false,true,GUIEditor_Tab.Social)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.social_invite_only,getElementData(localPlayer, "social_invite_only") == "1")

	posY = posY + lineH
	GUIEditor_Checkbox.social_friends_bypass_pmblock = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.888,lineH,"Allow my friends to bypass my PM block",false,true,GUIEditor_Tab.Social)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.social_friends_bypass_pmblock,getElementData(localPlayer, "social_friends_bypass_pmblock") == "1")

	posY = posY + lineH
	GUIEditor_Checkbox.social_friend_updates = DGS:dgsCreateCheckBox(0.036,0.1005+posY,0.888,lineH,"Receive friends alert and notification",false,true,GUIEditor_Tab.Social)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.social_friend_updates,getElementData(localPlayer, "social_friend_updates") ~= "0")

	posY = posY + lineH
	local indent = 0.02
	GUIEditor_Checkbox.social_friend_updates_on_off = DGS:dgsCreateCheckBox(0.036+indent,0.1005+posY,0.888,lineH,"Online/offline status",false,true,GUIEditor_Tab.Social)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.social_friend_updates_on_off,getElementData(localPlayer, "social_friend_updates_on_off") ~= "0")

	posY = posY + lineH
	GUIEditor_Checkbox.social_friend_updates_msg = DGS:dgsCreateCheckBox(0.036+indent,0.1005+posY,0.888,lineH,"Status messages",false,true,GUIEditor_Tab.Social)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.social_friend_updates_msg,getElementData(localPlayer, "social_friend_updates_msg") ~= "0")

	posY = posY + lineH
	GUIEditor_Checkbox.social_friend_updates_char = DGS:dgsCreateCheckBox(0.036+indent,0.1005+posY,0.888,lineH,"Character changes",false,true,GUIEditor_Tab.Social)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.social_friend_updates_char,getElementData(localPlayer, "social_friend_updates_char") ~= "0")

	posY = posY + lineH
	GUIEditor_Checkbox.social_friend_updates_sound = DGS:dgsCreateCheckBox(0.036+indent,0.1005+posY,0.888,lineH,"Enable sound effect",false,true,GUIEditor_Tab.Social)
	DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.social_friend_updates_sound,getElementData(localPlayer, "social_friend_updates_sound") ~= "0")

	DGS:dgsSetEnabled(GUIEditor_Checkbox.social_friend_updates_on_off, DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ))
	DGS:dgsSetEnabled(GUIEditor_Checkbox.social_friend_updates_msg, DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ))
	DGS:dgsSetEnabled(GUIEditor_Checkbox.social_friend_updates_char, DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ))
	DGS:dgsSetEnabled(GUIEditor_Checkbox.social_friend_updates_sound, DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ))
]]
	---Character Settings------------------------------------------------------------------------------------------------------------
	local lineH = 0.0515
	local posY = lineH

	--GUIEditor_Label.charSettingsgeneral = guiCreateLabel(0.0222,0.0361,0.313,lineH,"Character Configurations:",true,GUIEditor_Tab.graphicSettings)
	--guiSetFont(GUIEditor_Label.charSettingsgeneral,"default-bold-small")

	

	posY = posY + lineH
	--[[
	GUIEditor_Checkbox.graphic_motionblur = DGS:dgsCreateCheckBox(0.036,0.1005,0.2992,lineH,"Enable vehicle auto /park",false,true,GUIEditor_Tab.graphicSettings)
	if getElementData(localPlayer, "graphic_motionblur") == "0" then
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_motionblur,false)
	else
		DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox.graphic_motionblur,true)
	end]]
	
	
	
	--GUIEditor_Button.mainclose = guiCreateButton(0.0135,0.9135,0.9743,0.0675,"Close",true,GUIEditor_Window.main)
	addEventHandler("onDgsMouseClickDown", DsettRectImg, options_updateGameSettings)
	--addEventHandler("onClientGUITabSwitched", GUIEditor_TabPanel.main, updateTabs)
	--if tab and GUIEditor_Tab[tab] then
	--	guiSetSelectedTab ( GUIEditor_TabPanel.main, GUIEditor_Tab[tab] )
	--end
end
addEvent("accounts:settings:fetchSettings", true)
addEventHandler("accounts:settings:fetchSettings", localPlayer, showSettingsWindow)

function updateTabs(selectedTab )
	--FETCH DATA
	if settings then
		for i, setting in pairs(settings) do
			
			if isElement(GUIEditor_Checkbox[setting[2]]) then
				DGS:dgsCheckBoxSetSelected(GUIEditor_Checkbox[setting[2]],(setting[3] == "1"))
				--outputDebugString(setting[2].."-"..setting[3])
			end
		end
	else
		
	end
end

function closeSettingsWindow()
	if isElement(GUIEditor_Window.main) then
		removeEventHandler("onDgsMouseClickDown", GUIEditor_Window.main, options_updateGameSettings)
		--removeEventHandler("onClientGUITabSwitched", GUIEditor_TabPanel.main, updateTabs)
		destroyElement(GUIEditor_Window.main)
		GUIEditor_Window.main = nil
	end
	
	if wOptions and isElement(wOptions) then
		DGS:dgsSetEnabled(wOptions, true)
	end
	setElementData(getLocalPlayer(), "exclusiveGUI", false, false)
	exports.OwlGamingLogs:closeInfoBox()
end

function options_updateGameSettings()
	if source == GUIEditor_Button.mainclose then
		closeSettingsWindow()
	elseif source == GUIEditor_Checkbox.graphic_motionblur then
		local name, value = "graphic_motionblur", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_motionblur ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.graphic_skyclouds then
		local name, value = "graphic_skyclouds", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_skyclouds ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.streams then
		local name, value = "streams", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.streams ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_nametags then
		local name, value = "graphic_nametags", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_nametags ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.settings_hud_style then
		local name, value = "settings_hud_style", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.settings_hud_style ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_logs then
		local name, value = "graphic_logs", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_logs ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_chatbub then
		local name, value = "graphic_chatbub", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_chatbub ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_typingicon then
		local name, value = "graphic_typingicon", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_typingicon ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_shaderradar then
		local name, value = "graphic_shaderradar", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_shaderradar ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_shaderwater then
		local name, value = "graphic_shaderwater", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_shaderwater ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_shaderveh then
		local name, value = "graphic_shaderveh", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_shaderveh ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_shaderveh_reflect then
		local name, value = "graphic_shaderveh_reflect", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_shaderveh_reflect ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.graphic_shader_darker_night then
		local name, value = "graphic_shader_darker_night", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.graphic_shader_darker_night ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.enableOverlayDescription then
		local name, value = "enableOverlayDescription", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.enableOverlayDescription ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.enableOverlayDescriptionVeh then
		local name, value = "enableOverlayDescriptionVeh", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.enableOverlayDescriptionVeh ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.enableOverlayDescriptionPro then
		local name, value = "enableOverlayDescriptionPro", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.enableOverlayDescriptionPro ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.autopark then
		local name, value = "autopark", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.autopark ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.antifalling then
		local name, value = "antifalling", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.antifalling ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.vehicle_hotkey then
		local name, value = "graphic_shader_roadshine3", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.vehicle_hotkey ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.vehicle_rims then
		local name, value = "vehicle_rims", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.vehicle_rims ) then
			value = "1"
		end
		updateAccountSettings(name, value)
		triggerEvent("vehicle_rims", getRootElement(), value)
	elseif source == GUIEditor_Checkbox.text2speech_ic_chats then
		local name, value = "text2speech_ic_chats", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.text2speech_ic_chats ) then
			value = "1"
		end
		updateAccountSettings(name, value)
		triggerEvent("text2speech_ic_chats", getRootElement(), value)
	elseif source == GUIEditor_Checkbox.phone_anim then
		local name, value = "phone_anim", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.phone_anim ) then
			value = "1"
		end
		updateCharacterSettings(name, value)
	elseif source == GUIEditor_Checkbox.cellphone_log then
		local name, value = "cellphone_log", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.cellphone_log ) then
			value = "1"
			exports.OwlGamingLogs:drawInfoBox()
		end
	elseif source == GUIEditor_Checkbox.talk_anim then
		local name, value = "talk_anim", "0"
		if DGS:dgsCheckBoxGetSelected( GUIEditor_Checkbox.talk_anim ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.pm_username then
		local name, value = "pm_username", "0"
		if DGS:dgsCheckBoxGetSelected( GUIEditor_Checkbox.pm_username ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.weapon_show_selector then
		local name, value = "weapon_show_selector", "0"
		if DGS:dgsCheckBoxGetSelected( GUIEditor_Checkbox.weapon_show_selector ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.noti_faction_updates then
		local name, value = "noti_faction_updates", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.noti_faction_updates ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.noti_offline_pm then
		local name, value = "noti_offline_pm", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.noti_offline_pm ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.vehicle_inactivity_scanner then
		local name, value = "vehicle_inactivity_scanner", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.vehicle_inactivity_scanner ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.interior_inactivity_scanner then
		local name, value = "interior_inactivity_scanner", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.interior_inactivity_scanner ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.support_center then
		local name, value = "support_center", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.support_center ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.noti_no_noti then
		local name, value = "noti_no_noti", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.noti_no_noti ) then
			value = "1"
		end
		updateAccountSettings(name, value)		
	elseif source == GUIEditor_Checkbox.social_classic_user_interface then
		local name, value = "social_classic_user_interface", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_classic_user_interface ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.social_invite_only then
		local name, value = "social_invite_only", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_invite_only ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.social_friends_bypass_pmblock then
		local name, value = "social_friends_bypass_pmblock", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friends_bypass_pmblock ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.social_friend_updates then
		local name, value = "social_friend_updates", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
		DGS:dgsSetEnabled(GUIEditor_Checkbox.social_friend_updates_on_off, DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ))
		DGS:dgsSetEnabled(GUIEditor_Checkbox.social_friend_updates_msg, DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ))
		DGS:dgsSetEnabled(GUIEditor_Checkbox.social_friend_updates_char, DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ))
		DGS:dgsSetEnabled(GUIEditor_Checkbox.social_friend_updates_sound, DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates ))
	elseif source == GUIEditor_Checkbox.social_friend_updates_on_off then
		local name, value = "social_friend_updates_on_off", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates_on_off ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.social_friend_updates_msg then
		local name, value = "social_friend_updates_msg", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates_msg ) then
			value = "1"
		end
		updateAccountSettings(name, value)	
	elseif source == GUIEditor_Checkbox.social_friend_updates_char then
		local name, value = "social_friend_updates_char", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates_char ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.social_friend_updates_sound then
		local name, value = "social_friend_updates_sound", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.social_friend_updates_sound ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.bind_indicators then
		local name, value = "bind_indicators", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.bind_indicators ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.dynamic_lighting then
		local name, value = "dynamic_lighting", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.dynamic_lighting ) then
			value = "1"
		end
		DGS:dgsSetEnabled(GUIEditor_Checkbox.dynamic_lighting_vehicles, value == "1")
		DGS:dgsSetEnabled(GUIEditor_Checkbox.dynamic_lighting_nighttime_only, value == "1")
		DGS:dgsSetEnabled(GUIEditor_Checkbox.graphic_shader_darker_night, value == "1")
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.dynamic_lighting_nighttime_only then
		local name, value = "dynamic_lighting_nighttime_only", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.dynamic_lighting_nighttime_only ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.dynamic_lighting_vehicles then
		local name, value = "dynamic_lighting_vehicles", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.dynamic_lighting_vehicles ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	elseif source == GUIEditor_Checkbox.auto_check then
		local name, value = "auto_check", "0"
		if DGS:dgsCheckBoxGetSelected ( GUIEditor_Checkbox.auto_check ) then
			value = "1"
		end
		updateAccountSettings(name, value)
	end
end

function applyGameSettings(name, value)
	if name and value then
		if name == "duty_admin" or name == "duty_supporter" or name == "wrn:style" then
			value = tonumber(value) or value
		end
		setElementData(localPlayer, name, value)
		--outputDebugString("applyAccountSettings".." "..name.." "..value)
		if name == "graphic_motionblur" then

			triggerEvent("accounts:settings:graphic_motionblur", localPlayer)

			--setElementData(localPlayer, name, value, false)
		elseif name == "graphic_skyclouds" then
			if (value == "0") then
				setCloudsEnabled ( false )
			else
				setCloudsEnabled ( true )
			end
			--setElementData(localPlayer, name, value, false)
		elseif name == "streams" then
			--setElementData(localPlayer, name, value, false)
			triggerEvent("accounts:settings:updateCarRadio", localPlayer)
		--[[elseif name == "graphic_chatbub" then
			setElementData(localPlayer, name, value, false)
			triggerEvent("accounts:settings:updateChatBubbleState", localPlayer)]]
		elseif name == "graphic_typingicon" then
			--setElementData(localPlayer, name, value, false)
			triggerEvent("accounts:settings:graphic_typingicon", localPlayer)
		elseif name == "graphic_shaderradar" then
			--setElementData(localPlayer, name, value, false)
			triggerEvent("accounts:settings:graphic_shaderradar", localPlayer)
		elseif name == "graphic_shaderwater" then
			--setElementData(localPlayer, name, value, false)
			triggerEvent("accounts:settings:graphic_shaderwater", localPlayer)
		elseif name == "dynamic_lighting" then
			triggerEvent("accounts:settings:dynamic_lighting", localPlayer)
		elseif name == "graphic_shader_darker_night" then
			triggerEvent("accounts:settings:graphic_shader_darker_night", localPlayer)
		elseif name == "graphic_shaderveh" then
			--setElementData(localPlayer, name, value, false)
			triggerEvent("accounts:settings:graphic_shaderveh", localPlayer)
		elseif name == "graphic_shader_roadshine3" then
			--setElementData(localPlayer, name, value, false)
			triggerEvent("accounts:settings:switchRoadshine3", localPlayer)
		elseif name == "graphic_shaderveh_reflect" then
			--setElementData(localPlayer, name, value, false)
			triggerEvent("accounts:settings:graphic_shaderveh_reflect", localPlayer)
		end
	end
end
addEvent("accounts:settings:applyGameSettings", true)
addEventHandler("accounts:settings:applyGameSettings", localPlayer, applyGameSettings)

function updateAccountSettings(name, value)
	applyGameSettings(name, value)
	triggerServerEvent("saveClientAccountSettingsOnServer", localPlayer, name, value)
end
addEvent("accounts:settings:updateAccountSettings", true)
addEventHandler("accounts:settings:updateAccountSettings", localPlayer, updateAccountSettings)

function applyCharacterSettings(name, value)
	if name and value then
		setElementData(localPlayer, name, value)
		--outputDebugString("applyCharacterSettings".." "..name.." "..value)
		if name == "head_turning" then
			triggerEvent("realism:updateLookAt", localPlayer)
		end
	end
end
addEvent("accounts:settings:applyCharacterSettings", true)
addEventHandler("accounts:settings:applyCharacterSettings", localPlayer, applyCharacterSettings)

function updateCharacterSettings(name, value)
	applyCharacterSettings(name, value)
	triggerServerEvent("saveClientCharacterSettingsOnServer", localPlayer, name, value)
end
addEvent("accounts:settings:updateCharacterSettings", true)
addEventHandler("accounts:settings:updateCharacterSettings", localPlayer, updateCharacterSettings)

function loadAccountSettings(settingsFromServer) 
	if settingsFromServer then
		for i = 1, #settingsFromServer do
			if settingsFromServer[i][1] and settingsFromServer[i][2] then
				applyGameSettings(settingsFromServer[i][1], settingsFromServer[i][2])
			end
		end
	end
end
addEvent("accounts:settings:loadAccountSettings", true)
addEventHandler("accounts:settings:loadAccountSettings", localPlayer, loadAccountSettings)


function loadCharacterSettings(settingsFromServer) 
	if settingsFromServer then
		for i = 1, #settingsFromServer do
			if settingsFromServer[i][1] and settingsFromServer[i][2] then
				applyCharacterSettings(settingsFromServer[i][1], settingsFromServer[i][2])
			end
		end
	end
end
addEvent("accounts:settings:loadCharacterSettings", true)
addEventHandler("accounts:settings:loadCharacterSettings", localPlayer, loadCharacterSettings)

function cleanUp()
	setElementData(localPlayer, "exclusiveGUI", false, false)
end
addEventHandler("onClientResourceStart", resourceRoot, cleanUp)