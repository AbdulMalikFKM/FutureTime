--[[
* ***********************************************************************************************************************
* Copyright (c) 2020 Hype Unity - All Rights Reserved
* All rights reserved. This program and the accompanying materials are private property belongs to OwlGaming Community
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
* ***********************************************************************************************************************
]]

DGS = exports['dgs-master']
Noti = exports['cr_infobox']
local panel = { 
		login = {}, 
		register = {}, 
		sounds = { 
			{ 'http://files.owlgaming.net/menu.mp3', 1 },
			{ 'http://files.owlgaming.net/gtav.mp3', 0.3 },
			{ 'http://files.owlgaming.net/gtaiv.mp3', 0.3 },
		} 
	}
local sw, sh = DGS:dgsGetScreenSize()
local screenW, screenH = sw/800, sh/600
local fade = { }
local logoScale = 0.5
local logoSize = { sw*logoScale, sw*455/1920*logoScale }
local uFont

function open_log_reg_pannel()
	if not isElement ( panel.login.main ) then
		-- blur screen.

		-- sound effects.
		local sound = math.random( 1, 3 )
		local bgMusic = playSound ( panel.sounds[ sound ][ 1 ], true )
		if bgMusic then
			setSoundVolume( bgMusic, panel.sounds[ sound ][ 2 ] )
		end
		setElementData(localPlayer, "bgMusic", bgMusic , false)
--800,600
		-- prepare.
		showChat(false)
		showCursor(true)
		guiSetInputEnabled(true)
		local Width,Height = 350,350
		local X = (sw/2) - (Width/2)
		local Y = (sh/2) - (Height/2)
		--ufont = ufont or guiCreateFont( ':interior_system/intNameFont.ttf', 11 )
		font = DGS:dgsCreateFont(":account/login-panel/DIN-NEXT-LT-W23-REGULAR.TTF", 12)
		fonts = DGS:dgsCreateFont(":account/login-panel/DIN-NEXT-LT-W23-REGULAR.TTF", 28)
		robotoFont10 = DGS:dgsCreateFont(":job-system/storekeeper/files/Roboto-Regular.ttf", 10)
		
		browser = DGS:dgsCreateMediaBrowser(117,117) --Create Multi Media Browser
		DGS:dgsMediaLoadMedia(browser,":accountpic/vlogo.gif","IMAGE")  --Load the gif file into multi media browser
		mainRndRect = DGS:dgsCreateRoundRect(30, false,tocolor(25,25,25,255))
		btnRect = DGS:dgsCreateRoundRect(15, false, tocolor(40,39,41,255))
		btnRecthov = DGS:dgsCreateRoundRect(15, false, tocolor(255, 51, 51, 200))
		btnRectClick = DGS:dgsCreateRoundRect(15, false, tocolor(255, 51, 51, 255)) 
		
		--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		panel.login.main = DGS:dgsCreateImage((sw - 324) / 2, (sh - 370) / 2, 324, 370,mainRndRect,false)--238, 115, 324, 370
		--DGS:dgsWindowSetMovable(panel.login.main, false)
		logologin = DGS:dgsCreateImage(104, 42, 117, 117,browser,false,panel.login.main)
		panel.login.login = DGS:dgsCreateButton(9, 320, 305, 32, "LOGIN", false, panel.login.main, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
		addEventHandler("onDgsMouseClick",panel.login.login,onClickBtnLogin, false )
		DGS:dgsSetFont(panel.login.login, robotoFont10)
		DGS:dgsSetProperty(panel.login.login,"textOffset",{-120,0,false})
		DGS:dgsSetProperty(panel.login.login,"iconImage",{":accountpic/logins.png",":accountpic/logins.png",":accountpic/logins.png"})
		DGS:dgsSetProperty(panel.login.login,"iconOffset",-285)
		DGS:dgsSetProperty(panel.login.login,"iconSize",{35,35,false})
		
		panel.login.username = DGS:dgsCreateEdit(9, 194, 305, 29, "", false, panel.login.main, _, _, _, _, ":accountpic/user.png", tocolor(40, 39, 41, 255), tocolor(255, 51, 51, 255))
		panel.login.password = DGS:dgsCreateEdit(9, 233, 305, 29, "", false, panel.login.main, _, _, _, _, ":accountpic/pass.png", tocolor(40, 39, 41, 255), tocolor(255, 51, 51, 255))
		DGS:dgsSetFont( panel.login.username, font )
		DGS:dgsSetFont( panel.login.password, font )
		DGS:dgsEditSetMaxLength ( panel.login.username,25)
		DGS:dgsEditSetMaxLength ( panel.login.password,25)
		DGS:dgsEditSetMasked ( panel.login.password, true )
		DGS:dgsSetProperty( panel.login.password, 'MaskCodepoint', '8226' )
		DGS:dgsEditSetPlaceHolder( panel.login.username, "Username" )
		DGS:dgsEditSetPlaceHolder( panel.login.password, "Password" )
		--DGS:dgsEditSetMasked ( panel.login.password, true )

		addEventHandler("onDgsTextChange", panel.login.username, resetLogButtons)
		addEventHandler("onDgsTextChange", panel.login.password, resetLogButtons)
		panel.login.remember = DGS:dgsCreateSwitchButton(16, 276, 40, 17,"","",false,false,panel.login.main,tocolor(51, 255, 51, 255),tocolor(255, 51, 51, 255))
		saveLbl = DGS:dgsCreateLabel(62, 276, 61, 19, "Save Data", false, panel.login.main) 
		DGS:dgsSetFont(saveLbl, font)
        local accountData = loadLoginFromXML( )

		regImg = DGS:dgsCreateImage(-5, -5, 71, 50, ":accountpic/registers.png", false, panel.login.main, tocolor(200, 200, 200, 255))
		regLbl = DGS:dgsCreateLabel(50, 10, 308, 15, "Create new account", false, panel.login.main, tocolor(200, 200, 200, 255))
		
		panel.login.register = DGS:dgsCreateButton(50, 10, 308, 15, "", false, panel.login.main, tocolor(200, 200, 200, 0), _, _, _, _, _, tocolor(32, 32, 32, 0), tocolor(255, 51, 51, 0), tocolor(255, 51, 51, 0))
		addEventHandler("onDgsMouseClickDown",panel.login.register,OnBtnRegister, false )
		DGS:dgsBringToFront ( panel.login.register )

		ServerName = DGS:dgsCreateLabel(9, 169, 308, 15, "HYPE UNITY", false, panel.login.main)
        DGS:dgsLabelSetHorizontalAlign(ServerName, "center", false)

		--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		panel.login.reg = DGS:dgsCreateImage((sw - 534) / 2, (sh - 324) / 2, 534, 324,mainRndRect,false)--133, 138, 534, 324
		DGS:dgsSetVisible(panel.login.reg, false)
		DGS:dgsSetAlpha(panel.login.reg, 0)
		logoRegister = DGS:dgsCreateImage(209, 28, 117, 117, browser, false, panel.login.reg)
		--DGS:dgsWindowSetSizable(panel.login.reg, false)
		--DGS:dgsWindowSetMovable(panel.login.reg, false)
		
		panel.login.username2 = DGS:dgsCreateEdit(10, 161, 236, 31, "", false, panel.login.reg, _, _, _, _, ":accountpic/user.png", tocolor(40, 39, 41, 255), tocolor(255, 51, 51, 255))
		DGS:dgsEditSetMaxLength ( panel.login.username2,25)
		--DGS:dgsSetVisible(panel.login.username2,false)
		DGS:dgsSetFont( panel.login.username2, font )
		addEventHandler("onDgsTextChange", panel.login.username2, resetRegButtons)
		DGS:dgsEditSetPlaceHolder( panel.login.username2, "Username" )

		panel.login.password2 = DGS:dgsCreateEdit(288, 161, 236, 31, "", false, panel.login.reg, _, _, _, _, ":accountpic/pass.png", tocolor(40, 39, 41, 255), tocolor(255, 51, 51, 255))
		DGS:dgsEditSetMaxLength ( panel.login.password2,25)
		DGS:dgsEditSetMasked ( panel.login.password2, true )
		DGS:dgsSetProperty(panel.login.password2, 'MaskCodepoint', '8226')
		--DGS:dgsSetVisible(panel.login.password2,false)
		DGS:dgsSetFont( panel.login.password2, font )
		addEventHandler("onDgsTextChange", panel.login.password2, resetRegButtons)
		DGS:dgsEditSetPlaceHolder( panel.login.password2, "Password" )

		panel.login.repassword = DGS:dgsCreateEdit(288, 202, 236, 31, "", false, panel.login.reg, _, _, _, _, ":accountpic/pass.png", tocolor(40, 39, 41, 255), tocolor(255, 51, 51, 255))
		DGS:dgsEditSetMaxLength ( panel.login.repassword,25)
		DGS:dgsEditSetMasked ( panel.login.repassword, true )
		DGS:dgsSetProperty(panel.login.repassword, 'MaskCodepoint', '8226')
		--DGS:dgsSetVisible(panel.login.repassword,false)
		DGS:dgsSetEnabled (panel.login.repassword, true)
		DGS:dgsSetFont( panel.login.repassword, font )
		addEventHandler("onDgsTextChange", panel.login.repassword, resetRegButtons)
		DGS:dgsEditSetPlaceHolder( panel.login.repassword, "Rewrite Password" )

		panel.login.email = DGS:dgsCreateEdit(10, 202, 236, 31, "", false, panel.login.reg, _, _, _, _, ":accountpic/email.png", tocolor(40, 39, 41, 255), tocolor(255, 51, 51, 255))
		DGS:dgsEditSetMaxLength ( panel.login.email,100)
		--guiEditSetMasked ( panel.login.email, true )
		--DGS:dgsSetVisible(panel.login.email,false)
		DGS:dgsSetFont( panel.login.email, font )
		DGS:dgsSetEnabled (panel.login.email, true)
		addEventHandler("onDgsTextChange", panel.login.email, resetRegButtons)
		DGS:dgsEditSetPlaceHolder( panel.login.email, "Email" )

		--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		panel.login.register2 = DGS:dgsCreateButton(9, 268, 515, 32, "Create new account", false, panel.login.reg, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
		addEventHandler("onDgsMouseClickDown",panel.login.register2,onClickBtnRegister, false )--309, 834, 160, 39
		--DGS:dgsSetVisible(panel.login.register2,false)
		DGS:dgsSetProperty(panel.login.register2,"textOffset",{-190,0,false})
		DGS:dgsSetProperty(panel.login.register2,"iconImage",{":accountpic/registers.png",":accountpic/registers.png",":accountpic/registers.png"})
		DGS:dgsSetProperty(panel.login.register2,"iconOffset",-510)
		DGS:dgsSetProperty(panel.login.register2,"iconSize",{55,55,false})
		DGS:dgsSetFont( panel.login.register2, robotoFont10 )
		--DGS:dgsBringToFront ( panel.login.register2 )
		--reg2img = DGS:dgsCreateImage(-15, -15, 60, 60,":accountpic/registers.png",false, panel.login.register2)
		--DGS:dgsSetVisible(reg2img, false)

		backImg = DGS:dgsCreateImage(15, 5, 20, 20, ":accountpic/leftarrow.png", false, panel.login.reg, tocolor(200, 200, 200, 255))
		backLbl = DGS:dgsCreateLabel(40, 7, 308, 15, "Back", false, panel.login.reg, tocolor(200, 200, 200, 255))

		panel.login.cancel = DGS:dgsCreateButton(40, 7, 308, 15, "", false, panel.login.reg, tocolor(200, 200, 200, 0), _, _, _, _, _, tocolor(32, 32, 32, 0), tocolor(255, 51, 51, 0), tocolor(255, 51, 51, 0))
		addEventHandler("onDgsMouseClickDown",panel.login.cancel,onClickCancel, false )
		--DGS:dgsSetVisible(panel.login.cancel,false)
		DGS:dgsBringToFront ( panel.login.cancel )
		showCursor(true)

		--DGS:dgsSetText(panel.login.error, "")
		--DGS:dgsSetText(panel.login.authen, "")

		local accountData = loadLoginFromXML()
		if accountData.username then
			DGS:dgsSwitchButtonSetState ( panel.login.remember, true )
			DGS:dgsSetText ( panel.login.username, accountData.username)
			DGS:dgsSetText ( panel.login.password, accountData.password)
		else
			DGS:dgsSwitchButtonSetState ( panel.login.remember, false )
		end
		fadeCamera ( true )
	end
end

function saveLoginToXML(username, password)
    local xml_save_log_File = xmlLoadFile ("/login-panel/rememberme.xml")
    if not xml_save_log_File then
        xml_save_log_File = xmlCreateFile("/login-panel/rememberme.xml", "login")
    end
   	xmlNodeSetValue ( xmlFindChild( xml_save_log_File, "username", 0 ) or xmlCreateChild ( xml_save_log_File, "username"), username ) 
	xmlNodeSetValue ( xmlFindChild( xml_save_log_File, "password", 0 ) or xmlCreateChild ( xml_save_log_File, "password"), password ) 
	xmlSaveFile( xml_save_log_File )
	xmlUnloadFile( xml_save_log_File )
end
addEvent("saveLoginToXML", true)
addEventHandler("saveLoginToXML", getRootElement(), saveLoginToXML)

function loadLoginFromXML()
	local xml_save_log_File = xmlLoadFile ("/login-panel/rememberme.xml")
    if not xml_save_log_File then
        xml_save_log_File = xmlCreateFile("/login-panel/rememberme.xml", "login")
    end
	local username = xmlNodeGetValue( xmlFindChild( xml_save_log_File, "username", 0 ) )
	local password = xmlNodeGetValue( xmlFindChild( xml_save_log_File, "password", 0 ) )
	xmlSaveFile( xml_save_log_File )
	xmlUnloadFile( xml_save_log_File )
    return { username = username, password = password }
end

function resetSaveXML()
	local xml_save_log_File = xmlLoadFile ("/login-panel/remembermebird.xml")
    if xml_save_log_File then
		fileDelete ("/login-panel/remembermebird.xml")
		xmlUnloadFile ( xml_save_log_File )
	end
end
addEvent("resetSaveXML", true)
addEventHandler("resetSaveXML", getRootElement(), resetSaveXML)
		
function clicksave()
usernamea = DGS:dgsGetText(panel.login.username)
passworda = DGS:dgsGetText(panel.login.password)
if DGS:dgsSwitchButtonGetState ( panel.login.remember )then
    saveLoginToXML(usernamea, passworda)
else
	resetSaveXML()
end
end
addEvent("clicksave", true)
addEventHandler("clicksave", getRootElement(), clicksave)

function onClickBtnLogin(button,state)
	if(button == "left" and state == "up") then
		if (source == panel.login.login) then
			startLoggingIn()
		end
	end
end

local loginClickTimer = nil
function startLoggingIn()
	if not getElementData(localPlayer, "clickedLogin") then
		setElementData(localPlayer, "clickedLogin", true, false)
		if isTimer(loginClickTimer) then
			killTimer(loginClickTimer)
		end
		loginClickTimer = setTimer(setElementData, 1000, 1, localPlayer, "clickedLogin", nil, false)

		username = DGS:dgsGetText(panel.login.username)
		password = DGS:dgsGetText(panel.login.password)
			if DGS:dgsSwitchButtonGetState ( panel.login.remember ) then
				checksave = true
			else
				checksave = false
			end
		playSoundFrontEnd ( 6 )
		DGS:dgsSetEnabled(panel.login.login, false)
		DGS:dgsSetAlpha(panel.login.login, 0.3)
		triggerServerEvent("accounts:login:attempt", getLocalPlayer(), username, password, checksave)
		authen_msg("Login", "Sending request to server..")
	else
		Error_msg("Login", "Slow down..")
	end
end

function hideLoginPanel(keepBG)
	showCursor(true)
	if keepBG then
		for name, gui in pairs( panel.login ) do
			if name ~= 'logo' then
				DGS:dgsSetVisible( gui, false)
			end
		end
	else
		for name, gui in pairs( panel.login ) do
			if gui and isElement( gui ) then
				destroyElement( gui )
				gui = nil
			end
		end
		triggerEvent( 'hud:blur', resourceRoot, 'off', true )
		removeEventHandler( 'onClientRender', root, slideScreen )
	end
end
addEvent("hideLoginPanel", true)
addEventHandler("hideLoginPanel", getRootElement(), hideLoginPanel)


addEventHandler("onDgsMouseEnter", root,
function ()
	if source == panel.login.register then
	DGS:dgsLabelSetColor ( regLbl, 255, 51, 51, 200 )
	DGS:dgsSetProperty(regImg,"color",tocolor(255, 51, 51, 200))
	elseif source == panel.login.cancel then
	DGS:dgsLabelSetColor ( backLbl, 255, 51, 51, 200 )
	DGS:dgsSetProperty(backImg,"color",tocolor(255, 51, 51, 200))
	end
end
)

addEventHandler("onDgsMouseLeave", root,
function ()
	if source == panel.login.register then
	DGS:dgsLabelSetColor ( regLbl, 200, 200, 200, 255 )
	DGS:dgsSetProperty(regImg,"color",tocolor(200, 200, 200, 255))
	elseif source == panel.login.cancel then
	DGS:dgsLabelSetColor ( backLbl, 200, 200, 200, 255 )
	DGS:dgsSetProperty(backImg,"color",tocolor(200, 200, 200, 255))
	end
end
)

function OnBtnRegister ()
	switchToRegisterPanel() -- Disabled registration
	playSoundFrontEnd ( 2 )
	--guiSetText(panel.login.error, "Please register on Owlgaming.net/register.php")
end

function onClickCancel()
	switchToLoginPanel()
	playSoundFrontEnd ( 2 )
end

function switchToLoginPanel()
	--guiSetText(panel.login.error, "")
	--guiSetText(panel.login.authen, "")
	
	DGS:dgsSetVisible(panel.login.main, true)
	DGS:dgsAlphaTo(panel.login.reg,0,false,"OutQuad",2000)
	DGS:dgsAlphaTo(panel.login.main,1,false,"OutQuad",4500)
	DGS:dgsSetProperty(panel.login.register2,"iconImage",nil)
	setTimer(function ()
	DGS:dgsSetVisible(panel.login.reg, false)
	DGS:dgsSetVisible(panel.login.main, true)
	DGS:dgsSetProperty(panel.login.register2,"iconImage",{":accountpic/registers.png",":accountpic/registers.png",":accountpic/registers.png"})
	end, 2500, 1)
	showCursor(true)
end

function switchToRegisterPanel()
	--guiSetText(panel.login.error, "")
	--guiSetText(panel.login.authen, "")

	DGS:dgsSetVisible(panel.login.reg, true)
	DGS:dgsAlphaTo(panel.login.main,0,false,"OutQuad",2000)
	DGS:dgsAlphaTo(panel.login.reg,1,false,"OutQuad",4500)
	DGS:dgsSetProperty(panel.login.login,"iconImage",nil)
	setTimer(function ()
		 DGS:dgsSetVisible(panel.login.main, false)
		 DGS:dgsSetVisible(panel.login.reg, true)
		 DGS:dgsSetProperty(panel.login.login,"iconImage",{":accountpic/logins.png",":accountpic/logins.png",":accountpic/logins.png"})
		 end, 2500, 1)
	
	showCursor(true)
	setElementData(localPlayer, "switched", true, false)
end

function onClickBtnRegister(button,state)
	username = DGS:dgsGetText(panel.login.username2)
	password = DGS:dgsGetText(panel.login.password2)
	passwordConfirm = DGS:dgsGetText(panel.login.repassword)
	email = DGS:dgsGetText(panel.login.email)
	registerValidation(username, password, passwordConfirm,email)

	--playSoundFrontEnd ( 6 )
	--DGS:dgsSetEnabled(panel.login.register, false)
	DGS:dgsSetAlpha(panel.login.register, 0.3)
end

function registerValidation(username, password, passwordConfirm, email)
	if not username or username == "" or not password or password == "" or not passwordConfirm or passwordConfirm == "" or not email or email == ""  then
	    Noti:addBox("warning", "Please fill out all fields.")
	elseif string.len(username) < 3 then
		Noti:addBox("warning", "Username must be 3 characters or longer.")
	elseif string.len(username) >= 19 then
		Noti:addBox("warning", "Username must be less then 20 characters long.")
	elseif string.find(password, "'") or string.find(password, '"') then
		Noti:addBox("warning", "Password must not contain ' or "..'"')
	elseif string.len(password) < 8 then
		Noti:addBox("warning", "Password must be 8 characters or longer.")
	elseif password ~= passwordConfirm then
		Noti:addBox("warning", "Passwords mismatched!")
	elseif string.match(username,"%W") then
		Noti:addBox("warning", "\"!@#$\"%'^&*()\" are not allowed in username.")
	else
		local validEmail, reason = exports.global:isEmail(email)
		if not validEmail then
			Noti:addBox("warning", reason)
		else
			triggerServerEvent("accounts:register:attempt",getLocalPlayer(),username,password,passwordConfirm, email)
			authen_msg("Register", "Sending request to server.")
		end
	end
end

function registerComplete(username, pw, email)
	DGS:dgsSetText(panel.login.username, username)
	DGS:dgsSetText(panel.login.password, pw)
	playSoundFrontEnd(13)
	displayRegisterConpleteText(username, email)
end
addEvent("accounts:register:complete",true)
addEventHandler("accounts:register:complete",getRootElement(),registerComplete)

function displayRegisterConpleteText(username)
		Noti:addBox("success", "تم انشاء الحساب بنجاح")
    			switchToLoginPanel()
end

function Error_msg(Tab, Text)
showCursor(true)
	if Tab == "Login" then
		playSoundFrontEnd ( 4)
		DGS:dgsSetVisible(panel.login.register, true)
		DGS:dgsSetVisible(panel.login.login, true)
		DGS:dgsSetVisible(panel.login.password, true)
		DGS:dgsSetVisible(panel.login.username, true)
		DGS:dgsSetVisible(panel.login.remember, true)
		DGS:dgsSetVisible(panel.login.main, true)

		Noti:addBox("warning", tostring(Text))
	else
		playSoundFrontEnd ( 4)
		Noti:addBox("warning", tostring(Text))
	end
end
addEvent("set_warning_text",true)
addEventHandler("set_warning_text",getRootElement(),Error_msg)

function authen_msg(Tab, Text)
showCursor(true)
	if Tab == "Login" then
		if panel.login.authen and isElement(panel.login.authen) and guiGetVisible(panel.login.authen) then
			DGS:dgsSetVisible(panel.login.register, true)
			DGS:dgsSetVisible(panel.login.login, true)
			DGS:dgsSetVisible(panel.login.password, true)
			DGS:dgsSetVisible(panel.login.username, true)
			DGS:dgsSetVisible(panel.login.remember, true)
			DGS:dgsSetVisible(panel.login.main, true)

			Noti:addBox("warning", tostring(Text))
		end
	else
		Noti:addBox("warning", tostring(Text))
	end
end
addEvent("set_authen_text",true)
addEventHandler("set_authen_text",getRootElement(),authen_msg)


function hideLoginWindow()
	showCursor(false)
	hideLoginPanel()
end
addEvent("hideLoginWindow", true)
addEventHandler("hideLoginWindow", getRootElement(), hideLoginWindow)

function CursorError ()
showCursor(false)
end
addCommandHandler("showc", CursorError)

function resetRegButtons ()
	DGS:dgsSetEnabled(panel.login.register2, true)
	DGS:dgsSetAlpha(panel.login.register2, 1)
end

function resetLogButtons()
	DGS:dgsSetEnabled(panel.login.login, true)
	DGS:dgsSetAlpha(panel.login.login, 1)
end


local screenStandByCurrent = 0
local screenStandByComplete = 2
local screenStandByShowing = false
function screenStandBy(action, value) -- Maxime / 2015.3.25
	if action == "add" then
		screenStandByCurrent = screenStandByCurrent + 1
		if screenStandByShowing then
			authen_msg("Login", "Loading prerequisite resources.."..screenStandBy("getPercentage").."%")
		end
		return screenStandByCurrent
	elseif action == "getCurrent" then
		return screenStandByCurrent
	elseif action == "getState" then
		return screenStandByShowing
	elseif action == "setState" then
		screenStandByShowing = value
		if screenStandByShowing then
			authen_msg("Login", "Loading prerequisite resources.."..screenStandBy("getPercentage").."%")
		end
		screenStandByCurrent = 0
		return true
	elseif action == "getPercentage" then
		local percentage = math.floor(screenStandByCurrent/screenStandByComplete*100)
		if screenStandByShowing then
			authen_msg("Login", "Loading prerequisite resources.."..percentage.."%")
		end
		return percentage
	end
end
addEvent("screenStandBy",true)
addEventHandler("screenStandBy",root,screenStandBy)

addEventHandler ( "onClientElementDataChange", localPlayer,
function ( dataName )
	if getElementType ( localPlayer ) == "player" and dataName == "loggedin" then
		showChat(getElementData(localPlayer, "loggedin") == 1)
	end
end )

--