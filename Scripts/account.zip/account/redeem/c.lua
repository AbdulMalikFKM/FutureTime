---------------------------
--Moved To account (c_options)
--Developer = Dharma (AbdulMalik Almadi)
--Description = يسمح لك هذا المود بإجراء توزيعات للاعبين بأنواع مختلفة كــ (المال , جي سي , الخ..).
--Server Type = RolePlay
--For Project = لايوجد مشروع الى الان-- *
--Version = 1.0.0
--Other Version = يوجد نسخة قادمة مستقبلا باضافات اكثر وخيارات اوسع
--* Thank You ^_^
---------------------------
DGS = exports['dgs-master']
guiSetInputMode("no_binds_when_editing")
screenW, screenH = guiGetScreenSize()
Prize = nil
Code = nil
ID = nil
Time = {
 {"1 Min", 60000, 1},
 {"5 Min", 300000, 2},
 {"1 Hour", 3600000, 3},
}

Timer = {
 "1 Min",
 "5 Min",
 "1 Hour",
 }

LogTable = {}
CodeTable = {
	[1] = "A",
	[2] = "B",
	[3] = "C",
	[4] = "D",
	[5] = "E",
	[6] = "F",
	[7] = "G",
	[8] = "H",
	[9] = "I",
	[10] = "J",
	[11] = "K",
	[12] = "L",
	[13] = "M",
	[14] = "N",
	[15] = "O",
	[16] = "P",
	[17] = "Q",
	[18] = "R",
	[19] = "S",
	[20] = "T",
	[21] = "U",
	[22] = "V",
	[23] = "W",
	[24] = "X",
	[25] = "Y",
	[26] = "Z",
	[27] = "0",
	[28] = "1",
	[29] = "2",
	[30] = "3",
	[31] = "4",
	[32] = "5",
	[33] = "6",
	[34] = "7",
	[35] = "8",
	[36] = "9",
}
		mainRect = DGS:dgsCreateRoundRect(0, false,tocolor(15,15,15,255))
		
		btnRect = DGS:dgsCreateRoundRect(15, false, tocolor(20,20,20,255))  --Create Rounded Rectangle with 50 pixels radius 
		btnRecthov = DGS:dgsCreateRoundRect(15, false, tocolor(255, 51, 51, 200))  --Create Rounded Rectangle with 50 pixels radius 
		btnRectClick = DGS:dgsCreateRoundRect(15, false, tocolor(255, 51, 51, 255))
		
function redeemWnd (playerWnd)

        enterEdt = DGS:dgsCreateEdit(250, 200, 250, 32, "", false, playerWnd, _, _, _, btnRect)
       	DGS:dgsEditSetPlaceHolder( enterEdt, "Enter The Code" )
	   sumbitBtn = DGS:dgsCreateButton(250, 250, 250, 28, "Sumbit", false, playerWnd, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
end
addEvent("redeem-system:GUI:opens", true)
addEventHandler("redeem-system:GUI:opens", getRootElement(), redeemWnd)

    function infoWnds()
       -- infoWnd = DGS:dgsCreateWindow((screenW - 310) / 2, (screenH - 342) / 2, 310, 342, "Information", false)
	   infoWnd = DGS:dgsCreateImage((screenW - 310) / 2, (screenH - 342) / 2, 310, 320,mainRect,false)

        infoMemo = DGS:dgsCreateMemo(9, 8, 291, 276, "مرحبا بك في لوحة المعلومات المتعلقة بــ نظام الاكواد\nاليك بعض المساعدات لتصبح جاهز في استخدام المود\n1- يفضل عدم وضع اموال بكميات كبيرة عند التوزيع\nفأقصى كمية هي : 10000 وأدناها : 1000\nملاحظة : انت لست مقيد بهذه الارقام\n\n2- يفضل عدم وضع عملات ذهبية [GC]ي بكميات كبيرة\n3- عند استخدام التوكين المتعلق بالمركبات او البيوت\nيجب ان لاتتجاوز الـ5 قطع عند الارسال\nملاحظة : انت لست مقيد بهذه الارقام\n\n4- عند استخدام كود الرقم المميز لشريحة الهاتف\nيفضل عدم وضع ارقام تتجاوز الـ 6 او تقل عن الـ 3\n -- New Update SooN\n5- عند استخدام الكود المتعلق بالآيتم[Items]\nيجب ان يكون ايدي الايتم لايتجاوز الـ214 \nوالتأكد ان القطعة مناسبة  للاعب من خلال [items/]\nشكرا لك على تجاوبك معنا وقرائتك للملاحظات كاملة\nنرجوا الاستمتاع بالمود , وعدم التخريب\n\nفي حال وجود اي أخطاء الرجاء التحدث مع المبرمج\n\n#Author : Dharma", false, infoWnd)
       DGS:dgsSetProperty(infoMemo,"bgColor",tocolor(20, 20, 20, 255))
	   infoclsBtn = DGS:dgsCreateButton(9, 290, 291, 21, "Close", false, infoWnd, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)   			
    end

        LogWnd = DGS:dgsCreateImage((screenW - 435) / 2, (screenH - 354) / 2, 435, 354,mainRect,false)
       -- LogWnd = DGS:dgsCreateWindow((screenW - 435) / 2, (screenH - 354) / 2, 435, 354, "Redeem Code Log | By Dharma", false)
       -- DGS:dgsWindowSetSizable(LogWnd, false)
        DGS:dgsSetVisible(LogWnd, false)
        gridList = DGS:dgsCreateGridList(9, 30, 416, 275, false, LogWnd, _, tocolor(5,5,5,255), _, tocolor(5,5,5,255))
		DGS:dgsSetProperty(gridList,"rowHeight",40)
		availableItemscroll = DGS:dgsGridListGetScrollBar( gridList )
		DGS:dgsSetProperty(availableItemscroll,"arrowColor",{tocolor(65, 65, 65, 200), tocolor(255, 51, 51, 225), tocolor(255, 51, 51, 255)})
		DGS:dgsSetProperty(availableItemscroll,"cursorColor",{tocolor(65, 65, 65, 200), tocolor(255, 51, 51, 225), tocolor(255, 51, 51, 255)})
        DGS:dgsGridListAddColumn(gridList, "Name", 0.3)
        DGS:dgsGridListAddColumn(gridList, "Type", 0.22)
        DGS:dgsGridListAddColumn(gridList, "Amount", 0.15)
        DGS:dgsGridListAddColumn(gridList, "ID", 0.1)
        DGS:dgsGridListAddColumn(gridList, "Time", 0.12)
        DGS:dgsGridListAddColumn(gridList, "Code", 0.15)
        DGS:dgsGridListAddColumn(gridList, "Real Time", 0.29)
        DGS:dgsGridListAddRow(gridList)
        logclsBtn = DGS:dgsCreateButton(147, 318, 142, 26, "Close", false, LogWnd, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)  		



        Wnd2 = DGS:dgsCreateImage((screenW - 277) / 2, (screenH - 450) / 2, 277, 450,mainRect,false)
       -- Wnd2 = DGS:dgsCreateWindow((screenW - 277) / 2, (screenH - 450) / 2, 277, 450, "Redeem Code Control | By Dharma", false)
        DGS:dgsSetVisible(Wnd2, false)
		--dgsCreateComboBox(  element itemHeight = 20, int textColor = 0xFF000000, float scaleX = 1, float scaleY = 1, element normalImage = nil, element hoveringImage = nil, element clickedImage = nil, int normalColor = 0x0078C8C8, int hoveringColor = 0xC8005AFF, int clickedColor = 0xC8325AFA] )
        selectCombo = DGS:dgsCreateComboBox((277 - 175) / 2, (200 - 128) / 2, 175, 25, "Select Something", false, Wnd2, 20, _, _, _, _, _, _, tocolor(25, 25, 25, 200),tocolor(255,51,51,200),tocolor(255,51,51,255))
		DGS:dgsComboBoxSetBoxHeight(selectCombo,100,false)
		DGS:dgsSetProperty(selectCombo,"itemColor",{tocolor(25, 25, 25, 200),tocolor(255,51,51,200),tocolor(255,51,51,255)})
	  -- availableItemscroll = DGS:dgsComboBoxGetScrollBar( selectCombo )
		--DGS:dgsSetProperty(availableItemscroll,"arrowColor",{tocolor(65, 65, 65, 200), tocolor(255, 51, 51, 225), tocolor(255, 51, 51, 255)})
		--DGS:dgsSetProperty(availableItemscroll,"cursorColor",{tocolor(65, 65, 65, 200), tocolor(255, 51, 51, 225), tocolor(255, 51, 51, 255)})
		
		DGS:dgsComboBoxAddItem(selectCombo, "Money Code")
        DGS:dgsComboBoxAddItem(selectCombo, "GC Code")
        DGS:dgsComboBoxAddItem(selectCombo, "Vehicle Token's")
        DGS:dgsComboBoxAddItem(selectCombo, "House Token's")
        DGS:dgsComboBoxAddItem(selectCombo, "Special Number SIM Code")
        --guiComboBoxAddItem(selectCombo, "Item's Code")
        codeLbl = DGS:dgsCreateLabel(10, 175, 41, 18, "Code : ", false, Wnd2)
        codeEdt = DGS:dgsCreateEdit(61, 171, 110, 24, "", false, Wnd2, _, _, _, btnRect)
        valueEdt = DGS:dgsCreateEdit(61, 203, 110, 24, "", false, Wnd2, _, _, _, btnRect)
        valueLbl = DGS:dgsCreateLabel(10, 209, 41, 18, "Value : ", false, Wnd2)
        IDEdt = DGS:dgsCreateEdit(61, 237, 110, 24, "", false, Wnd2, _, _, _, btnRect)
        IDLbl = DGS:dgsCreateLabel(10, 243, 41, 18, "ID : ", false, Wnd2)
        timeLbl = DGS:dgsCreateLabel(10, 275, 41, 18, "Time : ", false, Wnd2)
        timeCombo = DGS:dgsCreateComboBox(62, 271, 109, 20, "Select Time", false, Wnd2, _, _, _, _, _, _, _, tocolor(25, 25, 25, 200),tocolor(255,51,51,200),tocolor(255,51,51,255))
		DGS:dgsSetProperty(timeCombo,"itemColor",{tocolor(25, 25, 25, 200),tocolor(255,51,51,200),tocolor(255,51,51,255)})
		DGS:dgsSetFont(timeCombo, "default-bold-small")
        DGS:dgsComboBoxAddItem(timeCombo, "1 Min")
        DGS:dgsComboBoxAddItem(timeCombo, "5 Min")
        DGS:dgsComboBoxAddItem(timeCombo, "1 Hour")
        genCodeBtn = DGS:dgsCreateButton(181, 170, 86, 25, "Generate Code", false, Wnd2, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
        randomValueBtn = DGS:dgsCreateButton(181, 202, 86, 25, "Random", false, Wnd2, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
        randomIDBtn = DGS:dgsCreateButton(181, 237, 86, 25, "Random", false, Wnd2, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
        randomTimeBtn = DGS:dgsCreateButton(181, 271, 86, 25, "Random", false, Wnd2, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
        sendBtn = DGS:dgsCreateButton(9, 365, 110, 31, "Send", false, Wnd2, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
        infoBtn = DGS:dgsCreateButton(157, 365, 110, 31, "Information", false, Wnd2, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
        logBtn = DGS:dgsCreateButton(9, 406, 110, 31, "Log (Manager)", false, Wnd2, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)
        clsBtn = DGS:dgsCreateButton(157, 406, 110, 31, "Close", false, Wnd2, tocolor(200, 200, 200, 255), _, _, btnRect, btnRecthov, btnRectClick)

		
function openRedemCodes()
        DGS:dgsSetVisible(Wnd2, not DGS:dgsGetVisible(Wnd2))
		showCursor(DGS:dgsGetVisible(Wnd2))
		end
addEvent("openRedemCodes", true)
addEventHandler("openRedemCodes", root, openRedemCodes)
		
--#ComboBox Clicks
addEventHandler("onDgsComboBoxSelect", root,
function()
local item = DGS:dgsComboBoxGetSelectedItem(selectCombo)
local text = DGS:dgsComboBoxGetItemText(selectCombo, item)

if text == "Money Code" then
DGS:dgsEditSetReadOnly(IDEdt, true)
DGS:dgsSetText(IDEdt, 134)
DGS:dgsSetEnabled(randomIDBtn, false)

elseif text == "GC Code" then
DGS:dgsEditSetReadOnly(IDEdt, true)
DGS:dgsSetText(IDEdt, -1)
DGS:dgsSetEnabled(randomIDBtn, false)

elseif text == "Vehicle Token's" then
DGS:dgsEditSetReadOnly(IDEdt, true)
DGS:dgsSetText(IDEdt, 1000)
DGS:dgsSetEnabled(randomIDBtn, false)

elseif text == "House Token's" then
DGS:dgsEditSetReadOnly(IDEdt, true)
DGS:dgsSetText(IDEdt, 1001)
DGS:dgsSetEnabled(randomIDBtn, false)

elseif text == "Special Number SIM Code" then
DGS:dgsEditSetReadOnly(IDEdt, true)
DGS:dgsSetText(IDEdt, 230)
DGS:dgsSetEnabled(randomIDBtn, false)

elseif text == "Item's Code" then
DGS:dgsEditSetReadOnly(IDEdt, false)
DGS:dgsSetEnabled(randomIDBtn, true)
--guiSetText(IDEdt, "")

end
end)

--#Buttons Clicks
addEventHandler("onDgsMouseClickDown", root,
function()
local item = DGS:dgsComboBoxGetSelectedItem(selectCombo)
local text = DGS:dgsComboBoxGetItemText(selectCombo, item)
valueM = math.random(1000, 10000)
valueO = math.random(1, 5)
IDS = math.random(1, 214)
if source == sendBtn then
if DGS:dgsComboBoxGetSelectedItem(selectCombo) == -1 then
exports.notification:addNotification("Please Select Type First", "error")
elseif DGS:dgsComboBoxGetSelectedItem(timeCombo) == -1 then
exports.notification:addNotification("Select Time First!", "error")
elseif DGS:dgsGetText(codeEdt) == "" or DGS:dgsGetText(codeEdt) == " " or DGS:dgsGetText(IDEdt) == "" or DGS:dgsGetText(IDEdt) == " " or DGS:dgsGetText(valueEdt) == "" or DGS:dgsGetText(valueEdt) == " " then
exports.notification:addNotification("Complete!", "error")
else
SuccessfulAndLog()
exports.notification:addNotification("You Successful Send The Code!", "success")
end

elseif source == genCodeBtn then
DGS:dgsSetText(codeEdt, ""..CodeTable[math.random(1,36)]..""..CodeTable[math.random(1,36)]..""..CodeTable[math.random(1,36)]..""..CodeTable[math.random(1,36)]..""..CodeTable[math.random(1,36)].."")

elseif source == clsBtn then
DGS:dgsSetVisible(Wnd2, false)
showCursor(false)
elseif source == randomIDBtn then
DGS:dgsSetText(IDEdt, IDS)

elseif source == randomValueBtn then
if text == "Money Code" or text == "GC Code" then
DGS:dgsSetText(valueEdt, valueM)
else
DGS:dgsSetText(valueEdt, valueO)
end
elseif source == randomTimeBtn then
for i, v in pairs(Time) do
   DGS:dgsComboBoxSetSelectedItem ( timeCombo, Time[math.random(#Time)][i] )
   end
   
   elseif source == infoBtn then
   infoWnds()
   DGS:dgsSetVisible(Wnd2, false)
   
   elseif source == infoclsBtn then
   DGS:dgsSetVisible(infoWnd, false)
   DGS:dgsSetVisible(Wnd2, true)
   
   elseif source == logBtn then
   DGS:dgsSetVisible(LogWnd, true)
   DGS:dgsSetVisible(Wnd2, false)
   triggerServerEvent('Log:GetTheLog',localPlayer)
   
   elseif source == logclsBtn then
   DGS:dgsSetVisible(LogWnd, false)
   DGS:dgsSetVisible(Wnd2, true)
   
   elseif source == playerclsBtn then
   DGS:dgsSetVisible(playerWnd, false)
   showCursor(false)
   
   elseif source == sumbitBtn then
   Check_The_Word()
end
end)

function Check_The_Word()
codeRight = DGS:dgsGetText(enterEdt)
codeAdmin = DGS:dgsGetText(codeEdt)
Prize = DGS:dgsGetText(valueEdt)
ID = DGS:dgsGetText(IDEdt)
Type = DGS:dgsComboBoxGetSelectedItem(selectCombo)
triggerServerEvent("CheckTheWord", localPlayer, codeRight, codeAdmin, Prize, ID, Type)
end

function SuccessfulAndLog()
   		realTime = getRealTime()
		hours = realTime.hour
		minutes = realTime.minute
		seconds = realTime.second
		day = realTime.monthday
	    month = realTime.month + 1
		year = realTime.year + 1900
        Player = getPlayerName(localPlayer)
		Code = DGS:dgsGetText(codeEdt)
		Type = DGS:dgsComboBoxGetSelectedItem(selectCombo)
		TypeText = DGS:dgsComboBoxGetItemText(selectCombo, Type)
		Prize = DGS:dgsGetText(valueEdt)
		Times = DGS:dgsComboBoxGetSelectedItem(timeCombo)
		TimeText = DGS:dgsComboBoxGetItemText(timeCombo, Times)
		ID = DGS:dgsGetText(IDEdt)
		gTime = "["..year.."/"..month.."/"..day.."/"..hours.."/"..minutes.."/"..seconds.."]"
		DGS:dgsGridListClear ( gridList )
        table.insert(LogTable, {Player, TypeText, Prize, ID, TimeText, Code, gTime})
        for i, v in pairs(LogTable) do	
            local row = DGS:dgsGridListAddRow(gridList)
		        DGS:dgsGridListSetItemText(gridList, row, 1, LogTable[i][1], false, false)
				DGS:dgsGridListSetItemText(gridList, row, 2, LogTable[i][2], false, false)
		        DGS:dgsGridListSetItemText(gridList, row, 3, LogTable[i][3], false, false) 
		        DGS:dgsGridListSetItemText(gridList, row, 4, LogTable[i][4], false, false) 
				DGS:dgsGridListSetItemText(gridList, row, 5, LogTable[i][5], false, false)
		        DGS:dgsGridListSetItemText(gridList, row, 6, LogTable[i][6], false, false) 
		        DGS:dgsGridListSetItemText(gridList, row, 7, LogTable[i][7], false, false)			 
				DGS:dgsGridListSetItemColor(gridList, row, 1, 5, 255, 0, 255) 
				DGS:dgsGridListSetItemColor(gridList, row, 2, 255, 5, 0, 255) 
				DGS:dgsGridListSetItemColor(gridList, row, 3, 5, 255, 0, 255) 	
				DGS:dgsGridListSetItemColor(gridList, row, 4, 255, 5, 0, 255) 				
				DGS:dgsGridListSetItemColor(gridList, row, 5, 5, 255, 0, 255)
				DGS:dgsGridListSetItemColor(gridList, row, 6, 255, 5, 0, 255) 
				DGS:dgsGridListSetItemColor(gridList, row, 7, 5, 255, 0, 255)		
end
 		        triggerServerEvent("MakeTheCode", localPlayer, Player, Code, TypeText, Prize, TimeText, ID, gTime)
end

   addEvent('Log:SetTheLog',true)
   addEventHandler('Log:SetTheLog',root,function(logCode)
   if DGS:dgsGetVisible(gridList) then
   		DGS:dgsGridListClear(gridList)
		end
		if #logCode~=0 then
			for k=1,#logCode do
				local row=DGS:dgsGridListAddRow(gridList)
					DGS:dgsGridListSetRowBackGroundColor(gridList,row,tocolor(25, 25, 25, 200),tocolor(255,51,51,200),tocolor(255,51,51,255))
					DGS:dgsGridListSetItemText(gridList,row,1,logCode[k].Player,false,false)
					DGS:dgsGridListSetItemText(gridList,row,2,logCode[k].Type,false,false)
					DGS:dgsGridListSetItemText(gridList,row,3,logCode[k].Prize,false,false)
					DGS:dgsGridListSetItemText(gridList,row,4,logCode[k].ID,false,false)
					DGS:dgsGridListSetItemText(gridList,row,5,logCode[k].Times,false,false)
					DGS:dgsGridListSetItemText(gridList,row,6,logCode[k].Code,false,false)
					DGS:dgsGridListSetItemText(gridList,row,7,logCode[k].gTime,false,false)
			end
		end
   end)    

