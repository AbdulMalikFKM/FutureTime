local mysql = exports.mysql

function getElementDataEx(theElement, theParameter)
	return getElementData(theElement, theParameter)
end

function setElementDataEx(theElement, theParameter, theValue, syncToClient, noSyncAtall)
	if syncToClient == nil then
		syncToClient = false
	end
	
	if noSyncAtall == nil then
		noSyncAtall = false
	end
	
	if tonumber(theValue) then
		theValue = tonumber(theValue)
	end
	
	exports.anticheat:changeProtectedElementDataEx(theElement, theParameter, theValue, syncToClient, noSyncAtall)
	return true
end

function resourceStart(resource)
	setWaveHeight ( 0 )
	setGameType("Roleplay")
	--setGameType("")
	setMapName("Los Santos")
	setRuleValue("Script Version", "2.0")
	setRuleValue("Author", "FT-RP ")
	setRuleValue("Website", "N/A")
	
	for key, value in ipairs(exports.pool:getPoolElementsByType("player")) do
		triggerEvent("playerJoinResourceStart", value, resource)
	end
	
	local appsRes = getResourceFromName("apps")
	if appsRes then
		restartResource(appsRes)
	end
end
addEventHandler("onResourceStart", getResourceRootElement(getThisResource()), resourceStart)
	
function onJoin()
	local skipreset = false
	local loggedIn = getElementData(source, "loggedin")
	if loggedIn == 1 then
		local accountID = getElementData(source, "account:id")
		local mQuery1 = mysql:query("SELECT `id` FROM `accounts` WHERE `id`='"..mysql:escape_string(accountID).."'")
		if mysql:num_rows(mQuery1) == 1 then
			skipreset = true
			setElementDataEx(source, "account:seamless:validated", true, false, true)
		end
		mysql:free_result(mQuery1)
	end
	if not skipreset then 
		-- Set the user as not logged in, so they can't see chat or use commands
		exports.anticheat:changeProtectedElementDataEx(source, "loggedin", 0, false)
		exports.anticheat:changeProtectedElementDataEx(source, "account:loggedin", false, false)
		exports.anticheat:changeProtectedElementDataEx(source, "account:username", "", false)
		exports.anticheat:changeProtectedElementDataEx(source, "account:id", "", false)
		exports.anticheat:changeProtectedElementDataEx(source, "dbid", false)
		exports.anticheat:changeProtectedElementDataEx(source, "admin_level", 0, false)
		exports.anticheat:changeProtectedElementDataEx(source, "hiddenadmin", 0, false)
		exports.anticheat:changeProtectedElementDataEx(source, "globalooc", 1, false)
		exports.anticheat:changeProtectedElementDataEx(source, "muted", 0, false)
		exports.anticheat:changeProtectedElementDataEx(source, "loginattempts", 0, false)
		exports.anticheat:changeProtectedElementDataEx(source, "timeinserver", 0, false)
		setElementData(source, "chatbubbles", 0, false)
		setElementDimension(source, 9999)
		setElementInterior(source, 0)
		makeIName(source)
	end
	
	exports.global:updateNametagColor(source)
end
addEventHandler("onPlayerJoin", getRootElement(), onJoin)
addEvent("playerJoinResourceStart", false)
addEventHandler("playerJoinResourceStart", getRootElement(), onJoin)

--[[ DO NOT UNQUOTE THIS IF U'RE NOT SURE WHAT YOU'RE DOING. - MAXIME
function changeAccountPassword(thePlayer, commandName, accountUsername, newPass, newPassConfirm)
	if exports.integration:isPlayerSeniorAdmin(thePlayer) then
		if not accountUsername or not newPass or not newPassConfirm then
			outputChatBox("SYNTAX: /" .. commandName .. " [Account Username] [New Password] [Confirm Pass]", thePlayer, 125, 125, 125)
		else
			if (newPass ~= newPassConfirm) then
				triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "The passwords do not match.")
			elseif (string.len(newPass)<6) then
				triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "Your password is too short. \n You must enter 6 or more characters.")
			elseif (string.len(newPass)>=30) then
				triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "Your password is too long. \n You must enter less than 30 characters.")
			elseif (string.find(newPass, ";", 0)) or (string.find(newPass, "'", 0)) or (string.find(newPass, "@", 0)) or (string.find(newPass, ",", 0)) then
				triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "Your password cannot contain ;,@'.")
			else
				local accountData
				local account = exports.mysql:query("SELECT id FROM accounts WHERE username ='"..exports.mysql:escape_string(accountUsername).."' LIMIT 1")
				if (mysql:num_rows(account) > 0) then
					accountData = mysql:fetch_assoc(account)
					mysql:free_result(account)
				else
					triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "No account with that username was found.")
					return
				end
				local password = md5("wedorp" .. newPass)
				local escapedPass = exports.mysql:escape_string(password)
				local query = exports.mysql:query_free("UPDATE accounts SET password = '" .. escapedPass .. "' WHERE id = '" .. accountData["id"] .. "'")
				if query then
					triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, accountUsername.."'s password was sussesfully changed.")
				else
					triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "MySQL error please try again later.")
				end
			end
		end
	end
end
addCommandHandler("setaccountpassword", changeAccountPassword, false, false)

function changePlayerPassword(thePlayer, commandName, newPass, newPassConfirm)
	if getElementData(thePlayer, "loggedin") then
		if not newPass or not newPassConfirm then
			outputChatBox("SYNTAX: /" .. commandName .. " [New Password] [Confirm Pass]", thePlayer, 125, 125, 125)
		else
			if (newPass ~= newPassConfirm) then
				triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "The passwords do not match.")
			elseif (string.len(newPass)<6) then
				triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "Your password is too short. \n You must enter 6 or more characters.")
			elseif (string.len(newPass)>=30) then
				triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "Your password is too long. \n You must enter less than 30 characters.")
			elseif (string.find(newPass, ";", 0)) or (string.find(newPass, "'", 0)) or (string.find(newPass, "@", 0)) or (string.find(newPass, ",", 0)) then
				triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "Your password cannot contain ;,@'.")
			else
				local dbid = getElementData(thePlayer, "account:id")
				local escapedID = exports.mysql:escape_string(dbid) -- Pointless, I know -Tam
				local password = md5("wedorp" .. newPass)
				local escapedPass = exports.mysql:escape_string(password)
				local query = exports.mysql:query_free("UPDATE accounts SET password = '" .. escapedPass .. "' WHERE id = '" .. escapedID .. "'")
				if query then
					triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "Your password was sussesfully changed.")
				else
					triggerClientEvent(thePlayer, "accounts:error:window", thePlayer, "MySQL error please try again later.")
				end
			end
		end
	end
end
addCommandHandler("changeaccountpassword", changePlayerPassword, false, false)
]]

function resetNick(oldNick, newNick)
	exports.anticheat:changeProtectedElementDataEx(client, "legitnamechange", 1)
	setPlayerName(client, oldNick)
	exports.anticheat:changeProtectedElementDataEx(client, "legitnamechange", 0)
	exports.global:sendMessageToAdmins("AdmWrn: " .. tostring(oldNick) .. " tried to change their name to " .. tostring(newNick) .. ".")
end
addEvent("resetName", true )
addEventHandler("resetName", getRootElement(), resetNick)

function makeIName(thePlayer)
	setPlayerName(thePlayer, "Future["..tostring(math.random(0,9))..tostring(math.random(0,9))..tostring(math.random(0,9))..tostring(math.random(0,9)).."]Time")
end

--By Dharma Properties--

function getPropertiesInfo(localPlayer)
	local allVehicles = getElementsByType("vehicle")
	local vehicleTable = { }
	local playerDBID = getElementData(client,"dbid")
	local carried = " Carried Weight: #00A2FF"..("%.2f#FFFFFF/%.2f" ):format( exports["item-system"]:getCarriedWeight( localPlayer ), exports["item-system"]:getMaxWeight( localPlayer ) ).." kg(s)"
	if not playerDBID then
		return
	end
	for _,vehicleElement in ipairs( exports.pool:getPoolElementsByType("vehicle") ) do
		if (getElementData(vehicleElement, "owner")) and (tonumber(getElementData(vehicleElement, "owner")) == tonumber(playerDBID)) and exports['vehicle-system']:hasVehiclePlates(vehicleElement) then
			local vehicleID = getElementData(vehicleElement, "dbid")
			table.insert(vehicleTable, { vehicleID, vehicleElement } )
		end
	end
	local interiorTable = { }
	myID = exports.global:getCharacterIDFromName(getPlayerName(client))
	--mysql:query("SELECT * FROM `pd_tickets` WHERE `plate` ='" ..mysql:escape_string(myPlate).."'")
	local mQuery = mysql:query("SELECT `id`, `x`, `y`, `z`, `type`, `cost`, `name` FROM `interiors` WHERE `owner` ='" ..mysql:escape_string(myID).."'")
		while true do
			local row = mysql:fetch_assoc(mQuery)
				if not row then break end
						--if tonumber(row["amount"]) >= 0 then
								table.insert( interiorTable, { row.id, row.x, row.y, row.z, row.type, row.cost, row.name} )

	end
		triggerClientEvent(client, "propertiesInfo", client, vehicleTable, interiorTable, carried)
		mysql:free_result(mQuery)
end
addEvent("showMeMyProperties", true)
addEventHandler("showMeMyProperties", getRootElement(), getPropertiesInfo)