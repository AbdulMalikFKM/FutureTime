function centerWindow(center_window)
    local screenW,screenH=guiGetScreenSize()
    local windowW,windowH=guiGetSize(center_window,false)
    local x,y = (screenW-windowW)/2,(screenH-windowH)/2
    guiSetPosition(center_window,x,y,false)
end

function guiComboBoxAdjustHeight ( combobox, itemcount )
	if itemcount < 3 then itemcount = 3 end
	itemcount = itemcount + 1
	if getElementType ( combobox ) ~= "gui-combobox" or type ( itemcount ) ~= "number" then error ( "Invalid arguments @ 'guiComboBoxAdjustHeight'", 2 ) end
	local width = guiGetSize ( combobox, false )
	return guiSetSize ( combobox, width, ( itemcount * 20 ) + 20, false )
end

function playSoundError()
	playSoundFrontEnd(4)
end

function playSoundSuccess()
	playSoundFrontEnd(13)
end

function playSoundCreate()
	playSoundFrontEnd(6)
end

function playSoundAlert()
	playSound("sounds/invite.ogg")
end

local screenWidth, screenHeight = guiGetScreenSize()
function reMap(value, low1, high1, low2, high2)
	return low2 + (value - low1) * (high2 - low2) / (high1 - low1)
end

local responsiveMultiplier = reMap(screenWidth, 1024, 1920, 0.75, 1)

function getResponsiveMultiplier()
	return responsiveMultiplier
end

function resp(value)
	return value * responsiveMultiplier
end

function respc(value)
	return math.ceil(value * responsiveMultiplier)
end