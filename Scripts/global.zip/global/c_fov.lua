function getPlayerFov()
	return dxGetStatus()["SettingFOV"]
end