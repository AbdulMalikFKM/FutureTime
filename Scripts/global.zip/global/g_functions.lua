-- exploding
function explode(div,str) -- credit: http://richard.warburton.it
  if (div=='') then return false end
  local pos,arr = 0,{}
  -- for each divider found
  for st,sp in function() return string.find(str,div,pos,true) end do
    table.insert(arr,string.sub(str,pos,st-1)) -- Attach chars left of current divider
    pos = sp + 1 -- Jump past current divider
  end
  table.insert(arr,string.sub(str,pos)) -- Attach chars right of last divider
  return arr
end

--MAXIME
function getUrlFromString(message)
	if not message or string.len(message) < 1 then
		return false
	end

	for _, v in ipairs(split(message, ' ')) do
		if v:sub(1, 7) == 'http://' or v:sub(1, 8) == 'https://' or v:sub(1, 4) == 'www.' then
			return v
		end
	end
	
	return false
end

function getRandomSkin()
	while true do 
		local ran = math.random(1,288)
		local ped = createPed(ran, 0, 0, 3)
		if ped then
			destroyElement(ped)
			return ran
		end
	end
end

function round(val, decimal)
  if (decimal) then
    return math.floor( (val * 10^decimal) + 0.5) / (10^decimal)
  else
    return math.floor(val+0.5)
  end
end

local alphanumberics = {
	['1'] = true,
	['2'] = true,
	['3'] = true,
	['4'] = true,
	['5'] = true,
	['6'] = true,
	['7'] = true,
	['8'] = true,
	['9'] = true,
	['0'] = true,
	['q'] = true,
	['w'] = true,
	['e'] = true,
	['r'] = true,
	['t'] = true,
	['y'] = true,
	['u'] = true,
	['i'] = true,
	['o'] = true,
	['p'] = true,
	['a'] = true,
	['s'] = true,
	['d'] = true,
	['f'] = true,
	['g'] = true,
	['h'] = true,
	['j'] = true,
	['k'] = true,
	['l'] = true,
	['z'] = true,
	['x'] = true,
	['c'] = true,
	['v'] = true,
	['b'] = true,
	['n'] = true,
	['m'] = true,
	['-'] = true,
	['_'] = true,
	['.'] = true,
}

function hasSpecialChars(str)
	for i = 1, string.len(str) do
		local char = string.lower(string.sub(str, i, i))
		if not alphanumberics[char] then
			return true
		end
	end
	return false
end

function isEmail(str)
	if not str or str == "" or string.len(str) < 1 then
		return false, "Email must not be empty."
	end

	local _,nAt = str:gsub('@','@') -- Counts the number of '@' symbol
	
	if nAt ~=1 then 
		return false, "Email must contain one and only one '@'."
	end

	if str:len() > 100 then
		return false, "Email must not be longer than 100 characters."
	end

	local text = exports.global:explode('@', str) 
	local localPart = text[1]
	local domainPart = text[2]
	if not localPart or not domainPart then 
		return false, "Email local or domain part is missing." 
	end

	if hasSpecialChars(localPart) then
		return false, "Email local part is invalid." 
	end

	if hasSpecialChars(domainPart) then
		return false, "Email domain part is invalid." 
	end

	return true, "Email address is valid!"
end

function convertTime(timeTable, asAlphanumericalDate)
	-- timeTable should be in the format of: hh,mm,ss,dd,mm,yyyy
	local time = split(timeTable, ",")
	local tableToReturn

	if (asAlphanumericalDate) then
		time[4] = tonumber(time[4])
		time[5] = tonumber(time[5])

		-- Parse the date.
		if (time[4] == 1) or (time[4] == 21) or (time[4] == 31) then
			time[4] = time[4] .. "st"
		elseif (time[4] == 2) or (time[4] == 22) then
			time[4] = time[4] .. "nd"
		elseif (time[4] == 3) or (time[4] == 23) then
			time[4] = time[4] .. "rd"
		else
			time[4] = time[4] .. "th"
		end

		-- Parse the month.
		if time[5] == 1 then time[5] = "January"
			elseif time[5] == 2 then time[5] = "February"
			elseif time[5] == 3 then time[5] = "March"
			elseif time[5] == 4 then time[5] = "April"
			elseif time[5] == 5 then time[5] = "May"
			elseif time[5] == 6 then time[5] = "June"
			elseif time[5] == 7 then time[5] = "July"
			elseif time[5] == 8 then time[5] = "August"
			elseif time[5] == 9 then time[5] = "September"
			elseif time[5] == 10 then time[5] = "October"
			elseif time[5] == 11 then time[5] = "November"
			elseif time[5] == 12 then time[5] = "December"
			else time[5] = "Unknown"
		end

		tableToReturn = {
			[1] = time[1] .. ":" .. time[2] .. ":" .. time[3],
			[2] = time[4] .. " of " .. time[5] .. ", " .. time[6]
		}

	else
		tableToReturn = {
			[1] = time[1] .. ":" .. time[2] .. ":" .. time[3],
			[2] = time[4] .. "/" .. time[5] .. "/" .. time[6]
		}

	end

	return tableToReturn
end

function inDistance3D(element1, element2, distance)
	if isElement(element1) and isElement(element2) then
	    local x1, y1, z1 = getElementPosition(element1)
	    local x2, y2, z2 = getElementPosition(element2)
	    local distance2 = getDistanceBetweenPoints3D(x1, y1, z1, x2, y2, z2)

	    if distance2 <= distance then
	        return true, distance2
	    end
	end

    return false, 99999
end

function inDistance2D(element1, element2, distance)
	if isElement(element1) and isElement(element2) then
	    local x1, y1, z1 = getElementPosition(element1)
	    local x2, y2, z2 = getElementPosition(element2)
	    local distance2 = getDistanceBetweenPoints2D(x1, y1, x2, y2)

	    if distance2 <= distance then
	        return true, distance2
	    end
	end
	
    return false, 99999
end

function dxDrawOctagon3D(x, y, z, radius, width, color)
	if type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then
		return false
	end

	local radius = radius or 1
	local radius2 = radius/math.sqrt(2)
	local width = width or 1
	local color = color or tocolor(255,255,255,150)

	point = {}

		for i=1,8 do
			point[i] = {}
		end

		point[1].x = x
		point[1].y = y-radius
		point[2].x = x+radius2
		point[2].y = y-radius2
		point[3].x = x+radius
		point[3].y = y
		point[4].x = x+radius2
		point[4].y = y+radius2
		point[5].x = x
		point[5].y = y+radius
		point[6].x = x-radius2
		point[6].y = y+radius2
		point[7].x = x-radius
		point[7].y = y
		point[8].x = x-radius2
		point[8].y = y-radius2
		
	for i=1,8 do
		if i ~= 8 then
			x, y, z, x2, y2, z2 = point[i].x,point[i].y,z,point[i+1].x,point[i+1].y,z
		else
			x, y, z, x2, y2, z2 = point[i].x,point[i].y,z,point[1].x,point[1].y,z
		end
		dxDrawLine3D(x, y, z, x2, y2, z2, color, width)
	end
	return true
end

local tick = getTickCount()
local speed = 3000

function dxDrawImageOnElement(TheElement,Image,height,width,R,G,B,alpha)
    local x, y, z = getElementPosition(TheElement)
    local height = height or 1
    local width = width or 1
    local sx, sy = getScreenFromWorldPosition(x, y, z+height)
    if(sx) and (sy) then 
    	local move_z = interpolateBetween(z+height+0.1, 0, 0, z+height-0.3, 0, 0, (getTickCount() - tick) / speed, "SineCurve")
        dxDrawMaterialLine3D(x, y, move_z+1, x, y, move_z, Image, width, tocolor(R or 255, G or 255, B or 255, alpha or 255))
    end
end

function convertSecondsToMinutes(sec) --turn the seconds into a MM:SS format 
        local hours = math.floor (sec/3600000) -- convert ms to hours
        local mins = math.floor (sec/60000) -- convert ms to mins
        local secs = math.floor ((sec/1000) % 60) -- convert ms to secs
		
		local hour = string.format ( "%02s", math.floor (sec/3600000))
		local min = string.format ( "%02s", ( mins - hours * 60 ))
		local sec = string.format ( "%02s", secs )

   return tostring(hour)..":"..tostring(min).. ":"..tostring(sec) 
end 