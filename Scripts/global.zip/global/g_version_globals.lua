scriptVersion = "1.2.5"
function getScriptVersion()
	return scriptVersion
end
